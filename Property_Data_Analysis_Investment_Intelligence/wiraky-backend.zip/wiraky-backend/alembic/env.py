from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool, text

from alembic import context
from app.database import Base
from app.models import *

# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# add your model's MetaData object here
# for 'autogenerate' support
# from myapp import mymodel
# target_metadata = mymodel.Base.metadata
target_metadata = Base.metadata

# other values from the config, defined by the needs of env.py,
# can be acquired:
# my_important_option = config.get_main_option("my_important_option")
# ... etc.

include_schemas = ["operasional", "analitik"]
 
 
def include_object(object, name, type_, reflected, compare_to):
    """
    Filter objek yang di-autogenerate oleh Alembic.
    Hanya memantau tabel di schema operasional dan analitik.
    Mengabaikan schema public dan schema sistem PostgreSQL.
    """
    if type_ == "table":
        schema = getattr(object, "schema", None)
        if schema not in include_schemas:
            return False
    return True

def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        include_schemas=True,
        include_object=include_object,
        version_table="alembic_version",
        version_table_schema="operasional",
    )
    with context.begin_transaction():
        context.run_migrations()
 
 
def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        # Set search_path agar Alembic menemukan tabel alembic_version
        connection.execute(text("SET search_path TO operasional, analitik, public"))
        connection.commit()
 
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            include_schemas=True,
            include_object=include_object,
            version_table="alembic_version",
            version_table_schema="operasional",
        )
        with context.begin_transaction():
            context.run_migrations()
 
 
if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()