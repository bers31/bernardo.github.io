# app/dependencies.py

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from app.auth import decode_token

security = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> str:
    """
    Dependency yang sudah ada — mengembalikan username sebagai string.
    Digunakan oleh seluruh endpoint GET agar tidak memerlukan perubahan.
    """
    token     = credentials.credentials
    user_data = decode_token(token)

    if user_data is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token tidak valid atau sudah kadaluarsa.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user_data["username"]


def get_current_user_data(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> dict:
    """
    Dependency baru — mengembalikan dict berisi username dan role.
    Digunakan oleh require_admin untuk pemeriksaan hak akses.
    """
    token     = credentials.credentials
    user_data = decode_token(token)

    if user_data is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token tidak valid atau sudah kadaluarsa.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user_data


def require_admin(
    user_data: dict = Depends(get_current_user_data)
) -> dict:
    """
    Dependency untuk melindungi endpoint CUD (Create/Update/Delete).
    Hanya pengguna dengan role 'admin' yang dapat mengaksesnya.
    Role 'user' akan mendapat HTTP 403 Forbidden.
    """
    if user_data.get("role") != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Akses ditolak. Hanya admin yang dapat melakukan operasi ini."
        )
    return user_data