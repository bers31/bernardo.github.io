# app/models.py

from sqlalchemy import Column, String, Numeric, SmallInteger, BigInteger, Text, ForeignKey, UniqueConstraint, Date, Integer
from sqlalchemy.orm import relationship
from app.database import Base


class Provinsi(Base):
    __tablename__ = "provinsi"
    __table_args__ = {"schema": "operasional"}

    kode_provinsi  = Column(String(10), primary_key=True)
    nama_provinsi  = Column(String(255), nullable=False)

    # Relasi: satu provinsi memiliki banyak kabupaten/kota
    kabupaten_kota = relationship("KabupatenKota", back_populates="provinsi")


class KabupatenKota(Base):
    __tablename__ = "kabupaten_kota"
    __table_args__ = {"schema": "operasional"}

    kode_kabupaten_kota  = Column(String(10), primary_key=True)
    nama_kabupaten_kota  = Column(String(255), nullable=False)
    kode_provinsi        = Column(String(10), ForeignKey("operasional.provinsi.kode_provinsi"), nullable=False)

    # Relasi balik ke provinsi
    provinsi   = relationship("Provinsi", back_populates="kabupaten_kota")
    # Relasi: satu kabupaten/kota memiliki banyak data UMR
    umr_list   = relationship("UMR", back_populates="kabupaten_kota")


class TipeProperti(Base):
    __tablename__ = "tipe_properti"
    __table_args__ = {"schema": "operasional"}

    id   = Column(String(20), primary_key=True)
    nama = Column(String(255), unique=True, nullable=False)

    properti_list = relationship("Properti", back_populates="tipe_properti")


class SegmenHarga(Base):
    __tablename__ = "segmen_harga"
    __table_args__ = {"schema": "operasional"}

    id   = Column(String(20), primary_key=True)
    nama = Column(String(50), unique=True, nullable=False)

    properti_list = relationship("Properti", back_populates="segmen_harga")


class Area(Base):
    __tablename__ = "area"
    __table_args__ = {"schema": "operasional"}

    area_id        = Column(String(20), primary_key=True)
    nama_area = Column(String(255), unique=True, nullable=False)
    kabupaten_kota      = Column(String(255), nullable=False)

    properti_list = relationship("Properti", back_populates="area")


class Properti(Base):
    __tablename__ = "properti"
    __table_args__ = {"schema": "operasional"}

    id               = Column(String(20), primary_key=True)
    harga            = Column(BigInteger, nullable=False)
    deskripsi        = Column(Text)
    kamar_tidur      = Column(SmallInteger)
    kamar_mandi      = Column(SmallInteger)
    carport          = Column(SmallInteger)
    tahun            = Column(SmallInteger, nullable=True)
    luas_tanah_m2    = Column(Numeric(10, 2))
    luas_bangunan_m2 = Column(Numeric(10, 2))
    area_id          = Column(String(20), ForeignKey("operasional.area.area_id"))
    keyword          = Column(Text)
    tipe_properti_id = Column(String(20), ForeignKey("operasional.tipe_properti.id"))
    segmen_harga_id  = Column(String(20), ForeignKey("operasional.segmen_harga.id"))
    area             = relationship("Area", back_populates="properti_list")
    tipe_properti    = relationship("TipeProperti", back_populates="properti_list")
    segmen_harga     = relationship("SegmenHarga", back_populates="properti_list")

# ─────────────────────────────────────────────────────────────────────────────
# SCHEMA: analitik
# Seluruh tabel ini berada di schema 'analitik'
# ─────────────────────────────────────────────────────────────────────────────

class InflasiBulanan(Base):
    __tablename__  = "inflasi_bulanan"
    __table_args__ = (
        UniqueConstraint(
            "provinsi", "tahun", "bulan", "index_base",
            name="inflasi_unique"
        ),
        {"schema": "analitik"}
    )
 
    id          = Column(Integer, primary_key=True, autoincrement=True)
    provinsi    = Column(String(100), nullable=False)
    tahun       = Column(SmallInteger, nullable=False)
    bulan       = Column(SmallInteger, nullable=False)
    nilai       = Column(Numeric(8, 4), nullable=False)
    index_base  = Column(SmallInteger, nullable=False, default=2022)
 
 
class IHPR2018(Base):
    __tablename__  = "ihpr_2018"
    __table_args__ = (
        UniqueConstraint("kota", "tipe", "tahun", "kuartal", name="ihpr_2018_unique"),
        {"schema": "analitik"}
    )
 
    id       = Column(Integer, primary_key=True, autoincrement=True)
    kota     = Column(String(100), nullable=False)
    tipe     = Column(String(50),  nullable=False)
    tahun    = Column(SmallInteger, nullable=False)
    kuartal  = Column(String(5),   nullable=False)
    nilai    = Column(Numeric(10, 4), nullable=False)
 
 
class IHPR2002(Base):
    __tablename__  = "ihpr_2002"
    __table_args__ = (
        UniqueConstraint("kota", "tipe", "tahun", "kuartal", name="ihpr_2002_unique"),
        {"schema": "analitik"}
    )
 
    id       = Column(Integer, primary_key=True, autoincrement=True)
    kota     = Column(String(100), nullable=False)
    tipe     = Column(String(50),  nullable=False)
    tahun    = Column(SmallInteger, nullable=False)
    kuartal  = Column(String(5),   nullable=False)
    nilai    = Column(Numeric(10, 4), nullable=False)
 
 
class PDBPertumbuhan(Base):
    __tablename__  = "pdb_pertumbuhan"
    __table_args__ = (
        UniqueConstraint(
            "komponen", "laju_pertumbuhan", "tahun", "kuartal",
            name="pdb_unique"
        ),
        {"schema": "analitik"}
    )
 
    id                  = Column(Integer, primary_key=True, autoincrement=True)
    komponen            = Column(String(200), nullable=False)
    level               = Column(String(50),  nullable=False)
    laju_pertumbuhan    = Column(String(50),  nullable=False)
    tahun               = Column(SmallInteger, nullable=False)
    kuartal             = Column(String(5),   nullable=False)
    nilai               = Column(Numeric(10, 4), nullable=False)
 
 
class BIRate(Base):
    __tablename__  = "bi_rate"
    __table_args__ = {"schema": "analitik"}
 
    id          = Column(Integer, primary_key=True, autoincrement=True)
    tanggal     = Column(Date, unique=True, nullable=False)
    nilai_pct   = Column(Numeric(5, 2), nullable=False)
 
 
class SensusPenduduk(Base):
    __tablename__  = "sensus_penduduk"
    __table_args__ = (
        UniqueConstraint(
            "provinsi", "tahun", "status", "gender",
            name="sensus_unique"
        ),
        {"schema": "analitik"}
    )
 
    id          = Column(Integer, primary_key=True, autoincrement=True)
    provinsi    = Column(String(100), nullable=False)
    tahun       = Column(SmallInteger, nullable=False)
    status      = Column(String(50),  nullable=False)
    gender      = Column(String(20),  nullable=False)
    nilai       = Column(BigInteger,  nullable=False)

class UMR(Base):
    __tablename__ = "umr"
    __table_args__ = (
        UniqueConstraint(
            "kode_kabupaten_kota",
            "tahun",
            name="umr_kode_kabupaten_kota_tahun_key"
        ),
        {"schema": "analitik"}
    )

    id                   = Column(String(20), primary_key=True)
    kode_kabupaten_kota  = Column(String(10), ForeignKey("operasional.kabupaten_kota.kode_kabupaten_kota"), nullable=False)
    besaran_upah_minimum = Column(Numeric(15, 2), nullable=False)
    satuan               = Column(String(20), default="RUPIAH")
    tahun                = Column(SmallInteger, nullable=False)

    kabupaten_kota = relationship("KabupatenKota", back_populates="umr_list")