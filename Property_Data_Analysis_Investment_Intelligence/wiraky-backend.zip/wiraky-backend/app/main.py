# app/main.py

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import auth, provinsi, umr, properti, kabupaten_kota, area, tipe_properti, segmen_harga, inflasi, ihpr, pdb, BI_rate, sensus, investasi_properti

app = FastAPI(
    title="Wiraky Nusa Telekomunikasi API",
    description="""
    Backend API untuk sistem manajemen data dan analitik investasi properti
    Wiraky Nusa Telekomunikasi.
    
    ## Schema Database
    - **operasional** — Data transaksi harian: provinsi, kabupaten/kota, UMR, area, properti
    - **analitik** — Data makroekonomi: inflasi, IHPR, PDB, BI Rate, sensus penduduk
    """,
    version="2.0.0",
)

# CORS — mengizinkan frontend untuk berkomunikasi dengan backend
# Pada produksi, ganti ["*"] dengan domain frontend yang spesifik
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Daftarkan semua router
app.include_router(auth.router)
app.include_router(provinsi.router)
app.include_router(kabupaten_kota.router)
app.include_router(umr.router)
app.include_router(area.router)
app.include_router(tipe_properti.router)
app.include_router(segmen_harga.router)
app.include_router(properti.router)

# ── Router analitik ───────────────────────────────────────────────────────────
app.include_router(inflasi.router)
app.include_router(ihpr.router)
app.include_router(pdb.router)
app.include_router(BI_rate.router)
app.include_router(sensus.router)
app.include_router(investasi_properti.router)


@app.get("/", tags=["Health Check"])
def root():
    """Endpoint untuk memverifikasi bahwa server berjalan."""
    return {
        "status": "online",
        "aplikasi": "Wiraky Nusa Telekomunikasi API",
        "versi": "2.0.0",
        "dokumentasi": "/docs"
    }