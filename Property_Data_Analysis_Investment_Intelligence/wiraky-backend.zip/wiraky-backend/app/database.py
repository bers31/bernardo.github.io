# app/database.py

from sqlalchemy import create_engine, event, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    class Config:
        env_file = ".env"


settings = Settings()

# Engine adalah koneksi utama ke database
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,      # Memastikan koneksi masih hidup sebelum digunakan
    pool_size=10,            # Jumlah koneksi yang disimpan di pool
    max_overflow=20,         # Koneksi tambahan jika pool penuh
)

@event.listens_for(engine, "connect")
def set_search_path(dbapi_connection, connection_record):
    cursor = dbapi_connection.cursor()
    cursor.execute("SET search_path TO operasional, analitik, public")
    cursor.close()

# SessionLocal adalah pabrik session — setiap request mendapat session-nya sendiri
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base adalah kelas induk untuk semua model SQLAlchemy
Base = declarative_base()


def get_db():
    """
    Dependency function — memberikan session database ke setiap endpoint.
    Session akan otomatis ditutup setelah request selesai.
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()