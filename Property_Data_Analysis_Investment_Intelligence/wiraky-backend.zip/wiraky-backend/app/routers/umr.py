# app/routers/umr.py

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload
from typing import Optional, List
from app.database import get_db
from app.models import UMR, KabupatenKota, Provinsi
from app.schemas import UMRResponse, PaginatedResponse, UMRCreate, UMRUpdate
from app.dependencies import get_current_user, require_admin
from app.utils import generate_next_id

router = APIRouter(prefix="/umr", tags=["Upah Minimum Regional"])


@router.get("/tahun/tersedia", response_model=List[int])
def get_tahun_tersedia(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    hasil = db.query(UMR.tahun).distinct().order_by(UMR.tahun).all()
    return [row[0] for row in hasil]


@router.get("/", response_model=PaginatedResponse)
def get_umr(
    tahun: Optional[int] = Query(None),
    kode_provinsi: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    query = (
        db.query(UMR, KabupatenKota, Provinsi)
        .join(KabupatenKota, UMR.kode_kabupaten_kota == KabupatenKota.kode_kabupaten_kota)
        .join(Provinsi, KabupatenKota.kode_provinsi == Provinsi.kode_provinsi)
    )
    if tahun:
        query = query.filter(UMR.tahun == tahun)
    if kode_provinsi:
        query = query.filter(Provinsi.kode_provinsi == kode_provinsi)

    total   = query.count()
    results = query.offset((page - 1) * per_page).limit(per_page).all()

    data = [
        {
            "id"                    : umr.id,
            "kode_kabupaten_kota"   : umr.kode_kabupaten_kota,
            "nama_kabupaten_kota"   : kab.nama_kabupaten_kota,
            "nama_provinsi"         : prov.nama_provinsi,
            "besaran_upah_minimum"  : float(umr.besaran_upah_minimum),
            "satuan"                : umr.satuan,
            "tahun"                 : umr.tahun,
        }
        for umr, kab, prov in results
    ]
    return {"total": total, "page": page, "per_page": per_page, "data": data}


@router.get("/{umr_id}")
def get_umr_by_id(
    umr_id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    result = (
        db.query(UMR, KabupatenKota, Provinsi)
        .join(KabupatenKota, UMR.kode_kabupaten_kota == KabupatenKota.kode_kabupaten_kota)
        .join(Provinsi, KabupatenKota.kode_provinsi == Provinsi.kode_provinsi)
        .filter(UMR.id == umr_id)
        .first()
    )
    if not result:
        raise HTTPException(status_code=404, detail="Data UMR tidak ditemukan.")
    umr, kab, prov = result
    return {
        "id"                   : umr.id,
        "kode_kabupaten_kota"  : umr.kode_kabupaten_kota,
        "nama_kabupaten_kota"  : kab.nama_kabupaten_kota,
        "nama_provinsi"        : prov.nama_provinsi,
        "besaran_upah_minimum" : float(umr.besaran_upah_minimum),
        "satuan"               : umr.satuan,
        "tahun"                : umr.tahun,
    }


@router.post("/", status_code=201)
def create_umr(
    data: UMRCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    # Validasi kabupaten/kota ada
    kab = db.query(KabupatenKota).filter(
        KabupatenKota.kode_kabupaten_kota == data.kode_kabupaten_kota
    ).first()
    if not kab:
        raise HTTPException(
            status_code=400,
            detail=f"Kode kabupaten/kota '{data.kode_kabupaten_kota}' tidak ditemukan."
        )
    # Cek duplikat kombinasi wilayah + tahun
    existing = db.query(UMR).filter(
        UMR.kode_kabupaten_kota == data.kode_kabupaten_kota,
        UMR.tahun == data.tahun
    ).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Data UMR untuk wilayah '{data.kode_kabupaten_kota}' "
                   f"tahun {data.tahun} sudah ada (ID: {existing.id})."
        )
    new_id = generate_next_id(db, "umr", "umr_")
    umr = UMR(
        id=new_id,
        kode_kabupaten_kota=data.kode_kabupaten_kota,
        besaran_upah_minimum=data.besaran_upah_minimum,
        satuan=data.satuan.upper(),
        tahun=data.tahun
    )
    db.add(umr)
    db.commit()
    db.refresh(umr)
    return {"id": umr.id, "message": "Data UMR berhasil ditambahkan."}


@router.put("/{umr_id}")
def update_umr(
    umr_id: str,
    data: UMRUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    umr = db.query(UMR).filter(UMR.id == umr_id).first()
    if not umr:
        raise HTTPException(status_code=404, detail="Data UMR tidak ditemukan.")
    umr.besaran_upah_minimum = data.besaran_upah_minimum
    umr.satuan               = data.satuan.upper()
    db.commit()
    db.refresh(umr)
    return {"id": umr.id, "message": "Data UMR berhasil diperbarui."}


@router.delete("/{umr_id}")
def delete_umr(
    umr_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    umr = db.query(UMR).filter(UMR.id == umr_id).first()
    if not umr:
        raise HTTPException(status_code=404, detail="Data UMR tidak ditemukan.")
    db.delete(umr)
    db.commit()
    return {"message": f"Data UMR '{umr_id}' berhasil dihapus."}