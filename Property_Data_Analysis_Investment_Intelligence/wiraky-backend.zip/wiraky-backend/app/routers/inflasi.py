from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from pydantic import BaseModel
from app.database import get_db
from app.dependencies import get_current_user

router = APIRouter(prefix="/analitik/inflasi", tags=["Inflasi"])


# ── Schema ──────────────────────────────────────────────────────────────────

class InflasiCreate(BaseModel):
    provinsi   : str
    tahun      : int
    bulan      : int
    nilai      : float
    index_base : int

class InflasiUpdate(BaseModel):
    provinsi   : Optional[str]   = None
    tahun      : Optional[int]   = None
    bulan      : Optional[int]   = None
    nilai      : Optional[float] = None
    index_base : Optional[int]   = None


# ── READ ─────────────────────────────────────────────────────────────────────

@router.get("")
def get_inflasi(
    provinsi    : Optional[str] = Query(None),
    tahun       : Optional[int] = Query(None),
    bulan       : Optional[int] = Query(None),
    db          : Session       = Depends(get_db),
    current_user: str           = Depends(get_current_user),
):
    """Mengambil data inflasi bulanan per provinsi."""
    sql = """
        SELECT id, provinsi, tahun, bulan, nilai, index_base
        FROM analitik.inflasi_bulanan
        WHERE 1=1
    """
    params = {}
    if provinsi:
        sql += " AND LOWER(provinsi) LIKE LOWER(:provinsi)"
        params["provinsi"] = f"%{provinsi}%"
    if tahun:
        sql += " AND tahun = :tahun"
        params["tahun"] = tahun
    if bulan:
        sql += " AND bulan = :bulan"
        params["bulan"] = bulan
    sql += " ORDER BY provinsi, tahun, bulan"
    rows = db.execute(text(sql), params).fetchall()
    return [dict(r._mapping) for r in rows]


@router.get("/tahunan")
def get_inflasi_tahunan(
    provinsi    : Optional[str] = Query(None),
    tahun       : Optional[int] = Query(None),
    db          : Session       = Depends(get_db),
    current_user: str           = Depends(get_current_user),
):
    """Mengambil rata-rata inflasi tahunan per provinsi dari view agregasi."""
    sql = """
        SELECT provinsi, tahun, index_base,
               rata_rata_tahunan, inflasi_minimum,
               inflasi_maksimum, jumlah_bulan_data
        FROM analitik.v_inflasi_tahunan
        WHERE 1=1
    """
    params = {}
    if provinsi:
        sql += " AND LOWER(provinsi) LIKE LOWER(:provinsi)"
        params["provinsi"] = f"%{provinsi}%"
    if tahun:
        sql += " AND tahun = :tahun"
        params["tahun"] = tahun
    sql += " ORDER BY provinsi, tahun"
    rows = db.execute(text(sql), params).fetchall()
    return [dict(r._mapping) for r in rows]


@router.get("/{id}")
def get_inflasi_by_id(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Mengambil satu record inflasi berdasarkan ID."""
    row = db.execute(
        text("SELECT id, provinsi, tahun, bulan, nilai, index_base FROM analitik.inflasi_bulanan WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Data inflasi tidak ditemukan")
    return dict(row._mapping)


# ── CREATE ───────────────────────────────────────────────────────────────────

@router.post("/", status_code=201)
def create_inflasi(
    body: InflasiCreate,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    """
    Menambahkan data inflasi bulanan baru.
    """

    payload = body.model_dump()

    new_id = db.execute(
        text("""
            SELECT
                'inflasi_' ||
                (
                    COALESCE(
                        MAX(
                            CAST(REPLACE(id,'inflasi_','') AS INTEGER)
                        ),
                        0
                    ) + 1
                )
            FROM analitik.inflasi_bulanan
        """)
    ).scalar()

    payload["id"] = new_id

    row = db.execute(
        text("""
            INSERT INTO analitik.inflasi_bulanan
            (
                id,
                provinsi,
                tahun,
                bulan,
                nilai,
                index_base
            )
            VALUES
            (
                :id,
                :provinsi,
                :tahun,
                :bulan,
                :nilai,
                :index_base
            )
            RETURNING
                id,
                provinsi,
                tahun,
                bulan,
                nilai,
                index_base
        """),
        payload,
    ).fetchone()

    db.commit()

    return dict(row._mapping)


# ── UPDATE ───────────────────────────────────────────────────────────────────

@router.put("/{id}")
def update_inflasi(
    id          : str,
    body        : InflasiUpdate,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Memperbarui data inflasi bulanan berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.inflasi_bulanan WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data inflasi tidak ditemukan")

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Tidak ada field yang diperbarui")

    set_clause = ", ".join(f"{k} = :{k}" for k in updates)
    updates["id"] = id
    row = db.execute(
        text(f"""
            UPDATE analitik.inflasi_bulanan
            SET {set_clause}
            WHERE id = :id
            RETURNING id, provinsi, tahun, bulan, nilai, index_base
        """),
        updates,
    ).fetchone()
    db.commit()
    return dict(row._mapping)


# ── DELETE ───────────────────────────────────────────────────────────────────

@router.delete("/{id}", status_code=200)
def delete_inflasi(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Menghapus data inflasi bulanan berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.inflasi_bulanan WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data inflasi tidak ditemukan")

    db.execute(text("DELETE FROM analitik.inflasi_bulanan WHERE id = :id"), {"id": id})
    db.commit()
    return {"message": f"Data inflasi ID {id} berhasil dihapus"}