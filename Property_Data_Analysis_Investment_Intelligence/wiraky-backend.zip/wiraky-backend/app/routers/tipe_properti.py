# app/routers/tipe_properti.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import TipeProperti
from app.schemas import TipePropertiResponse, TipePropertiCreate, TipePropertiUpdate
from app.dependencies import get_current_user, require_admin
from app.utils import generate_next_id

router = APIRouter(prefix="/tipe-properti", tags=["Tipe Properti"])


@router.get("/", response_model=List[TipePropertiResponse])
def get_all_tipe_properti(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    return db.query(TipeProperti).order_by(TipeProperti.nama).all()

@router.get("/{tipe_id}", response_model=TipePropertiResponse)
def get_tipe_properti(
    tipe_id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    result = db.query(TipeProperti).filter(TipeProperti.id == tipe_id).first()
    if not result:
        raise HTTPException(status_code=404, detail="Tipe properti tidak ditemukan.")
    return result


@router.post("/", response_model=TipePropertiResponse, status_code=201)
def create_tipe_properti(
    data: TipePropertiCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    existing = db.query(TipeProperti).filter(TipeProperti.nama == data.nama).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Tipe properti '{data.nama}' sudah ada (ID: {existing.id})."
        )
    new_id = generate_next_id(db, "tipe_properti", "tipe_")
    tipe   = TipeProperti(id=new_id, nama=data.nama)
    db.add(tipe)
    db.commit()
    db.refresh(tipe)
    return tipe


@router.put("/{tipe_id}", response_model=TipePropertiResponse)
def update_tipe_properti(
    tipe_id: str,
    data: TipePropertiUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    tipe = db.query(TipeProperti).filter(TipeProperti.id == tipe_id).first()
    if not tipe:
        raise HTTPException(status_code=404, detail="Tipe properti tidak ditemukan.")
    duplicate = db.query(TipeProperti).filter(
        TipeProperti.nama == data.nama,
        TipeProperti.id != tipe_id
    ).first()
    if duplicate:
        raise HTTPException(
            status_code=400,
            detail=f"Nama tipe '{data.nama}' sudah digunakan."
        )
    tipe.nama = data.nama
    db.commit()
    db.refresh(tipe)
    return tipe


@router.delete("/{tipe_id}")
def delete_tipe_properti(
    tipe_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    tipe = db.query(TipeProperti).filter(TipeProperti.id == tipe_id).first()
    if not tipe:
        raise HTTPException(status_code=404, detail="Tipe properti tidak ditemukan.")
    db.delete(tipe)
    db.commit()
    return {"message": f"Tipe properti '{tipe.nama}' berhasil dihapus."}