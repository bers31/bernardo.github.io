# app/routers/auth.py

from fastapi import APIRouter, HTTPException, status
from app.schemas import Token, UserLogin
from app.auth import verify_password, create_access_token

router = APIRouter(prefix="/auth", tags=["Autentikasi"])

# ─────────────────────────────────────────────────────────────────────────────
# Daftar pengguna sistem.
#
# Untuk menghasilkan hash password baru, jalankan perintah berikut di terminal
# (pastikan virtual environment aktif):
#
#   python -c "from passlib.context import CryptContext; \
#              ctx = CryptContext(schemes=['bcrypt'], deprecated='auto'); \
#              print(ctx.hash('PASSWORD_YANG_DIINGINKAN'))"
#
# Kemudian tempel hasilnya ke kolom "hashed_password" di bawah.
# ─────────────────────────────────────────────────────────────────────────────

DUMMY_USERS = {
    "admin": {
        "username"       : "admin",
        "hashed_password": "$2b$12$N0ViRkKfFhfF09CVIhaK7.ZvrD27LRP6WZI9WgeHx7oJPtpkEV/Lq",
        # Password di atas adalah hash dari: Cien@3110
        "role"           : "admin"
    },
    "user": {
        "username"       : "user",
        "hashed_password": "$2b$12$.UEBUaTIprSCSssEUzDgZ.UjRzzlb.wkEUUMDGN9wx12G1nBPjOxC",
        # Ganti nilai di atas dengan hash dari password yang Anda inginkan
        # menggunakan perintah di atas
        "role"           : "user"
    }
}


@router.post("/login", response_model=Token)
def login(credentials: UserLogin):
    """
    Endpoint login. Mengembalikan JWT token yang menyertakan role pengguna.
    Token ini harus disertakan di header setiap request ke endpoint terproteksi.
    """
    user = DUMMY_USERS.get(credentials.username)

    if not user or not verify_password(credentials.password, user["hashed_password"]):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Username atau password salah.",
        )

    token = create_access_token(data={
        "sub" : credentials.username,
        "role": user["role"]
    })
    return {"access_token": token, "token_type": "bearer"}