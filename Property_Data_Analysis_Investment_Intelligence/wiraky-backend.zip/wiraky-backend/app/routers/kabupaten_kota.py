# app/routers/kabupaten_kota.py

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app.models import KabupatenKota, Provinsi
from app.schemas import KabupatenKotaResponse, KabupatenKotaCreate, KabupatenKotaUpdate
from app.dependencies import get_current_user, require_admin

router = APIRouter(prefix="/kabupaten-kota", tags=["Kabupaten & Kota"])


@router.get("/", response_model=List[KabupatenKotaResponse])
def get_all_kabupaten_kota(
    kode_provinsi: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    query = db.query(KabupatenKota)
    if kode_provinsi:
        query = query.filter(KabupatenKota.kode_provinsi == kode_provinsi)
    return query.order_by(KabupatenKota.nama_kabupaten_kota).all()


@router.get("/{kode_kabupaten_kota}", response_model=KabupatenKotaResponse)
def get_kabupaten_kota(
    kode_kabupaten_kota: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    result = db.query(KabupatenKota).filter(
        KabupatenKota.kode_kabupaten_kota == kode_kabupaten_kota
    ).first()
    if not result:
        raise HTTPException(status_code=404, detail="Kabupaten/kota tidak ditemukan.")
    return result


@router.post("/", response_model=KabupatenKotaResponse, status_code=201)
def create_kabupaten_kota(
    data: KabupatenKotaCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    # Validasi provinsi induk ada
    provinsi = db.query(Provinsi).filter(
        Provinsi.kode_provinsi == data.kode_provinsi
    ).first()
    if not provinsi:
        raise HTTPException(
            status_code=400,
            detail=f"Kode provinsi '{data.kode_provinsi}' tidak ditemukan."
        )
    existing = db.query(KabupatenKota).filter(
        KabupatenKota.kode_kabupaten_kota == data.kode_kabupaten_kota
    ).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Kode kabupaten/kota '{data.kode_kabupaten_kota}' sudah ada."
        )
    kab = KabupatenKota(
        kode_kabupaten_kota=data.kode_kabupaten_kota,
        nama_kabupaten_kota=data.nama_kabupaten_kota.upper(),
        kode_provinsi=data.kode_provinsi
    )
    db.add(kab)
    db.commit()
    db.refresh(kab)
    return kab


@router.put("/{kode_kabupaten_kota}", response_model=KabupatenKotaResponse)
def update_kabupaten_kota(
    kode_kabupaten_kota: str,
    data: KabupatenKotaUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    kab = db.query(KabupatenKota).filter(
        KabupatenKota.kode_kabupaten_kota == kode_kabupaten_kota
    ).first()
    if not kab:
        raise HTTPException(status_code=404, detail="Kabupaten/kota tidak ditemukan.")
    provinsi = db.query(Provinsi).filter(
        Provinsi.kode_provinsi == data.kode_provinsi
    ).first()
    if not provinsi:
        raise HTTPException(
            status_code=400,
            detail=f"Kode provinsi '{data.kode_provinsi}' tidak ditemukan."
        )
    kab.nama_kabupaten_kota = data.nama_kabupaten_kota.upper()
    kab.kode_provinsi       = data.kode_provinsi
    db.commit()
    db.refresh(kab)
    return kab


@router.delete("/{kode_kabupaten_kota}")
def delete_kabupaten_kota(
    kode_kabupaten_kota: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    kab = db.query(KabupatenKota).filter(
        KabupatenKota.kode_kabupaten_kota == kode_kabupaten_kota
    ).first()
    if not kab:
        raise HTTPException(status_code=404, detail="Kabupaten/kota tidak ditemukan.")
    db.delete(kab)
    db.commit()
    return {"message": f"Kabupaten/kota '{kab.nama_kabupaten_kota}' berhasil dihapus."}