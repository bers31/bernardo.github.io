from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from pydantic import BaseModel
from app.database import get_db
from app.dependencies import get_current_user

router = APIRouter(prefix="/analitik/pdb", tags=["PDB"])


# ── Schema ──────────────────────────────────────────────────────────────────

class PDBCreate(BaseModel):
    komponen         : str
    level            : str
    laju_pertumbuhan : str
    tahun            : int
    kuartal          : str
    nilai            : float

class PDBUpdate(BaseModel):
    komponen         : Optional[str]   = None
    level            : Optional[str]   = None
    laju_pertumbuhan : Optional[str]   = None
    tahun            : Optional[int]   = None
    kuartal          : Optional[str]   = None
    nilai            : Optional[float] = None


# ── READ ─────────────────────────────────────────────────────────────────────

@router.get("")
def get_pdb(
    komponen        : Optional[str] = Query(None),
    level           : Optional[str] = Query(None),
    laju_pertumbuhan: Optional[str] = Query(None),
    tahun           : Optional[int] = Query(None),
    kuartal         : Optional[str] = Query(None),
    db              : Session       = Depends(get_db),
    current_user    : str           = Depends(get_current_user),
):
    """Mengambil data laju pertumbuhan PDB."""
    sql = """
        SELECT id, komponen, level, laju_pertumbuhan, tahun, kuartal, nilai
        FROM analitik.pdb_pertumbuhan
        WHERE 1=1
    """
    params = {}
    if komponen:
        sql += " AND LOWER(komponen) LIKE LOWER(:komponen)"
        params["komponen"] = f"%{komponen}%"
    if level:
        sql += " AND LOWER(level) = LOWER(:level)"
        params["level"] = level
    if laju_pertumbuhan:
        sql += " AND LOWER(laju_pertumbuhan) = LOWER(:laju)"
        params["laju"] = laju_pertumbuhan
    if tahun:
        sql += " AND tahun = :tahun"
        params["tahun"] = tahun
    if kuartal:
        sql += " AND UPPER(kuartal) = UPPER(:kuartal)"
        params["kuartal"] = kuartal
    sql += " ORDER BY tahun, kuartal, komponen"
    rows = db.execute(text(sql), params).fetchall()
    return [dict(r._mapping) for r in rows]

@router.get("/komponen-tersedia")
def get_komponen_tersedia(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    rows = db.execute(
        text("""
            SELECT DISTINCT komponen
            FROM analitik.pdb_pertumbuhan
            ORDER BY komponen
        """)
    ).fetchall()

    return [
        {"komponen": r.komponen}
        for r in rows
    ]

@router.get("/laju-tersedia")
def get_laju_tersedia(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    rows = db.execute(
        text("""
            SELECT DISTINCT laju_pertumbuhan
            FROM analitik.pdb_pertumbuhan
            ORDER BY laju_pertumbuhan
        """)
    ).fetchall()

    return [
        r.laju_pertumbuhan
        for r in rows
    ]

@router.get("/{id}")
def get_pdb_by_id(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Mengambil satu record PDB berdasarkan ID."""
    row = db.execute(
        text("""
            SELECT id, komponen, level, laju_pertumbuhan, tahun, kuartal, nilai
            FROM analitik.pdb_pertumbuhan
            WHERE id = :id
        """),
        {"id": id},
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Data PDB tidak ditemukan")
    return dict(row._mapping)


# ── CREATE ───────────────────────────────────────────────────────────────────

@router.post("/", status_code=201)
def create_pdb(
    body        : PDBCreate,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Menambahkan data PDB baru."""
    row = db.execute(
        text("""
            INSERT INTO analitik.pdb_pertumbuhan
                (komponen, level, laju_pertumbuhan, tahun, kuartal, nilai)
            VALUES
                (:komponen, :level, :laju_pertumbuhan, :tahun, :kuartal, :nilai)
            RETURNING id, komponen, level, laju_pertumbuhan, tahun, kuartal, nilai
        """),
        body.model_dump(),
    ).fetchone()
    db.commit()
    return dict(row._mapping)


# ── UPDATE ───────────────────────────────────────────────────────────────────

@router.put("/{id}")
def update_pdb(
    id          : str,
    body        : PDBUpdate,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Memperbarui data PDB berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.pdb_pertumbuhan WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data PDB tidak ditemukan")

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Tidak ada field yang diperbarui")

    set_clause = ", ".join(f"{k} = :{k}" for k in updates)
    updates["id"] = id
    row = db.execute(
        text(f"""
            UPDATE analitik.pdb_pertumbuhan
            SET {set_clause}
            WHERE id = :id
            RETURNING id, komponen, level, laju_pertumbuhan, tahun, kuartal, nilai
        """),
        updates,
    ).fetchone()
    db.commit()
    return dict(row._mapping)


# ── DELETE ───────────────────────────────────────────────────────────────────

@router.delete("/{id}", status_code=200)
def delete_pdb(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Menghapus data PDB berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.pdb_pertumbuhan WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data PDB tidak ditemukan")

    db.execute(text("DELETE FROM analitik.pdb_pertumbuhan WHERE id = :id"), {"id": id})
    db.commit()
    return {"message": f"Data PDB ID {id} berhasil dihapus"}