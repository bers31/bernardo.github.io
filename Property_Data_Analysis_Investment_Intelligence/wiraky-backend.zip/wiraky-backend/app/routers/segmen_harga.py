# app/routers/segmen_harga.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import SegmenHarga
from app.schemas import SegmenHargaResponse, SegmenHargaCreate, SegmenHargaUpdate
from app.dependencies import get_current_user, require_admin
from app.utils import generate_next_id

router = APIRouter(prefix="/segmen-harga", tags=["Segmen Harga"])


@router.get("/", response_model=List[SegmenHargaResponse])
def get_all_segmen_harga(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    return db.query(SegmenHarga).order_by(SegmenHarga.nama).all()


@router.get("/{segmen_id}", response_model=SegmenHargaResponse)
def get_segmen_harga(
    segmen_id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    result = db.query(SegmenHarga).filter(SegmenHarga.id == segmen_id).first()
    if not result:
        raise HTTPException(status_code=404, detail="Segmen harga tidak ditemukan.")
    return result


@router.post("/", response_model=SegmenHargaResponse, status_code=201)
def create_segmen_harga(
    data: SegmenHargaCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    existing = db.query(SegmenHarga).filter(SegmenHarga.nama == data.nama).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Segmen harga '{data.nama}' sudah ada (ID: {existing.id})."
        )
    new_id  = generate_next_id(db, "segmen_harga", "segmen_")
    segmen  = SegmenHarga(id=new_id, nama=data.nama)
    db.add(segmen)
    db.commit()
    db.refresh(segmen)
    return segmen


@router.put("/{segmen_id}", response_model=SegmenHargaResponse)
def update_segmen_harga(
    segmen_id: str,
    data: SegmenHargaUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    segmen = db.query(SegmenHarga).filter(SegmenHarga.id == segmen_id).first()
    if not segmen:
        raise HTTPException(status_code=404, detail="Segmen harga tidak ditemukan.")
    duplicate = db.query(SegmenHarga).filter(
        SegmenHarga.nama == data.nama,
        SegmenHarga.id != segmen_id
    ).first()
    if duplicate:
        raise HTTPException(
            status_code=400,
            detail=f"Nama segmen '{data.nama}' sudah digunakan."
        )
    segmen.nama = data.nama
    db.commit()
    db.refresh(segmen)
    return segmen


@router.delete("/{segmen_id}")
def delete_segmen_harga(
    segmen_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    segmen = db.query(SegmenHarga).filter(SegmenHarga.id == segmen_id).first()
    if not segmen:
        raise HTTPException(status_code=404, detail="Segmen harga tidak ditemukan.")
    db.delete(segmen)
    db.commit()
    return {"message": f"Segmen harga '{segmen.nama}' berhasil dihapus."}