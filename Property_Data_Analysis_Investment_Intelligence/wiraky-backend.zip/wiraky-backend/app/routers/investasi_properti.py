from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from app.database import get_db
from app.dependencies import get_current_user

router = APIRouter(prefix="/analitik/investasi-properti", tags=["Investasi Properti"])

# Catatan: endpoint ini bersifat read-only karena berbasis view agregasi
# (analitik.v_investasi_properti). Untuk mutasi data, gunakan router
# masing-masing entitas (properti, inflasi, ihpr, bi-rate, sensus).


@router.get("")
def get_investasi_properti(
    kota        : Optional[str] = Query(None),
    tipe        : Optional[str] = Query(None),
    segmen      : Optional[str] = Query(None),
    harga_min   : Optional[int] = Query(None),
    harga_max   : Optional[int] = Query(None),
    db          : Session       = Depends(get_db),
    current_user: str           = Depends(get_current_user),
):
    """
    View analitik investasi utama — menggabungkan data properti
    dengan data makroekonomi (IHPR, inflasi, BI Rate, populasi).
    """
    sql = """
        SELECT
            properti_id, harga, kamar_tidur, kamar_mandi,
            luas_tanah_m2, luas_bangunan_m2,
            nama_area, kabupaten_kota, tipe_properti, segmen_harga,
            kode_provinsi, nama_provinsi,
            ihpr_terbaru, ihpr_kuartal, ihpr_tahun, ihpr_pct_perubahan,
            inflasi_tahunan_terbaru, inflasi_tahun,
            bi_rate_terkini,
            total_populasi, sensus_tahun,
            harga_per_m2_tanah
        FROM analitik.v_investasi_properti
        WHERE 1=1
    """
    params = {}
    if kota:
        sql += " AND LOWER(kabupaten_kota) LIKE LOWER(:kota)"
        params["kota"] = f"%{kota}%"
    if tipe:
        sql += " AND LOWER(tipe_properti) LIKE LOWER(:tipe)"
        params["tipe"] = f"%{tipe}%"
    if segmen:
        sql += " AND LOWER(segmen_harga) LIKE LOWER(:segmen)"
        params["segmen"] = f"%{segmen}%"
    if harga_min:
        sql += " AND harga >= :harga_min"
        params["harga_min"] = harga_min
    if harga_max:
        sql += " AND harga <= :harga_max"
        params["harga_max"] = harga_max
    sql += " ORDER BY kabupaten_kota, harga DESC"
    rows = db.execute(text(sql), params).mappings().all()
    return [
        {
            **r,
            "ihpr_terbaru"           : float(r["ihpr_terbaru"])            if r["ihpr_terbaru"]            else None,
            "ihpr_pct_perubahan"     : float(r["ihpr_pct_perubahan"])      if r["ihpr_pct_perubahan"]      else None,
            "inflasi_tahunan_terbaru": float(r["inflasi_tahunan_terbaru"]) if r["inflasi_tahunan_terbaru"] else None,
            "bi_rate_terkini"        : float(r["bi_rate_terkini"])         if r["bi_rate_terkini"]         else None,
            "harga_per_m2_tanah"     : float(r["harga_per_m2_tanah"])      if r["harga_per_m2_tanah"]      else None,
        }
        for r in rows
    ]


@router.get("/ringkasan")
def get_investasi_properti_ringkasan(
    kota        : Optional[str] = Query(None),
    db          : Session       = Depends(get_db),
    current_user: str           = Depends(get_current_user),
):
    """
    Ringkasan statistik investasi properti per kota:
    jumlah listing, rata-rata harga, rata-rata harga/m², dan IHPR terkini.
    """
    sql = """
        SELECT
            kabupaten_kota,
            nama_provinsi,
            COUNT(*)                        AS jumlah_listing,
            ROUND(AVG(harga))               AS rata_rata_harga,
            ROUND(AVG(harga_per_m2_tanah))  AS rata_rata_harga_per_m2,
            MAX(ihpr_terbaru)               AS ihpr_terbaru,
            MAX(ihpr_pct_perubahan)         AS ihpr_pct_perubahan,
            MAX(inflasi_tahunan_terbaru)    AS inflasi_tahunan_terbaru,
            MAX(bi_rate_terkini)            AS bi_rate_terkini,
            MAX(total_populasi)             AS total_populasi
        FROM analitik.v_investasi_properti
        WHERE 1=1
    """
    params = {}
    if kota:
        sql += " AND LOWER(kabupaten_kota) LIKE LOWER(:kota)"
        params["kota"] = f"%{kota}%"
    sql += " GROUP BY kabupaten_kota, nama_provinsi ORDER BY jumlah_listing DESC"
    rows = db.execute(text(sql), params).mappings().all()
    return [
        {
            **r,
            "ihpr_terbaru"           : float(r["ihpr_terbaru"])            if r["ihpr_terbaru"]            else None,
            "ihpr_pct_perubahan"     : float(r["ihpr_pct_perubahan"])      if r["ihpr_pct_perubahan"]      else None,
            "inflasi_tahunan_terbaru": float(r["inflasi_tahunan_terbaru"]) if r["inflasi_tahunan_terbaru"] else None,
            "bi_rate_terkini"        : float(r["bi_rate_terkini"])         if r["bi_rate_terkini"]         else None,
        }
        for r in rows
    ]


@router.get("/segmen")
def get_investasi_properti_per_segmen(
    kota        : Optional[str] = Query(None),
    db          : Session       = Depends(get_db),
    current_user: str           = Depends(get_current_user),
):
    """Distribusi properti berdasarkan segmen harga per kota."""
    sql = """
        SELECT
            kabupaten_kota,
            segmen_harga,
            COUNT(*)           AS jumlah,
            ROUND(AVG(harga))  AS rata_rata_harga,
            MIN(harga)         AS harga_terendah,
            MAX(harga)         AS harga_tertinggi
        FROM analitik.v_investasi_properti
        WHERE 1=1
    """
    params = {}
    if kota:
        sql += " AND LOWER(kabupaten_kota) LIKE LOWER(:kota)"
        params["kota"] = f"%{kota}%"
    sql += """
    GROUP BY kabupaten_kota, segmen_harga
    ORDER BY kabupaten_kota, segmen_harga
    """
    rows = db.execute(text(sql), params).mappings().all()
    return [dict(r) for r in rows]