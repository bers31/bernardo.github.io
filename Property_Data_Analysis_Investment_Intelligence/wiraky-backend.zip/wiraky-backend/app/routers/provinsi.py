# app/routers/provinsi.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import Provinsi
from app.schemas import ProvinsiResponse, ProvinsiCreate, ProvinsiUpdate
from app.dependencies import get_current_user, require_admin

router = APIRouter(prefix="/provinsi", tags=["Provinsi"])


@router.get("/", response_model=List[ProvinsiResponse])
def get_all_provinsi(
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    return db.query(Provinsi).order_by(Provinsi.nama_provinsi).all()


@router.get("/{kode_provinsi}", response_model=ProvinsiResponse)
def get_provinsi(
    kode_provinsi: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    provinsi = db.query(Provinsi).filter(
        Provinsi.kode_provinsi == kode_provinsi
    ).first()
    if not provinsi:
        raise HTTPException(status_code=404, detail="Provinsi tidak ditemukan.")
    return provinsi


@router.post("/", response_model=ProvinsiResponse, status_code=201)
def create_provinsi(
    data: ProvinsiCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    existing = db.query(Provinsi).filter(
        Provinsi.kode_provinsi == data.kode_provinsi
    ).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Kode provinsi '{data.kode_provinsi}' sudah ada."
        )
    provinsi = Provinsi(
        kode_provinsi=data.kode_provinsi,
        nama_provinsi=data.nama_provinsi.upper()
    )
    db.add(provinsi)
    db.commit()
    db.refresh(provinsi)
    return provinsi


@router.put("/{kode_provinsi}", response_model=ProvinsiResponse)
def update_provinsi(
    kode_provinsi: str,
    data: ProvinsiUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    provinsi = db.query(Provinsi).filter(
        Provinsi.kode_provinsi == kode_provinsi
    ).first()
    if not provinsi:
        raise HTTPException(status_code=404, detail="Provinsi tidak ditemukan.")
    provinsi.nama_provinsi = data.nama_provinsi.upper()
    db.commit()
    db.refresh(provinsi)
    return provinsi


@router.delete("/{kode_provinsi}")
def delete_provinsi(
    kode_provinsi: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    provinsi = db.query(Provinsi).filter(
        Provinsi.kode_provinsi == kode_provinsi
    ).first()
    if not provinsi:
        raise HTTPException(status_code=404, detail="Provinsi tidak ditemukan.")
    db.delete(provinsi)
    db.commit()
    return {"message": f"Provinsi '{provinsi.nama_provinsi}' berhasil dihapus."}