from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from pydantic import BaseModel
from app.database import get_db
from app.dependencies import get_current_user

router = APIRouter(prefix="/analitik/sensus", tags=["Sensus Penduduk"])


# ── Schema ──────────────────────────────────────────────────────────────────

class SensusCreate(BaseModel):
    provinsi : str
    tahun    : int
    status   : str
    gender   : str
    nilai    : int


class SensusUpdate(BaseModel):
    provinsi : Optional[str] = None
    tahun    : Optional[int] = None
    status   : Optional[str] = None
    gender   : Optional[str] = None
    nilai    : Optional[int] = None


# ── READ ─────────────────────────────────────────────────────────────────────

@router.get("")
def get_sensus(
    provinsi: Optional[str] = Query(None),
    tahun: Optional[int] = Query(None),
    status: Optional[str] = Query(None),
    gender: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):

    sql="""
        SELECT
            id,
            provinsi,
            tahun,
            status,
            gender,
            nilai
        FROM analitik.sensus_penduduk
        WHERE 1=1
    """

    params={}

    if provinsi:
        sql+=" AND LOWER(provinsi) LIKE LOWER(:provinsi)"
        params["provinsi"]=f"%{provinsi}%"

    if tahun:
        sql+=" AND tahun=:tahun"
        params["tahun"]=tahun

    if status:
        sql+=" AND LOWER(status)=LOWER(:status)"
        params["status"]=status

    if gender:
        sql+=" AND LOWER(gender)=LOWER(:gender)"
        params["gender"]=gender

    rows=db.execute(text(sql),params).fetchall()

    return [dict(r._mapping) for r in rows]

@router.get("/{id}")
def get_sensus_by_id(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Mengambil satu record sensus berdasarkan ID."""
    row = db.execute(
        text("""
            SELECT id, provinsi, tahun, status, gender, nilai
            FROM analitik.sensus_penduduk
            WHERE id = :id
        """),
        {"id": id},
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Data sensus tidak ditemukan")
    return dict(row._mapping)


# ── CREATE ───────────────────────────────────────────────────────────────────

@router.post("/", status_code=201)
def create_sensus(
    body        : SensusCreate,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Menambahkan data sensus penduduk baru."""
    row = db.execute(
        text("""
            INSERT INTO analitik.sensus_penduduk
            (
                provinsi,
                tahun,
                status,
                gender,
                nilai
            )
            VALUES
            (
                :provinsi,
                :tahun,
                :status,
                :gender,
                :nilai
            )
            RETURNING
                id,
                provinsi,
                tahun,
                status,
                gender,
                nilai
        """),
        body.model_dump(),
    ).fetchone()
    db.commit()
    return dict(row._mapping)


# ── UPDATE ───────────────────────────────────────────────────────────────────

@router.put("/{id}")
def update_sensus(
    id          : str,
    body        : SensusUpdate,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Memperbarui data sensus berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.sensus_penduduk WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data sensus tidak ditemukan")

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Tidak ada field yang diperbarui")

    set_clause = ", ".join(f"{k} = :{k}" for k in updates)
    updates["id"] = id
    row = db.execute(
        text(f"""
            UPDATE analitik.sensus_penduduk
            SET {set_clause}
            WHERE id = :id
            RETURNING id, provinsi, tahun, status, gender, nilai
        """),
        updates,
    ).fetchone()
    db.commit()
    return dict(row._mapping)


# ── DELETE ───────────────────────────────────────────────────────────────────

@router.delete("/{id}", status_code=200)
def delete_sensus(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Menghapus data sensus berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.sensus_penduduk WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data sensus tidak ditemukan")

    db.execute(text("DELETE FROM analitik.sensus_penduduk WHERE id = :id"), {"id": id})
    db.commit()
    return {"message": f"Data sensus ID {id} berhasil dihapus"}