from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from pydantic import BaseModel
from app.database import get_db
from app.dependencies import get_current_user
from sqlalchemy.exc import IntegrityError

router = APIRouter(prefix="/analitik/ihpr", tags=["IHPR"])

# Mapping index_base → tabel fisik
TABLE_MAP = {
    2002: "analitik.ihpr_2002",
    2018: "analitik.ihpr_2018",
}

def get_table(index_base: int):
    table = TABLE_MAP.get(index_base)

    if not table:
        raise HTTPException(
            status_code=400,
            detail="index_base harus 2002 atau 2018"
        )

    return table


# ── Schema ──────────────────────────────────────────────────────────────────

class IHPRCreate(BaseModel):
    kota       : str
    tipe       : str
    tahun      : int
    kuartal    : str
    nilai      : float
    index_base : int

class IHPRUpdate(BaseModel):
    kota       : Optional[str]   = None
    tipe       : Optional[str]   = None
    tahun      : Optional[int]   = None
    kuartal    : Optional[str]   = None
    nilai      : Optional[float] = None
    index_base : Optional[int]   = None

# ── READ ─────────────────────────────────────────────────────────────────────

@router.get("")
def get_ihpr(
    kota       : Optional[str] = Query(None),
    tipe       : Optional[str] = Query(None),
    tahun      : Optional[int] = Query(None),
    index_base : Optional[int] = Query(None),
    db         : Session       = Depends(get_db),
    current_user: str          = Depends(get_current_user),
):
    # Tentukan tabel mana yang di-query
    tables = []
    if index_base == 2018 or index_base is None:
        tables.append(("analitik.ihpr_2018", 2018))
    if index_base == 2002 or index_base is None:
        tables.append(("analitik.ihpr_2002", 2002))

    all_rows = []
    for table, base in tables:
        sql = f"""
            SELECT
                id, id AS row_id, kota, tipe, tahun, kuartal, nilai, {base} AS index_base
            FROM {table}
            WHERE 1=1
        """
        params = {}
        if kota:
            sql += " AND LOWER(kota) LIKE LOWER(:kota)"
            params["kota"] = f"%{kota}%"
        if tipe:
            sql += " AND LOWER(tipe) LIKE LOWER(:tipe)"
            params["tipe"] = f"%{tipe}%"
        if tahun:
            sql += " AND tahun = :tahun"
            params["tahun"] = tahun

        rows = db.execute(text(sql), params).fetchall()
        all_rows.extend([dict(r._mapping) for r in rows])

    return all_rows


@router.get("/tren")
def get_ihpr_tren(
    kota        : Optional[str] = Query(None),
    tipe        : Optional[str] = Query(None),
    index_base  : Optional[int] = Query(2018),
    db          : Session       = Depends(get_db),
    current_user: str           = Depends(get_current_user),
):
    """
    Mengambil tren IHPR dengan persentase perubahan antar kuartal.
    Berguna untuk analisis momentum harga properti.
    """
    sql = """
        SELECT kota, tipe, tahun, kuartal, nilai,
               index_base, nilai_sebelumnya, pct_perubahan_qtq
        FROM analitik.v_ihpr_tren
        WHERE 1=1
    """
    params = {}
    if kota:
        sql += " AND LOWER(kota) LIKE LOWER(:kota)"
        params["kota"] = f"%{kota}%"
    if tipe:
        sql += " AND LOWER(tipe) LIKE LOWER(:tipe)"
        params["tipe"] = f"%{tipe}%"
    if index_base:
        sql += " AND index_base = :index_base"
        params["index_base"] = index_base
    rows = db.execute(text(sql), params).fetchall()
    return [dict(r._mapping) for r in rows]


@router.get("/kota-tersedia")
def get_ihpr_kota_tersedia(
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Mengambil daftar kota yang tersedia di data IHPR."""
    rows = db.execute(
        text("SELECT DISTINCT kota FROM analitik.v_ihpr_gabungan ORDER BY kota")
    ).fetchall()
    return [r[0] for r in rows]


@router.get("/{id}")
def get_ihpr_by_id(
    id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    """
    Mengambil satu data IHPR berdasarkan ID asli.
    Contoh ID:
    - ihpr_2018_1
    - ihpr_2002_15
    """

    if id.startswith("ihpr_2018_"):
        table = "analitik.ihpr_2018"
        index_base = 2018

    elif id.startswith("ihpr_2002_"):
        table = "analitik.ihpr_2002"
        index_base = 2002

    else:
        raise HTTPException(
            status_code=400,
            detail="Format ID tidak valid."
        )

    row = db.execute(
        text(f"""
            SELECT
                id,
                kota,
                tipe,
                tahun,
                kuartal,
                nilai
            FROM {table}
            WHERE id = :id
        """),
        {"id": id},
    ).fetchone()

    if not row:
        raise HTTPException(
            status_code=404,
            detail="Data IHPR tidak ditemukan."
        )

    result = dict(row._mapping)
    result["index_base"] = index_base

    return result


# ── CREATE ───────────────────────────────────────────────────────────────────

@router.post("/", status_code=201)
def create_ihpr(
    body: IHPRCreate,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):
    """
    Menambahkan data IHPR baru.
    Data akan disimpan ke tabel sesuai index_base.
    """

    table = get_table(body.index_base)

    payload = body.model_dump()
    payload.pop("index_base")

    # Generate ID baru
    if body.index_base == 2018:

        new_id = db.execute(
            text("""
                SELECT
                    'ihpr_2018_' ||
                    (
                        COALESCE(
                            MAX(
                                CAST(REPLACE(id, 'ihpr_2018_', '') AS INTEGER)
                            ),
                            0
                        ) + 1
                    )
                FROM analitik.ihpr_2018
            """)
        ).scalar()

    else:

        new_id = db.execute(
            text("""
                SELECT
                    'ihpr_2002_' ||
                    (
                        COALESCE(
                            MAX(
                                CAST(REPLACE(id, 'ihpr_2002_', '') AS INTEGER)
                            ),
                            0
                        ) + 1
                    )
                FROM analitik.ihpr_2002
            """)
        ).scalar()

    payload["id"] = new_id

    try:

        row = db.execute(
            text(f"""
                INSERT INTO {table}
                (
                    id,
                    kota,
                    tipe,
                    tahun,
                    kuartal,
                    nilai
                )
                VALUES
                (
                    :id,
                    :kota,
                    :tipe,
                    :tahun,
                    :kuartal,
                    :nilai
                )
                RETURNING
                    id,
                    kota,
                    tipe,
                    tahun,
                    kuartal,
                    nilai
            """),
            payload,
        ).fetchone()

        db.commit()

    except IntegrityError:

        db.rollback()

        raise HTTPException(
            status_code=409,
            detail=(
                f"Data sudah ada: "
                f"{body.kota} | "
                f"{body.tipe} | "
                f"{body.kuartal} {body.tahun} "
                f"(seri {body.index_base}). "
                f"Gunakan fitur Edit untuk memperbarui nilainya."
            ),
        )

    result = dict(row._mapping)
    result["row_id"] = result["id"]
    result["index_base"] = body.index_base

    return result


# ── UPDATE ───────────────────────────────────────────────────────────────────

@router.put("/{row_id}")
def update_ihpr(
    row_id: str,
    body: IHPRUpdate,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):

    if row_id.startswith("ihpr_2018_"):
        table = "analitik.ihpr_2018"
    elif row_id.startswith("ihpr_2002_"):
        table = "analitik.ihpr_2002"
    else:
        raise HTTPException(
            status_code=400,
            detail="Format ID tidak valid"
        )

    updates = body.model_dump(exclude_none=True)
    updates.pop("index_base", None)

    if not updates:
        raise HTTPException(
            status_code=400,
            detail="Tidak ada perubahan"
        )

    updates["id"] = row_id

    set_clause = ", ".join(
        f"{k}=:{k}"
        for k in updates
        if k != "id"
    )

    row = db.execute(
        text(f"""
            UPDATE {table}
            SET {set_clause}
            WHERE id=:id
            RETURNING
                id,
                kota,
                tipe,
                tahun,
                kuartal,
                nilai
        """),
        updates,
    ).fetchone()

    if not row:
        raise HTTPException(
            status_code=404,
            detail="Data tidak ditemukan"
        )

    db.commit()

    result = dict(row._mapping)
    result["row_id"] = result["id"]
    result["index_base"] = 2018 if table.endswith("2018") else 2002

    return result

# ── DELETE ───────────────────────────────────────────────────────────────────

@router.delete("/{row_id}")
def delete_ihpr(
    row_id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user),
):

    if row_id.startswith("ihpr_2018_"):
        table = "analitik.ihpr_2018"
    elif row_id.startswith("ihpr_2002_"):
        table = "analitik.ihpr_2002"
    else:
        raise HTTPException(
            status_code=400,
            detail="Format ID tidak valid"
        )

    deleted = db.execute(
        text(f"""
            DELETE FROM {table}
            WHERE id=:id
            RETURNING id
        """),
        {"id": row_id},
    ).fetchone()

    if not deleted:
        raise HTTPException(
            status_code=404,
            detail="Data tidak ditemukan"
        )

    db.commit()

    return {
        "message": "Berhasil dihapus"
    }