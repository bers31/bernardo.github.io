# app/routers/properti.py

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Optional
from app.database import get_db
from app.models import Properti, Area, TipeProperti, SegmenHarga
from app.schemas import PaginatedResponse, PropertiCreate, PropertiUpdate
from app.dependencies import get_current_user, require_admin
from app.utils import generate_next_id

router = APIRouter(prefix="/properti", tags=["Properti"])


def safe_float(value):
    try:
        if value is None:
            return None
        result = float(value)
        return None if result != result else result  # NaN check
    except Exception:
        return None


def serialize_properti(prop, area, tipe_obj, segmen_obj) -> dict:
    lt = safe_float(prop.luas_tanah_m2)
    lb = safe_float(prop.luas_bangunan_m2)
    try:
        harga_per_m2_tanah    = round(prop.harga / lt, 0) if lt and lt > 0 else None
    except Exception:
        harga_per_m2_tanah    = None
    try:
        harga_per_m2_bangunan = round(prop.harga / lb, 0) if lb and lb > 0 else None
    except Exception:
        harga_per_m2_bangunan = None
    try:
        rasio_bangunan_tanah  = round(lb / lt, 4) if lt and lt > 0 and lb else None
    except Exception:
        rasio_bangunan_tanah  = None
    return {
        "id"                   : prop.id,
        "harga"                : prop.harga,
        "deskripsi"            : prop.deskripsi,
        "kamar_tidur"          : prop.kamar_tidur,
        "kamar_mandi"          : prop.kamar_mandi,
        "carport"              : prop.carport,
        "tahun"                : prop.tahun, 
        "luas_tanah_m2"        : lt,
        "luas_bangunan_m2"     : lb,
        "area_id"              : prop.area_id,
        "nama_area"            : area.nama_area if area else None,
        "kabupaten_kota"       : area.kabupaten_kota if area else None,
        "keyword"              : prop.keyword,
        "tipe_properti_id"     : prop.tipe_properti_id,
        "tipe_properti"        : tipe_obj.nama if tipe_obj else None,
        "segmen_harga_id"      : prop.segmen_harga_id,
        "segmen_harga"         : segmen_obj.nama if segmen_obj else None,
        "harga_per_m2_tanah"   : harga_per_m2_tanah,
        "harga_per_m2_bangunan": harga_per_m2_bangunan,
        "rasio_bangunan_tanah" : rasio_bangunan_tanah,
    }


def build_query(db, kota, tipe, segmen, harga_min, harga_max, kamar_tidur_min):
    query = (
        db.query(Properti, Area, TipeProperti, SegmenHarga)
        .outerjoin(Area, Properti.area_id == Area.area_id)
        .outerjoin(TipeProperti, Properti.tipe_properti_id == TipeProperti.id)
        .outerjoin(SegmenHarga, Properti.segmen_harga_id == SegmenHarga.id)
    )
    if kota:            query = query.filter(Area.kabupaten_kota.ilike(f"%{kota}%"))
    if tipe:            query = query.filter(TipeProperti.nama.ilike(f"%{tipe}%"))
    if segmen:          query = query.filter(SegmenHarga.nama.ilike(f"%{segmen}%"))
    if harga_min:       query = query.filter(Properti.harga >= harga_min)
    if harga_max:       query = query.filter(Properti.harga <= harga_max)
    if kamar_tidur_min: query = query.filter(Properti.kamar_tidur >= kamar_tidur_min)
    return query


# ── READ ─────────────────────────────────────────────────────────────────────

@router.get("/semua", summary="Ambil semua properti tanpa batas untuk analitik")
def get_semua_properti(
    kota: Optional[str] = Query(None),
    tipe: Optional[str] = Query(None),
    segmen: Optional[str] = Query(None),
    harga_min: Optional[int] = Query(None),
    harga_max: Optional[int] = Query(None),
    kamar_tidur_min: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    results = build_query(db, kota, tipe, segmen, harga_min, harga_max, kamar_tidur_min).all()
    return [serialize_properti(p, a, t, s) for p, a, t, s in results]


@router.get("/", response_model=PaginatedResponse)
def get_properti(
    kota: Optional[str] = Query(None),
    tipe: Optional[str] = Query(None),
    segmen: Optional[str] = Query(None),
    harga_min: Optional[int] = Query(None),
    harga_max: Optional[int] = Query(None),
    kamar_tidur_min: Optional[int] = Query(None),
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    query   = build_query(db, kota, tipe, segmen, harga_min, harga_max, kamar_tidur_min)
    total   = query.count()
    results = query.offset((page - 1) * per_page).limit(per_page).all()
    return {
        "total"   : total,
        "page"    : page,
        "per_page": per_page,
        "data"    : [serialize_properti(p, a, t, s) for p, a, t, s in results]
    }


@router.get("/{properti_id}")
def get_properti_detail(
    properti_id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    result = (
        build_query(db, None, None, None, None, None, None)
        .filter(Properti.id == properti_id)
        .first()
    )
    if not result:
        raise HTTPException(status_code=404, detail="Properti tidak ditemukan.")
    return serialize_properti(*result)


# ── CREATE ───────────────────────────────────────────────────────────────────

@router.post("/", status_code=201)
def create_properti(
    data: PropertiCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    # Validasi FK jika disertakan
    if data.area_id:
        if not db.query(Area).filter(Area.area_id == data.area_id).first():
            raise HTTPException(status_code=400, detail=f"Area ID '{data.area_id}' tidak ditemukan.")
    if data.tipe_properti_id:
        if not db.query(TipeProperti).filter(TipeProperti.id == data.tipe_properti_id).first():
            raise HTTPException(status_code=400, detail=f"Tipe properti ID '{data.tipe_properti_id}' tidak ditemukan.")
    if data.segmen_harga_id:
        if not db.query(SegmenHarga).filter(SegmenHarga.id == data.segmen_harga_id).first():
            raise HTTPException(status_code=400, detail=f"Segmen harga ID '{data.segmen_harga_id}' tidak ditemukan.")

    new_id   = generate_next_id(db, "properti", "prop_")
    properti = Properti(
        id               = new_id,
        harga            = data.harga,
        deskripsi        = data.deskripsi,
        kamar_tidur      = data.kamar_tidur,
        kamar_mandi      = data.kamar_mandi,
        carport          = data.carport,
        tahun            = data.tahun, 
        luas_tanah_m2    = data.luas_tanah_m2,
        luas_bangunan_m2 = data.luas_bangunan_m2,
        area_id          = data.area_id,
        keyword          = data.keyword,
        tipe_properti_id = data.tipe_properti_id,
        segmen_harga_id  = data.segmen_harga_id,
    )
    db.add(properti)
    db.commit()
    db.refresh(properti)
    return {"id": properti.id, "message": "Properti berhasil ditambahkan."}


# ── UPDATE ───────────────────────────────────────────────────────────────────

@router.put("/{properti_id}")
def update_properti(
    properti_id: str,
    data: PropertiUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    properti = db.query(Properti).filter(Properti.id == properti_id).first()
    if not properti:
        raise HTTPException(status_code=404, detail="Properti tidak ditemukan.")

    if data.area_id and not db.query(Area).filter(Area.area_id == data.area_id).first():
        raise HTTPException(status_code=400, detail=f"Area ID '{data.area_id}' tidak ditemukan.")
    if data.tipe_properti_id and not db.query(TipeProperti).filter(TipeProperti.id == data.tipe_properti_id).first():
        raise HTTPException(status_code=400, detail=f"Tipe properti ID '{data.tipe_properti_id}' tidak ditemukan.")
    if data.segmen_harga_id and not db.query(SegmenHarga).filter(SegmenHarga.id == data.segmen_harga_id).first():
        raise HTTPException(status_code=400, detail=f"Segmen harga ID '{data.segmen_harga_id}' tidak ditemukan.")

    properti.harga            = data.harga
    properti.deskripsi        = data.deskripsi
    properti.kamar_tidur      = data.kamar_tidur
    properti.kamar_mandi      = data.kamar_mandi
    properti.carport          = data.carport
    properti.tahun            = data.tahun
    properti.luas_tanah_m2    = data.luas_tanah_m2
    properti.luas_bangunan_m2 = data.luas_bangunan_m2
    properti.area_id          = data.area_id
    properti.keyword          = data.keyword
    properti.tipe_properti_id = data.tipe_properti_id
    properti.segmen_harga_id  = data.segmen_harga_id
    db.commit()
    db.refresh(properti)
    return {"id": properti.id, "message": "Properti berhasil diperbarui."}


# ── DELETE ───────────────────────────────────────────────────────────────────

@router.delete("/{properti_id}")
def delete_properti(
    properti_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    properti = db.query(Properti).filter(Properti.id == properti_id).first()
    if not properti:
        raise HTTPException(status_code=404, detail="Properti tidak ditemukan.")
    db.delete(properti)
    db.commit()
    return {"message": f"Properti '{properti_id}' berhasil dihapus."}