from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Optional
from datetime import date
from pydantic import BaseModel
from app.database import get_db
from app.dependencies import get_current_user

router = APIRouter(prefix="/analitik/bi-rate", tags=["BI Rate"])


# ── Schema ──────────────────────────────────────────────────────────────────

class BIRateCreate(BaseModel):
    tanggal  : date
    nilai_pct: float

class BIRateUpdate(BaseModel):
    tanggal  : Optional[date]  = None
    nilai_pct: Optional[float] = None


# ── READ ─────────────────────────────────────────────────────────────────────

@router.get("")
def get_bi_rate(
    tanggal_mulai: Optional[date] = Query(None),
    tanggal_akhir: Optional[date] = Query(None),
    db          : Session       = Depends(get_db),
    current_user: str           = Depends(get_current_user),
):
    """Mengambil historis BI Rate."""
    sql = """
        SELECT id, tanggal, nilai_pct
        FROM analitik.bi_rate
        WHERE 1=1
    """
    params = {}

    if tanggal_mulai:
        sql += " AND tanggal >= :tanggal_mulai"
        params["tanggal_mulai"] = tanggal_mulai

    if tanggal_akhir:
        sql += " AND tanggal <= :tanggal_akhir"
        params["tanggal_akhir"] = tanggal_akhir
    sql += " ORDER BY tanggal"
    rows = db.execute(text(sql), params).fetchall()
    return [{"id": r[0], "tanggal": str(r[1]), "nilai_pct": float(r[2])} for r in rows]


@router.get("/terkini")
def get_bi_rate_terkini(
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Mengambil nilai BI Rate terbaru."""
    row = db.execute(
        text("SELECT id, nilai_pct, tanggal FROM analitik.bi_rate ORDER BY tanggal DESC LIMIT 1")
    ).fetchone()
    if not row:
        return {"id": None, "nilai_pct": None, "tanggal": None}
    return {"id": row[0], "nilai_pct": float(row[1]), "tanggal": str(row[2])}


@router.get("/{id}")
def get_bi_rate_by_id(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Mengambil satu record BI Rate berdasarkan ID."""
    row = db.execute(
        text("SELECT id, tanggal, nilai_pct FROM analitik.bi_rate WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Data BI Rate tidak ditemukan")
    return {"id": row[0], "tanggal": str(row[1]), "nilai_pct": float(row[2])}


# ── CREATE ───────────────────────────────────────────────────────────────────

@router.post("/", status_code=201)
def create_bi_rate(
    body        : BIRateCreate,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Menambahkan data BI Rate baru."""
    row = db.execute(
        text("""
            INSERT INTO analitik.bi_rate (tanggal, nilai_pct)
            VALUES (:tanggal, :nilai_pct)
            RETURNING id, tanggal, nilai_pct
        """),
        body.model_dump(),
    ).fetchone()
    db.commit()
    return {"id": row[0], "tanggal": str(row[1]), "nilai_pct": float(row[2])}


# ── UPDATE ───────────────────────────────────────────────────────────────────

@router.put("/{id}")
def update_bi_rate(
    id          : str,
    body        : BIRateUpdate,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Memperbarui data BI Rate berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.bi_rate WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data BI Rate tidak ditemukan")

    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="Tidak ada field yang diperbarui")

    set_clause = ", ".join(f"{k} = :{k}" for k in updates)
    updates["id"] = id
    row = db.execute(
        text(f"""
            UPDATE analitik.bi_rate
            SET {set_clause}
            WHERE id = :id
            RETURNING id, tanggal, nilai_pct
        """),
        updates,
    ).fetchone()
    db.commit()
    return {"id": row[0], "tanggal": str(row[1]), "nilai_pct": float(row[2])}


# ── DELETE ───────────────────────────────────────────────────────────────────

@router.delete("/{id}", status_code=200)
def delete_bi_rate(
    id          : str,
    db          : Session = Depends(get_db),
    current_user: str     = Depends(get_current_user),
):
    """Menghapus data BI Rate berdasarkan ID."""
    existing = db.execute(
        text("SELECT id FROM analitik.bi_rate WHERE id = :id"),
        {"id": id},
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Data BI Rate tidak ditemukan")

    db.execute(text("DELETE FROM analitik.bi_rate WHERE id = :id"), {"id": id})
    db.commit()
    return {"message": f"Data BI Rate ID {id} berhasil dihapus"}