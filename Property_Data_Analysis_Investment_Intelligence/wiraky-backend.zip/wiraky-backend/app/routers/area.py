# app/routers/area.py

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from app.database import get_db
from app.models import Area
from app.schemas import AreaResponse,AreaCreate, AreaUpdate
from app.dependencies import get_current_user, require_admin
from app.utils import generate_next_id

router = APIRouter(prefix="/area", tags=["Area"])

@router.get("/", response_model=List[AreaResponse])
def get_all_area(
    kota: Optional[str] = Query(None),
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    query = db.query(Area)
    if kota:
        query = query.filter(Area.kota.ilike(f"%{kota}%"))
    return query.order_by(Area.nama_area).all()


@router.get("/{area_id}", response_model=AreaResponse)
def get_area(
    area_id: str,
    db: Session = Depends(get_db),
    current_user: str = Depends(get_current_user)
):
    result = db.query(Area).filter(Area.area_id == area_id).first()
    if not result:
        raise HTTPException(status_code=404, detail="Area tidak ditemukan.")
    return result


@router.post("/", response_model=AreaResponse, status_code=201)
def create_area(
    data: AreaCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    existing = db.query(Area).filter(Area.nama_area == data.nama_area).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Area '{data.nama_area}' sudah ada (ID: {existing.id})."
        )
    new_id   = generate_next_id(db, "operasional.area", "area_",
                             pk_col="area_id")
    area     = Area(
        area_id        = new_id,                            # ← diubah
        nama_area      = data.nama_area,
        kabupaten_kota = data.kabupaten_kota                # ← diubah
    )
    db.add(area)
    db.commit()
    db.refresh(area)
    return area


@router.put("/{area_id}", response_model=AreaResponse)
def update_area(
    area_id: str,
    data: AreaUpdate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    area = db.query(Area).filter(Area.area_id == area_id).first()
    if not area:
        raise HTTPException(status_code=404, detail="Area tidak ditemukan.")
    # Cek nama duplikat pada area lain
    duplicate = db.query(Area).filter(
        Area.nama_area == data.nama_area,
        Area.area_id != area_id                             # ← diubah
    ).first()
    if duplicate:
        raise HTTPException(
            status_code=400,
            detail=f"Nama area '{data.nama_area}' sudah digunakan oleh ID lain."
        )
    area.nama_area      = data.nama_area
    area.kabupaten_kota = data.kabupaten_kota 
    db.commit()
    db.refresh(area)
    return area


@router.delete("/{area_id}")
def delete_area(
    area_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_admin)
):
    area = db.query(Area).filter(Area.area_id == area_id).first()
    if not area:
        raise HTTPException(status_code=404, detail="Area tidak ditemukan.")
    db.delete(area)
    db.commit()
    return {"message": f"Area '{area.nama_area}' berhasil dihapus."}