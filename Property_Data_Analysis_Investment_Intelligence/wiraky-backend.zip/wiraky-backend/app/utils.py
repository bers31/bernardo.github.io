# app/utils.py
# Helper functions untuk seluruh router

from sqlalchemy.orm import Session
from sqlalchemy import text


def generate_next_id(db: Session, table: str, prefix: str,
                     pk_col: str = "id") -> str:       # ← tambah parameter pk_col
    result = db.execute(text(f"""
        SELECT MAX(CAST(SUBSTRING({pk_col} FROM {len(prefix) + 1}) AS INTEGER))
        FROM {table}
        WHERE {pk_col} LIKE :prefix
    """), {"prefix": f"{prefix}%"}).scalar()
    next_num = (result or 0) + 1
    return f"{prefix}{next_num}"