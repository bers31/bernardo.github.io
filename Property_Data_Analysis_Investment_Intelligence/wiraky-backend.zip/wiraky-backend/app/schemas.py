# app/schemas.py

from pydantic import BaseModel, Field
from typing import Optional


# ── Provinsi ──────────────────────────────────────────

class ProvinsiBase(BaseModel):
    kode_provinsi: str
    nama_provinsi: str

class ProvinsiResponse(ProvinsiBase):
    class Config:
        from_attributes = True


# ── Kabupaten/Kota ────────────────────────────────────

class KabupatenKotaBase(BaseModel):
    kode_kabupaten_kota: str
    nama_kabupaten_kota: str
    kode_provinsi: str

class KabupatenKotaResponse(KabupatenKotaBase):
    class Config:
        from_attributes = True


# ── UMR ───────────────────────────────────────────────

class UMRBase(BaseModel):
    kode_kabupaten_kota: str
    besaran_upah_minimum: float
    satuan: str = "RUPIAH"
    tahun: int

class UMRResponse(UMRBase):
    id: str
    class Config:
        from_attributes = True

class UMRWithWilayah(UMRResponse):
    nama_kabupaten_kota: Optional[str] = None
    nama_provinsi: Optional[str] = None


# ── Area ──────────────────────────────────────────────

class AreaBase(BaseModel):
    nama_area: str
    kabupaten_kota: str

class AreaResponse(AreaBase):
    area_id: str
    class Config:
        from_attributes = True


# ── Tipe Properti ─────────────────────────────────────

class TipePropertiResponse(BaseModel):
    id: str
    nama: str
    class Config:
        from_attributes = True


# ── Segmen Harga ──────────────────────────────────────

class SegmenHargaResponse(BaseModel):
    id: str
    nama: str
    class Config:
        from_attributes = True


# ── Properti ──────────────────────────────────────────

class PropertiBase(BaseModel):
    harga: int
    deskripsi: Optional[str] = None
    kamar_tidur: Optional[int] = None
    kamar_mandi: Optional[int] = None
    carport: Optional[int] = None
    luas_tanah_m2: Optional[float] = None
    luas_bangunan_m2: Optional[float] = None
    area_id: Optional[str] = None
    keyword: Optional[str] = None
    tipe_properti_id: Optional[str] = None
    segmen_harga_id: Optional[str] = None
    tahun: Optional[int]

class PropertiResponse(PropertiBase):
    id: str
    class Config:
        from_attributes = True

class PropertiDetail(PropertiResponse):
    """Response lengkap dengan data relasi"""
    nama_area: Optional[str] = None
    kota: Optional[str] = None
    tipe_properti: Optional[str] = None
    segmen_harga: Optional[str] = None
    # Kolom turunan (dihitung di endpoint, bukan di database)
    harga_per_m2_tanah: Optional[float] = None
    harga_per_m2_bangunan: Optional[float] = None
    rasio_bangunan_tanah: Optional[float] = None


# ── Autentikasi ───────────────────────────────────────

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str


# ── Pagination ────────────────────────────────────────

class PaginatedResponse(BaseModel):
    total: int
    page: int
    per_page: int
    data: list

# ─────────────────────────────────────────────────────────────────────────────
# SCHEMAS CRUD — Create dan Update untuk setiap entitas
# ─────────────────────────────────────────────────────────────────────────────

from pydantic import BaseModel
from typing import Optional


# ── Provinsi ──────────────────────────────────────────────────────────────────

class ProvinsiCreate(BaseModel):
    kode_provinsi: str
    nama_provinsi: str

class ProvinsiUpdate(BaseModel):
    nama_provinsi: str


# ── Kabupaten/Kota ────────────────────────────────────────────────────────────

class KabupatenKotaCreate(BaseModel):
    kode_kabupaten_kota: str
    nama_kabupaten_kota: str
    kode_provinsi: str

class KabupatenKotaUpdate(BaseModel):
    nama_kabupaten_kota: str
    kode_provinsi: str


# ── UMR ───────────────────────────────────────────────────────────────────────

class UMRCreate(BaseModel):
    kode_kabupaten_kota: str
    besaran_upah_minimum: float
    satuan: str = "RUPIAH"
    tahun: int

class UMRUpdate(BaseModel):
    besaran_upah_minimum: float
    satuan: str = "RUPIAH"


# ── Area ──────────────────────────────────────────────────────────────────────

class AreaCreate(BaseModel):
    nama_area: str
    kabupaten_kota: str

class AreaUpdate(BaseModel):
    nama_area: str
    kabupaten_kota: str


# ── Tipe Properti ─────────────────────────────────────────────────────────────

class TipePropertiCreate(BaseModel):
    nama: str

class TipePropertiUpdate(BaseModel):
    nama: str


# ── Segmen Harga ──────────────────────────────────────────────────────────────

class SegmenHargaCreate(BaseModel):
    nama: str

class SegmenHargaUpdate(BaseModel):
    nama: str


# ── Properti ──────────────────────────────────────────────────────────────────

class PropertiCreate(BaseModel):
    harga: int
    deskripsi: Optional[str] = None
    kamar_tidur: Optional[int] = None
    kamar_mandi: Optional[int] = None
    carport: Optional[int] = None
    tahun: Optional[int] = None
    luas_tanah_m2: Optional[float] = None
    luas_bangunan_m2: Optional[float] = None
    area_id: Optional[str] = None
    keyword: Optional[str] = None
    tipe_properti_id: Optional[str] = None
    segmen_harga_id: Optional[str] = None

class PropertiUpdate(PropertiCreate):
    pass