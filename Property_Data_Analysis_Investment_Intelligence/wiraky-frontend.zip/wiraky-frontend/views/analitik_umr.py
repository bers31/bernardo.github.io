# views/umr.py

import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_umr, get_kabupaten_kota, is_admin,
    crud_create, crud_update, crud_delete,
    notif_sukses, notif_gagal, tampilkan_notif
)


def render():
    st.title("📊 Analitik Upah Minimum Regional")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat  = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # ── TAB LIHAT ─────────────────────────────────────────────────────────────
    with tab_lihat:
        result = get_umr()
        data   = result.get("data", [])
        if not data:
            st.warning("Tidak ada data UMR yang tersedia.")
            return

        df = pd.DataFrame(data)
        df["besaran_upah_minimum"] = pd.to_numeric(df["besaran_upah_minimum"], errors="coerce")

        st.subheader("🔽 Filter per Kolom")
        col_f1, col_f2, col_f3 = st.columns(3)
        with col_f1:
            semua_tahun = sorted(df["tahun"].dropna().unique().tolist(), reverse=True)
            pilih_tahun = st.multiselect("Filter Tahun", options=["Semua"] + semua_tahun,
                                         default=["Semua"], key="filter_tahun")
            aktif_tahun = semua_tahun if "Semua" in pilih_tahun or not pilih_tahun else pilih_tahun
        with col_f2:
            semua_prov = sorted(df["nama_provinsi"].dropna().unique().tolist())
            pilih_prov = st.multiselect("Filter Provinsi", options=["Semua"] + semua_prov,
                                        default=["Semua"], key="filter_provinsi_umr")
            aktif_prov = semua_prov if "Semua" in pilih_prov or not pilih_prov else pilih_prov
        with col_f3:
            semua_kab = sorted(df["nama_kabupaten_kota"].dropna().unique().tolist())
            pilih_kab = st.multiselect("Filter Kabupaten/Kota", options=["Semua"] + semua_kab,
                                       default=["Semua"], key="filter_kabupaten_umr")
            aktif_kab = semua_kab if "Semua" in pilih_kab or not pilih_kab else pilih_kab

        st.markdown("**Filter Rentang UMR**")
        step_umr  = 100_000
        umr_min_r = int(df["besaran_upah_minimum"].min() // step_umr) * step_umr
        umr_max_r = (int(df["besaran_upah_minimum"].max()) // step_umr + 1) * step_umr
        umr_range = st.slider("Rentang Besaran UMR (Rp)", min_value=umr_min_r,
                              max_value=umr_max_r, value=(umr_min_r, umr_max_r),
                              step=step_umr, format="Rp %d",
                              key=f"filter_umr_{umr_min_r}_{umr_max_r}")

        df_filtered = df[
            df["tahun"].isin(aktif_tahun) &
            df["nama_provinsi"].isin(aktif_prov) &
            df["nama_kabupaten_kota"].isin(aktif_kab) &
            df["besaran_upah_minimum"].between(umr_range[0], umr_range[1])
        ]

        st.divider()
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Wilayah",  f"{len(df_filtered):,}")
        col2.metric("UMR Tertinggi",  f"Rp {df_filtered['besaran_upah_minimum'].max():,.0f}" if not df_filtered.empty else "-")
        col3.metric("UMR Terendah",   f"Rp {df_filtered['besaran_upah_minimum'].min():,.0f}" if not df_filtered.empty else "-")
        col4.metric("UMR Rata-rata",  f"Rp {df_filtered['besaran_upah_minimum'].mean():,.0f}" if not df_filtered.empty else "-")

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai.")
            return

        tahun_label = ", ".join(str(t) for t in sorted(aktif_tahun)) \
                      if len(aktif_tahun) <= 3 else f"{len(aktif_tahun)} tahun dipilih"
        st.subheader(f"Top 15 UMR Tertinggi — {tahun_label}")
        fig1 = px.bar(
            df_filtered.nlargest(15, "besaran_upah_minimum"),
            x="besaran_upah_minimum", y="nama_kabupaten_kota", orientation="h",
            color="besaran_upah_minimum", color_continuous_scale="Blues",
            labels={"besaran_upah_minimum": "UMR (Rp)", "nama_kabupaten_kota": "Kabupaten/Kota"}
        )
        fig1.update_layout(yaxis={"categoryorder": "total ascending"}, coloraxis_showscale=False)
        st.plotly_chart(fig1, use_container_width=True)

        if len(aktif_tahun) > 1:
            st.subheader("Tren Rata-rata UMR per Tahun")
            tren = df_filtered.groupby("tahun")["besaran_upah_minimum"].mean().reset_index()
            tren.columns = ["Tahun", "Rata-rata UMR"]
            fig2 = px.line(tren.sort_values("Tahun"), x="Tahun", y="Rata-rata UMR",
                           markers=True, color_discrete_sequence=["#1a56db"])
            st.plotly_chart(fig2, use_container_width=True)

        st.subheader(f"Data Lengkap ({len(df_filtered):,} data)")
        df_tampil = df_filtered[["id", "nama_kabupaten_kota", "nama_provinsi",
                                  "besaran_upah_minimum", "satuan", "tahun"]].copy()
        df_tampil["besaran_upah_minimum"] = df_tampil["besaran_upah_minimum"].apply(
            lambda x: f"Rp {x:,.0f}"
        )
        df_tampil.columns = ["ID", "Kabupaten/Kota", "Provinsi", "UMR", "Satuan", "Tahun"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)

    # ── TAB TAMBAH ────────────────────────────────────────────────────────────
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Data UMR Baru")
            kab_list    = get_kabupaten_kota()
            kab_options = {f"{k['kode_kabupaten_kota']} — {k['nama_kabupaten_kota']}": k["kode_kabupaten_kota"]
                           for k in kab_list}

            with st.form("form_tambah_umr"):
                kab_sel = st.selectbox("Kabupaten/Kota", options=list(kab_options.keys()))
                tahun   = st.number_input("Tahun", min_value=2000, max_value=2100,
                                          value=2025, step=1)
                besaran = st.number_input("Besaran Upah Minimum (Rp)",
                                          min_value=0, step=100_000)
                satuan  = st.selectbox("Satuan", options=["RUPIAH"])
                saved   = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if besaran <= 0:
                    notif_gagal("Besaran upah minimum harus lebih dari 0.")
                else:
                    result = crud_create("umr", {
                        "kode_kabupaten_kota" : kab_options[kab_sel],
                        "besaran_upah_minimum": besaran,
                        "satuan"              : satuan,
                        "tahun"               : int(tahun)
                    })
                    if result:
                        notif_sukses(f"Data UMR berhasil ditambahkan dengan ID: {result.get('id')}.")
                        st.rerun()

    # ── TAB EDIT ──────────────────────────────────────────────────────────────
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Data UMR")
            result_all = get_umr(per_page=99999)
            data_all   = result_all.get("data", [])

            if not data_all:
                st.warning("Tidak ada data UMR.")
            else:
                umr_options = {
                    f"{d['id']} — {d['nama_kabupaten_kota']} ({d['tahun']})": d
                    for d in data_all
                }
                pilihan  = st.selectbox("Pilih Data UMR",
                                        options=list(umr_options.keys()), key="edit_sel_umr")
                selected = umr_options[pilihan]

                with st.form("form_edit_umr"):
                    st.caption(
                        f"ID: **{selected['id']}** | Wilayah: **{selected['nama_kabupaten_kota']}** "
                        f"| Tahun: **{selected['tahun']}** (tidak dapat diubah)"
                    )
                    besaran_baru = st.number_input(
                        "Besaran Upah Minimum (Rp)", min_value=0, step=100_000,
                        value=int(selected["besaran_upah_minimum"])
                    )
                    satuan_baru = st.selectbox("Satuan", options=["RUPIAH"])
                    updated     = st.form_submit_button("✏️ Update", use_container_width=True)

                if updated:
                    result = crud_update("umr", selected["id"], {
                        "besaran_upah_minimum": besaran_baru,
                        "satuan"              : satuan_baru
                    })
                    if result:
                        notif_sukses("Data UMR berhasil diperbarui.")
                        st.rerun()

    # ── TAB HAPUS ─────────────────────────────────────────────────────────────
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Data UMR")
            result_all = get_umr(per_page=99999)
            data_all   = result_all.get("data", [])

            if not data_all:
                st.warning("Tidak ada data UMR.")
            else:
                umr_options = {
                    f"{d['id']} — {d['nama_kabupaten_kota']} ({d['tahun']})": d
                    for d in data_all
                }
                pilihan  = st.selectbox("Pilih Data UMR",
                                        options=list(umr_options.keys()), key="del_sel_umr")
                selected = umr_options[pilihan]

                st.warning(
                    f"Anda akan menghapus data UMR **{selected['id']}** untuk "
                    f"**{selected['nama_kabupaten_kota']}** tahun **{selected['tahun']}** "
                    f"sebesar Rp {float(selected['besaran_upah_minimum']):,.0f}."
                )
                if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_umr"):
                    result = crud_delete("umr", selected["id"])
                    if result:
                        notif_sukses(f"Data UMR '{selected['id']}' berhasil dihapus.")
                        st.rerun()