# views/properti.py

import streamlit as st
import pandas as pd
import plotly.express as px
import time as _time
from api_client import (
    get_semua_properti_cached, clear_properti_cache,
    get_area, get_tipe_properti, get_segmen_harga,
    crud_create, crud_update, crud_delete,
    fetch, invalidate_properti_cache, is_admin,
    notif_sukses, notif_gagal, tampilkan_notif
)

ROWS_PER_PAGE = 100


def render():
    st.title("🏠 Analitik Properti")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat  = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # ── TAB LIHAT ─────────────────────────────────────────────────────────────
    with tab_lihat:
        if "properti_cache_time" in st.session_state:
            usia  = int(_time.time() - st.session_state["properti_cache_time"])
            menit = usia // 60
            st.caption(
                f"Data dimuat {menit} menit yang lalu. "
                f"Cache berlaku 60 menit sejak pengambilan terakhir."
            )

        with st.spinner("Memuat data properti..."):
            prop_list = get_semua_properti_cached()

        if not prop_list:
            st.warning("Tidak ada data properti yang tersedia.")
            return

        df = pd.DataFrame(prop_list)
        df["harga"]         = pd.to_numeric(df["harga"],         errors="coerce")
        df["luas_tanah_m2"] = pd.to_numeric(df["luas_tanah_m2"], errors="coerce")
        df["kamar_tidur"]   = pd.to_numeric(df["kamar_tidur"],   errors="coerce")
        df["tahun"]         = pd.to_numeric(df["tahun"],         errors="coerce")

        st.subheader("🔽 Filter per Kolom")
        col_f1, col_f2, col_f3, col_f4, col_f5 = st.columns(5)

        with col_f1:
            semua_kota = sorted(df["kabupaten_kota"].dropna().unique().tolist())
            pilih_kota = st.multiselect("Filter Kota", options=["Semua"] + semua_kota,
                                        default=["Semua"], key="filter_kota")
            aktif_kota = semua_kota if "Semua" in pilih_kota or not pilih_kota else pilih_kota

        with col_f2:
            semua_tipe = sorted(df["tipe_properti"].dropna().unique().tolist())
            pilih_tipe = st.multiselect("Filter Tipe Properti",
                                        options=["Semua"] + semua_tipe,
                                        default=["Semua"], key="filter_tipe")
            aktif_tipe = semua_tipe if "Semua" in pilih_tipe or not pilih_tipe else pilih_tipe

        with col_f3:
            semua_segmen = sorted(df["segmen_harga"].dropna().unique().tolist())
            pilih_segmen = st.multiselect("Filter Segmen Harga",
                                          options=["Semua"] + semua_segmen,
                                          default=["Semua"], key="filter_segmen")
            aktif_segmen = semua_segmen if "Semua" in pilih_segmen or not pilih_segmen else pilih_segmen

        with col_f4:
            semua_kt = sorted(df["kamar_tidur"].dropna().unique().astype(int).tolist())
            pilih_kt = st.multiselect("Filter Kamar Tidur", options=["Semua"] + semua_kt,
                                      default=["Semua"], key="filter_kamar_tidur")
            aktif_kt = semua_kt if "Semua" in pilih_kt or not pilih_kt \
                       else [int(k) for k in pilih_kt]
        with col_f5:
            semua_tahun = sorted(
                df["tahun"].dropna().astype(int).unique().tolist()
            )

            pilih_tahun = st.multiselect(
                "Filter Tahun",
                options=["Semua"] + semua_tahun,
                default=["Semua"],
                key="filter_tahun"
            )

            aktif_tahun = (
                semua_tahun
                if "Semua" in pilih_tahun or not pilih_tahun
                else [int(t) for t in pilih_tahun]
            )

        st.markdown("**Filter Rentang Harga**")
        JUTA          = 1_000_000
        step_harga_jt = 50
        harga_min_jt  = int(df["harga"].min() / JUTA // step_harga_jt) * step_harga_jt
        harga_max_jt  = (int(df["harga"].max() / JUTA) // step_harga_jt + 1) * step_harga_jt
        harga_range_jt = st.slider(
            "Rentang Harga (dalam juta Rp)",
            min_value=harga_min_jt, max_value=harga_max_jt,
            value=(harga_min_jt, harga_max_jt), step=step_harga_jt,
            format="Rp %d jt",
            key=f"filter_harga_{harga_min_jt}_{harga_max_jt}"
        )
        harga_range = (harga_range_jt[0] * JUTA, harga_range_jt[1] * JUTA)

        st.markdown("**Filter Rentang Luas Tanah**")
        df_lt      = df["luas_tanah_m2"].dropna()
        step_lt    = 10
        lt_min_val = int(df_lt.min() // step_lt) * step_lt
        lt_max_val = (int(df_lt.max()) // step_lt + 1) * step_lt
        if lt_min_val == lt_max_val:
            lt_max_val += step_lt
        lt_range = st.slider(
            "Rentang Luas Tanah (m²)",
            min_value=lt_min_val, max_value=lt_max_val,
            value=(lt_min_val, lt_max_val), step=step_lt,
            key=f"filter_lt_{lt_min_val}_{lt_max_val}"
        )

        df_filtered = df[
            df["kabupaten_kota"].isin(aktif_kota) &
            df["tipe_properti"].isin(aktif_tipe) &
            df["segmen_harga"].isin(aktif_segmen) &
            df["kamar_tidur"].isin(aktif_kt) &
            df["tahun"].isin(aktif_tahun) &
            df["harga"].between(harga_range[0], harga_range[1]) &
            (df["luas_tanah_m2"].isna() | df["luas_tanah_m2"].between(lt_range[0], lt_range[1]))
        ].reset_index(drop=True)

        st.divider()
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Properti",  f"{len(df_filtered):,}")
        col2.metric("Harga Tertinggi", f"Rp {df_filtered['harga'].max():,.0f}"
                    if not df_filtered.empty else "-")
        col3.metric("Harga Terendah",  f"Rp {df_filtered['harga'].min():,.0f}"
                    if not df_filtered.empty else "-")
        col4.metric("Harga Rata-rata", f"Rp {df_filtered['harga'].mean():,.0f}"
                    if not df_filtered.empty else "-")

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai dengan filter.")
            return

        st.divider()
        col_a, col_b = st.columns(2)
        with col_a:
            st.subheader("Distribusi Tipe Properti")
            tipe_count = df_filtered["tipe_properti"].value_counts().reset_index()
            tipe_count.columns = ["Tipe", "Jumlah"]
            fig1 = px.pie(tipe_count, names="Tipe", values="Jumlah", hole=0.4,
                          color_discrete_sequence=px.colors.qualitative.Set2)
            st.plotly_chart(fig1, use_container_width=True)
        with col_b:
            st.subheader("Distribusi Segmen Harga")
            segmen_count = df_filtered["segmen_harga"].value_counts().reset_index()
            segmen_count.columns = ["Segmen", "Jumlah"]
            fig2 = px.bar(segmen_count, x="Segmen", y="Jumlah", color="Segmen",
                          color_discrete_sequence=px.colors.qualitative.Set2)
            fig2.update_layout(showlegend=False)
            st.plotly_chart(fig2, use_container_width=True)

        st.subheader("Rata-rata Harga per Kota (Top 15)")
        avg_kota = df_filtered.groupby("kabupaten_kota")["harga"].mean().reset_index()
        avg_kota.columns = ["Kabupaten/Kota", "Rata-rata Harga"]
        avg_kota = avg_kota.sort_values("Rata-rata Harga", ascending=False).head(15)
        fig4 = px.bar(avg_kota, x="Rata-rata Harga", y="Kabupaten/Kota", orientation="h",
                      color="Rata-rata Harga", color_continuous_scale="Oranges")
        fig4.update_layout(yaxis={"categoryorder": "total ascending"},
                           coloraxis_showscale=False)
        st.plotly_chart(fig4, use_container_width=True)

        # Tabel dengan pagination
        total_rows  = len(df_filtered)
        total_pages = max(1, (total_rows + ROWS_PER_PAGE - 1) // ROWS_PER_PAGE)

        st.subheader(f"Data Lengkap ({total_rows:,} data)")
        st.caption(f"Menampilkan {ROWS_PER_PAGE} baris per halaman. Total {total_pages} halaman.")

        if "tabel_halaman" not in st.session_state:
            st.session_state["tabel_halaman"] = 1
        if st.session_state["tabel_halaman"] > total_pages:
            st.session_state["tabel_halaman"] = 1

        col_n1, col_n2, col_n3, col_n4, col_n5 = st.columns([1, 1, 2, 1, 1])
        with col_n1:
            if st.button("⏮ Pertama", use_container_width=True,
                         disabled=st.session_state["tabel_halaman"] == 1):
                st.session_state["tabel_halaman"] = 1
        with col_n2:
            if st.button("◀ Sebelum", use_container_width=True,
                         disabled=st.session_state["tabel_halaman"] == 1):
                st.session_state["tabel_halaman"] -= 1
        with col_n3:
            st.markdown(
                f"<div style='text-align:center;padding-top:8px;'>"
                f"Halaman <b>{st.session_state['tabel_halaman']}</b> "
                f"dari <b>{total_pages}</b></div>",
                unsafe_allow_html=True
            )
        with col_n4:
            if st.button("Sesudah ▶", use_container_width=True,
                         disabled=st.session_state["tabel_halaman"] == total_pages):
                st.session_state["tabel_halaman"] += 1
        with col_n5:
            if st.button("Terakhir ⏭", use_container_width=True,
                         disabled=st.session_state["tabel_halaman"] == total_pages):
                st.session_state["tabel_halaman"] = total_pages

        halaman   = st.session_state["tabel_halaman"]
        idx_awal  = (halaman - 1) * ROWS_PER_PAGE
        idx_akhir = min(idx_awal + ROWS_PER_PAGE, total_rows)

        kolom_tampil = ["id", "kabupaten_kota", "nama_area", "tipe_properti", "segmen_harga",
                        "harga", "tahun", "luas_tanah_m2", "luas_bangunan_m2",
                        "kamar_tidur", "kamar_mandi", "carport"]
        df_tampil = df_filtered.iloc[idx_awal:idx_akhir][
            [k for k in kolom_tampil if k in df_filtered.columns]
        ].copy()
        df_tampil["harga"] = df_tampil["harga"].apply(
            lambda x: f"Rp {x:,.0f}" if pd.notna(x) else "-"
        )
        df_tampil.columns = ["ID", "Kabupaten/Kota", "Area", "Tipe", "Segmen Harga",
                             "Harga", "Tahun", "Luas Tanah (m²)", "Luas Bangunan (m²)",
                             "Kamar Tidur", "Kamar Mandi", "Carport"][:len(df_tampil.columns)]

        st.caption(f"Baris {idx_awal + 1:,} – {idx_akhir:,} dari {total_rows:,}")
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)

        kolom_dl = ["id", "kabupaten_kota", "nama_area", "tipe_properti", "segmen_harga",
                    "harga", "tahun", "luas_tanah_m2", "luas_bangunan_m2",
                    "kamar_tidur", "kamar_mandi", "carport"]
        df_dl = df_filtered[[k for k in kolom_dl if k in df_filtered.columns]].copy()
        df_dl.columns = ["ID", "Kabupaten/Kota", "Area", "Tipe", "Segmen Harga", "Harga", "Tahun",
                         "Luas Tanah (m2)", "Luas Bangunan (m2)",
                         "Kamar Tidur", "Kamar Mandi", "Carport"][:len(df_dl.columns)]
        st.download_button(
            label=f"⬇️ Download Seluruh Data ({total_rows:,} baris) sebagai CSV",
            data=df_dl.to_csv(index=False).encode("utf-8"),
            file_name="properti_wiraky.csv", mime="text/csv",
            use_container_width=True
        )

        st.divider()
        if st.button("🔄 Refresh Data Properti",
                     help="Hapus cache dan ambil data terbaru dari server"):
            clear_properti_cache()
            notif_sukses("Cache properti berhasil dibersihkan. Data diperbarui.")
            st.rerun()

    # ── TAB TAMBAH ────────────────────────────────────────────────────────────
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Properti Baru")

            area_list    = get_area()
            tipe_list    = get_tipe_properti()
            segmen_list  = get_segmen_harga()

            area_options   = {"(Tidak dipilih)": None}
            area_options.update({
                f"{a['area_id']} — {a['nama_area']} ({a['kabupaten_kota']})": a["area_id"]
                for a in area_list
            })
            tipe_options   = {"(Tidak dipilih)": None}
            tipe_options.update({f"{t['id']} — {t['nama']}": t["id"] for t in tipe_list})
            segmen_options = {"(Tidak dipilih)": None}
            segmen_options.update({f"{s['id']} — {s['nama']}": s["id"] for s in segmen_list})

            with st.form("form_tambah_properti"):
                col1, col2 = st.columns(2)
                with col1:
                    harga        = st.number_input("Harga (Rp)", min_value=0, step=1_000_000)
                    kamar_tidur  = st.number_input("Kamar Tidur", min_value=0, step=1, value=0)
                    kamar_mandi  = st.number_input("Kamar Mandi", min_value=0, step=1, value=0)
                    carport      = st.number_input("Carport", min_value=0, step=1, value=0)
                    tahun = st.number_input(
                        "Tahun Bangunan",
                        value=2026,
                        step=1,
                        format="%d"
                    )
                with col2:
                    luas_tanah    = st.number_input("Luas Tanah (m²)", min_value=0.0, step=1.0)
                    luas_bangunan = st.number_input("Luas Bangunan (m²)", min_value=0.0, step=1.0)
                    area_sel      = st.selectbox("Area", options=list(area_options.keys()))
                    tipe_sel      = st.selectbox("Tipe Properti", options=list(tipe_options.keys()))
                    segmen_sel    = st.selectbox("Segmen Harga", options=list(segmen_options.keys()))
                    

                deskripsi = st.text_area("Deskripsi", placeholder="Deskripsi properti...")
                keyword   = st.text_input("Keyword", placeholder="kata kunci, dipisah koma")
                saved     = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if harga <= 0:
                    notif_gagal("Harga harus lebih dari 0.")
                else:
                    result = crud_create("properti", {
                        "harga"           : int(harga),
                        "deskripsi"       : deskripsi or None,
                        "kamar_tidur"     : int(kamar_tidur) if kamar_tidur > 0 else None,
                        "kamar_mandi"     : int(kamar_mandi) if kamar_mandi > 0 else None,
                        "carport"         : int(carport) if carport > 0 else None,
                        "tahun"           : int(tahun) if tahun > 0 else None,
                        "luas_tanah_m2"   : float(luas_tanah) if luas_tanah > 0 else None,
                        "luas_bangunan_m2": float(luas_bangunan) if luas_bangunan > 0 else None,
                        "area_id"         : area_options[area_sel],
                        "keyword"         : keyword or None,
                        "tipe_properti_id": tipe_options[tipe_sel],
                        "segmen_harga_id" : segmen_options[segmen_sel],
                    })
                    if result:
                        invalidate_properti_cache()
                        notif_sukses(
                            f"Properti berhasil ditambahkan dengan ID: {result.get('id')}."
                        )
                        st.rerun()

    # ── TAB EDIT ──────────────────────────────────────────────────────────────
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Properti")
            st.info(
                "Masukkan ID properti yang akan diedit. "
                "ID dapat dilihat dari kolom ID di tab Lihat Data."
            )

            properti_id_edit = st.text_input(
                "ID Properti yang akan diedit",
                placeholder="contoh: prop_1", key="input_id_edit"
            )
            if st.button("🔍 Cari Properti", key="btn_cari_edit") and properti_id_edit:
                data = fetch(f"properti/{properti_id_edit.strip()}")
                if data:
                    st.session_state["properti_edit_data"] = data
                    notif_sukses(f"Properti '{properti_id_edit.strip()}' ditemukan.")
                else:
                    st.session_state.pop("properti_edit_data", None)
                    notif_gagal(f"Properti '{properti_id_edit.strip()}' tidak ditemukan.")

            if "properti_edit_data" in st.session_state:
                p = st.session_state["properti_edit_data"]

                area_list    = get_area()
                tipe_list    = get_tipe_properti()
                segmen_list  = get_segmen_harga()

                area_options   = {"(Tidak dipilih)": None}
                area_options.update({
                    f"{a['area_id']} — {a['nama_area']} ({a['kabupaten_kota']})": a['area_id']
                    for a in area_list
                })
                tipe_options   = {"(Tidak dipilih)": None}
                tipe_options.update({f"{t['id']} — {t['nama']}": t["id"] for t in tipe_list})
                segmen_options = {"(Tidak dipilih)": None}
                segmen_options.update({f"{s['id']} — {s['nama']}": s["id"] for s in segmen_list})

                area_keys   = list(area_options.keys())
                tipe_keys   = list(tipe_options.keys())
                segmen_keys = list(segmen_options.keys())
                area_idx    = next((i for i, k in enumerate(area_keys)
                                    if area_options[k] == p.get("area_id")), 0)
                tipe_idx    = next((i for i, k in enumerate(tipe_keys)
                                    if tipe_options[k] == p.get("tipe_properti_id")), 0)
                segmen_idx  = next((i for i, k in enumerate(segmen_keys)
                                    if segmen_options[k] == p.get("segmen_harga_id")), 0)

                st.success(
                    f"Data ditemukan: **{p.get('area_id')}** — "
                    f"{p.get('kabupaten_kota', '-')} | {p.get('tipe_properti', '-')}"
                )

                with st.form("form_edit_properti"):
                    col1, col2 = st.columns(2)
                    with col1:
                        harga_baru        = st.number_input(
                            "Harga (Rp)", min_value=0, step=1_000_000,
                            value=int(p.get("harga", 0))
                        )
                        kamar_tidur_baru  = st.number_input(
                            "Kamar Tidur", min_value=0, step=1,
                            value=int(p.get("kamar_tidur") or 0)
                        )
                        kamar_mandi_baru  = st.number_input(
                            "Kamar Mandi", min_value=0, step=1,
                            value=int(p.get("kamar_mandi") or 0)
                        )
                        carport_baru      = st.number_input(
                            "Carport", min_value=0, step=1,
                            value=int(p.get("carport") or 0)
                        )
                        tahun_baru = st.number_input(
                            "Tahun Bangunan",
                            min_value=1900,
                            max_value=2100,
                            value=int(p.get("tahun") or 2020),
                            step=1
                        )
                    with col2:
                        luas_tanah_baru    = st.number_input(
                            "Luas Tanah (m²)", min_value=0.0, step=1.0,
                            value=float(p.get("luas_tanah_m2") or 0.0)
                        )
                        luas_bangunan_baru = st.number_input(
                            "Luas Bangunan (m²)", min_value=0.0, step=1.0,
                            value=float(p.get("luas_bangunan_m2") or 0.0)
                        )
                        area_baru   = st.selectbox("Area", options=area_keys, index=area_idx)
                        tipe_baru   = st.selectbox("Tipe Properti", options=tipe_keys, index=tipe_idx)
                        segmen_baru = st.selectbox("Segmen Harga", options=segmen_keys,
                                                   index=segmen_idx)

                    deskripsi_baru = st.text_area("Deskripsi", value=p.get("deskripsi") or "")
                    keyword_baru   = st.text_input("Keyword", value=p.get("keyword") or "")
                    updated        = st.form_submit_button("✏️ Update", use_container_width=True)

                if updated:
                    result = crud_update("properti", p["id"], {
                        "harga"           : int(harga_baru),
                        "deskripsi"       : deskripsi_baru or None,
                        "kamar_tidur"     : int(kamar_tidur_baru) if kamar_tidur_baru > 0 else None,
                        "kamar_mandi"     : int(kamar_mandi_baru) if kamar_mandi_baru > 0 else None,
                        "carport"         : int(carport_baru) if carport_baru > 0 else None,
                        "tahun"           : int(tahun_baru) if tahun_baru > 0 else None,
                        "luas_tanah_m2"   : float(luas_tanah_baru) if luas_tanah_baru > 0 else None,
                        "luas_bangunan_m2": float(luas_bangunan_baru) if luas_bangunan_baru > 0 else None,
                        "area_id"         : area_options[area_baru],
                        "keyword"         : keyword_baru or None,
                        "tipe_properti_id": tipe_options[tipe_baru],
                        "segmen_harga_id" : segmen_options[segmen_baru],
                    })
                    if result:
                        invalidate_properti_cache()
                        st.session_state.pop("properti_edit_data", None)
                        notif_sukses(f"Properti '{p['id']}' berhasil diperbarui.")
                        st.rerun()

    # ── TAB HAPUS ─────────────────────────────────────────────────────────────
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Properti")
            st.info(
                "Masukkan ID properti yang akan dihapus. "
                "ID dapat dilihat dari kolom ID di tab Lihat Data."
            )

            properti_id_hapus = st.text_input(
                "ID Properti yang akan dihapus",
                placeholder="contoh: prop_1", key="input_id_hapus"
            )
            if st.button("🔍 Cari Properti", key="btn_cari_hapus") and properti_id_hapus:
                data = fetch(f"properti/{properti_id_hapus.strip()}")
                if data:
                    st.session_state["properti_hapus_data"] = data
                    notif_sukses(f"Properti '{properti_id_hapus.strip()}' ditemukan.")
                else:
                    st.session_state.pop("properti_hapus_data", None)
                    notif_gagal(f"Properti '{properti_id_hapus.strip()}' tidak ditemukan.")

            if "properti_hapus_data" in st.session_state:
                p = st.session_state["properti_hapus_data"]
                st.warning(
                    f"Anda akan menghapus properti **{p['id']}** — "
                    f"{p.get('kabupaten_kota', '-')} | {p.get('tipe_properti', '-')} | "
                    f"Rp {int(p.get('harga', 0)):,}. "
                    f"Tindakan ini tidak dapat dibatalkan."
                )
                if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_prop"):
                    result = crud_delete("properti", p["id"])
                    if result:
                        invalidate_properti_cache()
                        st.session_state.pop("properti_hapus_data", None)
                        notif_sukses(f"Properti '{p['id']}' berhasil dihapus.")
                        st.rerun()