# views/analitik_sensus.py
import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_sensus,
    is_admin, crud_create, crud_update, crud_delete,
    notif_sukses, notif_gagal, tampilkan_notif,
)

TAHUN_SENSUS = [1971, 1980, 1990, 1995, 2000, 2005, 2010, 2015, 2020]
GENDER_LIST  = ["Laki-laki", "Perempuan", "Total"]


def _load_semua() -> pd.DataFrame:
    """Ambil semua data sensus dari backend. Backend return: id, provinsi, tahun, status, gender, nilai."""
    data = get_sensus()
    if not data:
        return pd.DataFrame()
    df = pd.DataFrame(data)
    if "nilai" in df.columns:
        df["nilai"] = pd.to_numeric(df["nilai"], errors="coerce")
    if "tahun" in df.columns:
        df["tahun"] = pd.to_numeric(df["tahun"], errors="coerce").astype("Int64")
    return df


def render():
    st.title("👥 Analitik Sensus Penduduk")
    st.divider()
    tampilkan_notif()
    st.caption(
        "Populasi adalah fundamen dari permintaan properti jangka panjang. "
        "Provinsi dengan populasi besar dan tumbuh pesat memiliki demand organik "
        "yang kuat untuk properti residensial."
    )

    # ── Tabs ──────────────────────────────────────────────────────────────────
    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # =========================================================================
    # TAB LIHAT
    # =========================================================================
    with tab_lihat:
        with st.spinner("Memuat data sensus penduduk..."):
            data = get_sensus()
        if not data:
            st.warning(
                "Belum ada data sensus. Silakan impor data menggunakan "
                "script import_data_analitik.py terlebih dahulu."
            )
            return

        df = pd.DataFrame(data)
        df["nilai"] = pd.to_numeric(df["nilai"], errors="coerce")
        df["tahun"] = pd.to_numeric(df["tahun"], errors="coerce")

        # Filter
        st.subheader("🔽 Filter")
        col_f1, col_f2, col_f3, col_f4 = st.columns(4)
        with col_f1:
            semua_prov = sorted(df["provinsi"].dropna().unique().tolist())
            pilih_prov = st.multiselect("Filter Provinsi",
                                         options=["Semua"] + semua_prov,
                                         default=["Semua"], key="filter_prov_sensus")
            aktif_prov = semua_prov if "Semua" in pilih_prov or not pilih_prov else pilih_prov
        with col_f2:
            semua_tahun = sorted(df["tahun"].dropna().unique().tolist(), reverse=True)
            pilih_tahun = st.multiselect("Tahun Sensus", options=["Semua"] + semua_tahun,
                                        default=["Semua"], key="filter_tahun_sensus")
            aktif_tahun = semua_tahun if "Semua" in pilih_tahun or not pilih_tahun else pilih_tahun
        with col_f3:
            semua_status = sorted(df["status"].dropna().unique().tolist())
            pilih_status = st.multiselect("Status", options=["Semua"] + semua_status,
                                        default=["Semua"], key="filter_status_sensus")
            aktif_status = semua_status if "Semua" in pilih_status or not pilih_status else pilih_status
        with col_f4:
            semua_gender = sorted(df["gender"].dropna().unique().tolist())
            pilih_gender = st.multiselect("Gender", options=["Semua"] + semua_gender,
                                        default=["Semua"], key="filter_gender_sensus")
            aktif_gender = semua_gender if "Semua" in pilih_gender or not pilih_gender else pilih_gender

        df_filtered = df[
            df["provinsi"].isin(aktif_prov) &
            df["tahun"].isin(aktif_tahun) &
            df["status"].isin(aktif_status) &
            df["gender"].isin(aktif_gender)
        ].copy()

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai dengan filter.")
            return

        # Metrik
        st.divider()
        df_agg_prov = df_filtered.groupby("provinsi")["nilai"].sum()
        total_nilai    = df_filtered["nilai"].sum()
        prov_terbesar  = df_agg_prov.idxmax() if not df_agg_prov.empty else "-"
        nilai_terbesar = df_agg_prov.max()    if not df_agg_prov.empty else 0

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Nilai",       f"{total_nilai:,.0f}")
        c2.metric("Jumlah Record",     f"{len(df_filtered):,}")
        c3.metric("Provinsi Terbesar", prov_terbesar)
        c4.metric("Nilai Terbesar",    f"{nilai_terbesar:,.0f}")

        # Grafik 1: Nilai agregat per provinsi
        st.divider()
        label_tahun = ", ".join(str(t) for t in sorted(aktif_tahun)) if len(aktif_tahun) <= 3 else f"{len(aktif_tahun)} tahun"
        st.subheader(f"Nilai per Provinsi — Sensus {label_tahun}")
        df_bar = df_agg_prov.reset_index().sort_values("nilai", ascending=True)
        fig1 = px.bar(df_bar, x="nilai", y="provinsi", orientation="h",
                       color="nilai", color_continuous_scale="Blues",
                       labels={"nilai": "Nilai", "provinsi": "Provinsi"})
        fig1.update_layout(coloraxis_showscale=False)
        st.plotly_chart(fig1, use_container_width=True)

        # Grafik 2: Breakdown per gender (hanya jika filter gender = Semua)
        if len(aktif_gender) > 1 and "gender" in df_filtered.columns:
            st.subheader("Breakdown per Gender (Top 20 Provinsi)")
            top20_prov = df_agg_prov.nlargest(20).index.tolist()
            df_gender  = (df_filtered[df_filtered["provinsi"].isin(top20_prov)]
                          .groupby(["provinsi", "gender"])["nilai"]
                          .sum().reset_index())
            fig2 = px.bar(df_gender, x="nilai", y="provinsi", color="gender",
                           orientation="h", barmode="stack",
                           labels={"nilai": "Nilai", "provinsi": "Provinsi",
                                   "gender": "Gender"})
            st.plotly_chart(fig2, use_container_width=True)

        # Grafik 3: Pie charts
        col_a, col_b = st.columns(2)
        with col_a:
            st.subheader("Top 10 Provinsi Terbesar")
            df_top10 = df_agg_prov.nlargest(10).reset_index()
            fig3 = px.pie(df_top10, names="provinsi", values="nilai",
                           hole=0.4, color_discrete_sequence=px.colors.qualitative.Set3)
            st.plotly_chart(fig3, use_container_width=True)
        with col_b:
            if len(aktif_gender) > 1 and "gender" in df_filtered.columns:
                st.subheader("Proporsi per Gender")
                df_pie = df_filtered.groupby("gender")["nilai"].sum().reset_index()
                fig4   = px.pie(df_pie, names="gender", values="nilai", hole=0.4)
                st.plotly_chart(fig4, use_container_width=True)

        # Tabel
        st.subheader(f"Data Lengkap ({len(df_filtered):,} baris)")
        df_tampil = df_filtered[["id", "provinsi", "tahun", "status", "gender", "nilai"]].copy()
        df_tampil["nilai"]  = df_tampil["nilai"].apply(
            lambda x: f"{int(x):,}" if pd.notna(x) else "-"
        )
        df_tampil.columns = ["id", "Provinsi", "Tahun", "Status", "Gender", "Nilai"]
        st.dataframe(df_tampil.sort_values("Nilai", ascending=False),
                     use_container_width=True, hide_index=True)
        st.download_button("⬇️ Download CSV",
                            data=df_tampil.to_csv(index=False).encode("utf-8"),
                            file_name="sensus_penduduk.csv", mime="text/csv",
                            use_container_width=True)

    # =========================================================================
    # TAB TAMBAH
    # =========================================================================
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Data Sensus Penduduk")
            st.caption("Data disimpan ke tabel `analitik.sensus_penduduk`.")

            with st.spinner("Memuat referensi data..."):
                df_ref = _load_semua()

            provinsi_list = sorted(df_ref["provinsi"].dropna().unique().tolist()) \
                            if not df_ref.empty else []
            status_list   = sorted(df_ref["status"].dropna().unique().tolist()) \
                            if not df_ref.empty and "status" in df_ref.columns else []

            with st.form("form_tambah_sensus"):
                col_a, col_b = st.columns(2)
                with col_a:
                    prov_sel = st.selectbox("Provinsi",
                                             options=provinsi_list + ["— Ketik manual —"])
                    if prov_sel == "— Ketik manual —":
                        provinsi = st.text_input("Nama Provinsi Baru")
                    else:
                        provinsi = prov_sel
                    tahun = st.selectbox("Tahun Sensus",
                                          options=sorted(TAHUN_SENSUS, reverse=True))
                with col_b:
                    if status_list:
                        status_sel = st.selectbox("Status",
                                                   options=status_list + ["— Ketik manual —"])
                        if status_sel == "— Ketik manual —":
                            status = st.text_input("Nama Status Baru")
                        else:
                            status = status_sel
                    else:
                        status = st.text_input("Status")
                    gender = st.selectbox("Gender", options=GENDER_LIST)
                    nilai  = st.number_input("Nilai", min_value=0, step=1000)

                saved = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not provinsi or not provinsi.strip():
                    notif_gagal("Nama provinsi tidak boleh kosong.")
                elif not status or not status.strip():
                    notif_gagal("Status tidak boleh kosong.")
                elif nilai <= 0:
                    notif_gagal("Nilai harus lebih dari 0.")
                else:
                    result = crud_create("analitik/sensus", {
                        "provinsi": provinsi.strip(),
                        "tahun"   : int(tahun),
                        "status"  : status.strip(),
                        "gender"  : gender,
                        "nilai"   : int(nilai),
                    })
                    if result:
                        notif_sukses(
                            f"Data sensus berhasil ditambahkan — "
                            f"{provinsi} | {gender} | {status} | tahun {tahun} "
                            f"(ID: {result.get('id')})."
                        )
                        st.rerun()

    # =========================================================================
    # TAB EDIT
    # =========================================================================
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Data Sensus Penduduk")
            st.caption("Hanya kolom `nilai` yang dapat diubah. "
                       "Provinsi, tahun, status, dan gender adalah kunci identitas data.")

            with st.spinner("Memuat data sensus..."):
                df_all = _load_semua()

            if df_all.empty:
                st.warning("Tidak ada data sensus yang tersedia.")
            elif "id" not in df_all.columns:
                st.error(
                    "Kolom `id` tidak ditemukan dalam respons API. "
                    "Tambahkan `id` ke query `GET /analitik/sensus` di backend."
                )
            else:
                col_e1, col_e2, col_e3 = st.columns(3)
                with col_e1:
                    prov_f = st.selectbox(
                        "Filter Provinsi",
                        options=["Semua"] + sorted(df_all["provinsi"].dropna().unique()),
                        key="edit_filter_prov_sensus"
                    )
                with col_e2:
                    tahun_f = st.selectbox(
                        "Filter Tahun",
                        options=["Semua"] + sorted(df_all["tahun"].dropna().unique(), reverse=True),
                        key="edit_filter_tahun_sensus"
                    )
                with col_e3:
                    gender_f = st.selectbox(
                        "Filter Gender",
                        options=["Semua"] + sorted(df_all["gender"].dropna().unique()),
                        key="edit_filter_gender_sensus"
                    )

                df_edit = df_all.copy()
                if prov_f   != "Semua": df_edit = df_edit[df_edit["provinsi"] == prov_f]
                if tahun_f  != "Semua": df_edit = df_edit[df_edit["tahun"]    == tahun_f]
                if gender_f != "Semua": df_edit = df_edit[df_edit["gender"]   == gender_f]

                if df_edit.empty:
                    st.warning("Tidak ada data yang cocok dengan filter.")
                else:
                    opts = {
                        (
                            f"ID {d['id']} — {d['provinsi']} | "
                            f"{d['gender']} | {d['status']} | {d['tahun']} | "
                            f"nilai: {int(d['nilai']):,}"
                        ): d
                        for d in df_edit.to_dict("records")
                    }
                    pilihan  = st.selectbox("Pilih Record", options=list(opts.keys()),
                                             key="edit_sel_sensus")
                    selected = opts[pilihan]

                    with st.form("form_edit_sensus"):
                        st.caption(
                            f"**ID {selected['id']}** | "
                            f"Provinsi: **{selected['provinsi']}** | "
                            f"Gender: **{selected['gender']}** | "
                            f"Status: **{selected['status']}** | "
                            f"Tahun: **{selected['tahun']}** — field ini tidak dapat diubah"
                        )
                        nilai_baru = st.number_input(
                            "Nilai", min_value=0, step=1000,
                            value=int(selected["nilai"]) if pd.notna(selected["nilai"]) else 0
                        )
                        updated = st.form_submit_button("✏️ Update", use_container_width=True)

                    if updated:
                        result = crud_update("analitik/sensus", selected["id"], {
                            "nilai": int(nilai_baru),
                        })
                        if result:
                            notif_sukses(f"Data sensus ID {selected['id']} berhasil diperbarui.")
                            st.rerun()

    # =========================================================================
    # TAB HAPUS
    # =========================================================================
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Data Sensus Penduduk")

            with st.spinner("Memuat data sensus..."):
                df_all = _load_semua()

            if df_all.empty:
                st.warning("Tidak ada data sensus yang tersedia.")
            elif "id" not in df_all.columns:
                st.error(
                    "Kolom `id` tidak ditemukan dalam respons API. "
                    "Tambahkan `id` ke query `GET /analitik/sensus` di backend."
                )
            else:
                col_h1, col_h2, col_h3 = st.columns(3)
                with col_h1:
                    prov_d = st.selectbox(
                        "Filter Provinsi",
                        options=["Semua"] + sorted(df_all["provinsi"].dropna().unique()),
                        key="del_filter_prov_sensus"
                    )
                with col_h2:
                    tahun_d = st.selectbox(
                        "Filter Tahun",
                        options=["Semua"] + sorted(df_all["tahun"].dropna().unique(), reverse=True),
                        key="del_filter_tahun_sensus"
                    )
                with col_h3:
                    gender_d = st.selectbox(
                        "Filter Gender",
                        options=["Semua"] + sorted(df_all["gender"].dropna().unique()),
                        key="del_filter_gender_sensus"
                    )

                df_del = df_all.copy()
                if prov_d   != "Semua": df_del = df_del[df_del["provinsi"] == prov_d]
                if tahun_d  != "Semua": df_del = df_del[df_del["tahun"]    == tahun_d]
                if gender_d != "Semua": df_del = df_del[df_del["gender"]   == gender_d]

                if df_del.empty:
                    st.warning("Tidak ada data yang cocok dengan filter.")
                else:
                    opts = {
                        (
                            f"ID {d['id']} — {d['provinsi']} | "
                            f"{d['gender']} | {d['status']} | {d['tahun']} | "
                            f"nilai: {int(d['nilai']):,}"
                        ): d
                        for d in df_del.sort_values(
                            ["provinsi", "tahun", "gender"]
                        ).to_dict("records")
                    }
                    pilihan  = st.selectbox("Pilih Record", options=list(opts.keys()),
                                             key="del_sel_sensus")
                    selected = opts[pilihan]

                    st.warning(
                        f"Anda akan menghapus secara permanen: "
                        f"**ID {selected['id']}** — **{selected['provinsi']}** | "
                        f"Gender: **{selected['gender']}** | "
                        f"Status: **{selected['status']}** | "
                        f"Tahun: **{selected['tahun']}** | "
                        f"nilai: **{int(selected['nilai']):,}**"
                    )
                    if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_sensus"):
                        result = crud_delete("analitik/sensus", selected["id"])
                        if result:
                            notif_sukses(f"Data sensus ID {selected['id']} berhasil dihapus.")
                            st.rerun()