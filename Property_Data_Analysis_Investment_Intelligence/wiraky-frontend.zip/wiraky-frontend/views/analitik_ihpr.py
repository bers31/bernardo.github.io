# views/analitik_ihpr.py
import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_ihpr_tren, get_ihpr_kota_tersedia,
    is_admin, crud_create, crud_update, crud_delete,
    notif_sukses, notif_gagal, tampilkan_notif,
)

TIPE_PROPERTI = ["Kecil", "Menengah", "Besar"]
KUARTAL_LIST  = ["QI", "QII", "QIII", "QIV"]
KUARTAL_ORDER = {"QI": 1, "QII": 2, "QIII": 3, "QIV": 4}


def _load_ihpr_raw(kota_list: list, tipe, index_base: int) -> pd.DataFrame:
    """
    Ambil data dari v_ihpr_tren untuk tab Lihat.
    Ini dari VIEW — tidak ada id. Dipakai hanya untuk visualisasi.
    """
    all_data = []
    for kota in kota_list:
        data = get_ihpr_tren(kota=kota, tipe=tipe, index_base=index_base)
        all_data.extend(data)
    if not all_data:
        return pd.DataFrame()
    df = pd.DataFrame(all_data)
    df["nilai"]             = pd.to_numeric(df["nilai"],             errors="coerce")
    df["pct_perubahan_qtq"] = pd.to_numeric(df["pct_perubahan_qtq"], errors="coerce")
    df["kuartal_num"]       = df["kuartal"].map(KUARTAL_ORDER)
    df["periode"]           = df["tahun"].astype(str) + "-" + df["kuartal"]
    df = df.sort_values(["kota", "tipe", "tahun", "kuartal_num"])
    return df


def _load_ihpr_tabel(index_base: int | None = None) -> pd.DataFrame:
    """
    Ambil SEMUA data dari tabel analitik.ihpr (via GET /analitik/ihpr).
    Backend HARUS return kolom `id` agar Edit/Hapus bisa berjalan.
    """
    from api_client import get_ihpr          # fungsi hit GET /analitik/ihpr
    data = get_ihpr(index_base=index_base)   # None = semua seri
    if not data:
        return pd.DataFrame()
    df = pd.DataFrame(data)
    df["nilai"]      = pd.to_numeric(df["nilai"],      errors="coerce")
    df["tahun"]      = pd.to_numeric(df["tahun"],      errors="coerce").astype("Int64")
    df["index_base"] = pd.to_numeric(df["index_base"], errors="coerce").astype("Int64")
    df["kuartal_num"] = df["kuartal"].map(KUARTAL_ORDER)
    return df


def render():
    st.title("🏘️ Analitik IHPR — Indeks Harga Properti Residensial")
    st.divider()
    tampilkan_notif()

    st.caption(
        "IHPR mengukur perubahan harga properti residensial dari waktu ke waktu. "
        "Nilai di atas baseline (100) berarti harga properti sudah lebih tinggi dari tahun dasar."
    )

    # ── Tabs ──────────────────────────────────────────────────────────────────
    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # =========================================================================
    # TAB LIHAT
    # =========================================================================
    with tab_lihat:
        # Filter
        st.subheader("🔽 Filter")
        col_f1, col_f2, col_f3 = st.columns(3)
        with col_f1:
            kota_list  = get_ihpr_kota_tersedia()
            pilih_kota = st.multiselect("Filter Kota",
                                         options=["Semua"] + kota_list,
                                         default=["Semua"], key="filter_kota_ihpr")
            aktif_kota = kota_list if "Semua" in pilih_kota or not pilih_kota else pilih_kota
        with col_f2:
            pilih_tipe = st.multiselect("Tipe Properti",
                                        options=["Semua"] + TIPE_PROPERTI,
                                        default=["Semua"], key="filter_tipe_ihpr")
            aktif_tipe = TIPE_PROPERTI if "Semua" in pilih_tipe or not pilih_tipe else pilih_tipe
        with col_f3:
            index_base = st.radio("Seri Indeks", options=[2018, 2002], index=0,
                                   horizontal=True, key="filter_base_ihpr",
                                   help="Seri 2018 untuk jangka menengah. Seri 2002 untuk jangka panjang.")

        with st.spinner("Memuat data IHPR..."):
            df = _load_ihpr_raw(aktif_kota, None, index_base)
            if len(aktif_tipe) < len(TIPE_PROPERTI):
                df = df[df["tipe"].isin(aktif_tipe)]

        if df.empty:
            st.warning(
                "Belum ada data IHPR. Silakan impor data menggunakan "
                "script import_data_analitik.py terlebih dahulu."
            )
            return

        # Metrik
        st.divider()
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Kota",        df["kota"].nunique())
        c2.metric("IHPR Tertinggi",    f"{df['nilai'].max():.2f}")
        c3.metric("IHPR Terendah",     f"{df['nilai'].min():.2f}")
        c4.metric("Perubahan QTQ Max",
                  f"{df['pct_perubahan_qtq'].max():.2f}%"
                  if not df["pct_perubahan_qtq"].isna().all() else "-")

        # Grafik 1: Tren per kota
        st.divider()
        st.subheader(f"Tren IHPR per Kota (Index {index_base}=100)")
        if len(aktif_tipe) == 1:
            df_plot = df[df["tipe"] == aktif_tipe[0]]
            judul   = f"IHPR Tipe {aktif_tipe[0]}"
        else:
            df_plot = (df.groupby(["kota", "periode", "tahun", "kuartal_num"])["nilai"]
                        .mean().reset_index())
            tipe_label = ", ".join(aktif_tipe) if len(aktif_tipe) < len(TIPE_PROPERTI) else "Semua Tipe"
            judul      = f"IHPR Rata-rata ({tipe_label})"
        fig1 = px.line(df_plot.sort_values(["tahun", "kuartal_num"]),
                        x="periode", y="nilai",
                        color="kota" if "kota" in df_plot.columns else None,
                        markers=True, title=judul,
                        labels={"nilai": f"Indeks (base {index_base}=100)", "periode": "Periode"})
        fig1.add_hline(y=100, line_dash="dash", line_color="gray",
                        annotation_text=f"Baseline {index_base}=100")
        st.plotly_chart(fig1, use_container_width=True)

        # Grafik 2: Perubahan QTQ
        if "pct_perubahan_qtq" in df.columns:
            st.subheader("Persentase Perubahan IHPR per Kuartal (QTQ)")
            df_qtq = df.dropna(subset=["pct_perubahan_qtq"])
            if not df_qtq.empty:
                fig2 = px.bar(df_qtq.sort_values(["tahun", "kuartal_num"]),
                               x="periode", y="pct_perubahan_qtq", color="kota",
                               barmode="group",
                               labels={"pct_perubahan_qtq": "Perubahan QTQ (%)", "periode": "Periode"},
                               color_discrete_sequence=px.colors.qualitative.Set2)
                fig2.add_hline(y=0, line_dash="dash", line_color="gray")
                st.plotly_chart(fig2, use_container_width=True)

        # Grafik 3: Perbandingan terbaru antar kota
        st.subheader("Perbandingan IHPR Terbaru Antar Kota")
        df_latest = (df[df["tahun"] == df["tahun"].max()]
                       .groupby("kota")["nilai"].mean().reset_index()
                       .sort_values("nilai", ascending=False))
        fig3 = px.bar(df_latest, x="kota", y="nilai", color="nilai",
                       color_continuous_scale="Blues",
                       labels={"nilai": f"IHPR (base {index_base}=100)", "kota": "Kota"})
        fig3.add_hline(y=100, line_dash="dash", line_color="gray",
                        annotation_text=f"Baseline {index_base}")
        fig3.update_layout(coloraxis_showscale=False)
        st.plotly_chart(fig3, use_container_width=True)

        # Tabel
        st.subheader(f"Data Lengkap ({len(df):,} baris)")
        df_tampil = df[["id", "kota", "tipe", "tahun", "kuartal",
                         "nilai", "pct_perubahan_qtq", "index_base"]].copy()
        df_tampil["nilai"]             = df_tampil["nilai"].apply(lambda x: f"{x:.4f}")
        df_tampil["pct_perubahan_qtq"] = df_tampil["pct_perubahan_qtq"].apply(
            lambda x: f"{x:.4f}%" if pd.notna(x) else "-"
        )
        df_tampil.columns = ["id", "Kota", "Tipe", "Tahun", "Kuartal",
                              "Nilai Indeks", "Perubahan QTQ", "Base Indeks"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)
        st.download_button("⬇️ Download CSV",
                            data=df_tampil.to_csv(index=False).encode("utf-8"),
                            file_name="ihpr_data.csv", mime="text/csv",
                            use_container_width=True)

    # =========================================================================
    # TAB TAMBAH
    # =========================================================================
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Data IHPR")
            st.caption("Data disimpan ke tabel `analitik.ihpr`.")

            # Kota diambil dinamis
            with st.spinner("Memuat daftar kota..."):
                kota_ref = get_ihpr_kota_tersedia()

            with st.form("form_tambah_ihpr"):
                col_a, col_b = st.columns(2)
                with col_a:
                    kota_sel = st.selectbox("Kota", options=kota_ref + ["— Ketik manual —"])
                    if kota_sel == "— Ketik manual —":
                        kota = st.text_input("Nama Kota Baru")
                    else:
                        kota = kota_sel
                    tipe  = st.selectbox("Tipe Properti", options=TIPE_PROPERTI)
                    tahun = st.number_input("Tahun", min_value=2000, max_value=2100,
                                             value=2024, step=1)
                with col_b:
                    kuartal    = st.selectbox("Kuartal", options=KUARTAL_LIST)
                    nilai      = st.number_input("Nilai Indeks", min_value=0.0,
                                                  value=100.0, step=0.01, format="%.4f")
                    index_base = st.radio("Seri Index Base", options=[2018, 2002],
                                           horizontal=True)

                saved = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not kota or not kota.strip():
                    notif_gagal("Nama kota tidak boleh kosong.")
                else:
                    result = crud_create("analitik/ihpr", {
                        "kota"      : kota.strip(),
                        "tipe"      : tipe,
                        "tahun"     : int(tahun),
                        "kuartal"   : kuartal,
                        "nilai"     : float(nilai),
                        "index_base": int(index_base),
                    })
                    if result:
                        notif_sukses(
                            f"Data IHPR berhasil ditambahkan — "
                            f"{kota} {tipe} {kuartal} {int(tahun)} (ID: {result.get('id')})."
                        )
                        st.rerun()

    # =========================================================================
    # TAB EDIT
    # =========================================================================
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Data IHPR")
            st.caption(
                "⚠️ Backend harus mengembalikan kolom `id` dari tabel `analitik.ihpr` "
                "(bukan dari view `v_ihpr_gabungan`) agar fitur ini berfungsi."
            )

            # Filter index_base dulu untuk mempercepat load
            seri_edit = st.radio("Pilih Seri", options=[2018, 2002], horizontal=True,
                                  key="edit_seri_ihpr")
            with st.spinner("Memuat data IHPR..."):
                df_all = _load_ihpr_tabel(index_base=seri_edit)

            if df_all.empty:
                st.warning("Tidak ada data IHPR yang tersedia.")
            elif "row_id" not in df_all.columns:
                st.error(
                    "Kolom `id` tidak ditemukan dalam respons API. "
                    "Tambahkan `id` ke query `GET /analitik/ihpr` di backend "
                    "(query dari tabel `analitik.ihpr`, bukan view)."
                )
            else:
                col_e1, col_e2, col_e3 = st.columns(3)
                with col_e1:
                    kota_f = st.selectbox("Filter Kota",
                                           options=["Semua"] + sorted(df_all["kota"].dropna().unique()),
                                           key="edit_filter_kota_ihpr")
                with col_e2:
                    tahun_f = st.selectbox("Filter Tahun",
                                            options=["Semua"] + sorted(df_all["tahun"].dropna().unique(), reverse=True),
                                            key="edit_filter_tahun_ihpr")
                with col_e3:
                    tipe_f = st.selectbox("Filter Tipe",
                                           options=["Semua"] + TIPE_PROPERTI,
                                           key="edit_filter_tipe_ihpr")

                df_edit = df_all.copy()
                if kota_f  != "Semua": df_edit = df_edit[df_edit["kota"]  == kota_f]
                if tahun_f != "Semua": df_edit = df_edit[df_edit["tahun"] == tahun_f]
                if tipe_f  != "Semua": df_edit = df_edit[df_edit["tipe"]  == tipe_f]

                if df_edit.empty:
                    st.warning("Tidak ada data yang cocok dengan filter.")
                else:
                    opts = {
                        (
                            f"{d['row_id']} — "
                            f"{d['kota']} | "
                            f"{d['tipe']} | "
                            f"{d['kuartal']} {d['tahun']}"
                        ): d
                        for d in df_edit.to_dict("records")
                    }
                    pilihan  = st.selectbox("Pilih Record", options=list(opts.keys()),
                                             key="edit_sel_ihpr")
                    selected = opts[pilihan]

                    with st.form("form_edit_ihpr"):
                        st.caption(
                            f"**ID {selected['id']}** | Kota: **{selected['kota']}** | "
                            f"Tipe: **{selected['tipe']}** | "
                            f"Periode: **{selected['kuartal']} {selected['tahun']}** | "
                            f"Base: **{selected['index_base']}** — field ini tidak dapat diubah"
                        )
                        nilai_baru = st.number_input(
                            "Nilai Indeks", min_value=0.0,
                            value=float(selected["nilai"]) if pd.notna(selected["nilai"]) else 100.0,
                            step=0.01, format="%.4f"
                        )
                        updated = st.form_submit_button("✏️ Update", use_container_width=True)

                    if updated:
                        result = crud_update(
                            "analitik/ihpr",
                            selected["row_id"],   # "2018_10"
                            {"nilai": float(nilai_baru)}
                        )
                        if result:
                            notif_sukses(f"Data IHPR ID {selected['id']} berhasil diperbarui.")
                            st.rerun()

    # =========================================================================
    # TAB HAPUS
    # =========================================================================
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Data IHPR")

            seri_del = st.radio("Pilih Seri", options=[2018, 2002], horizontal=True,
                                 key="del_seri_ihpr")
            with st.spinner("Memuat data IHPR..."):
                df_all = _load_ihpr_tabel(index_base=seri_del)

            if df_all.empty:
                st.warning("Tidak ada data IHPR yang tersedia.")
            elif "id" not in df_all.columns:
                st.error(
                    "Kolom `id` tidak ditemukan dalam respons API. "
                    "Tambahkan `id` ke query `GET /analitik/ihpr` di backend."
                )
            else:
                col_h1, col_h2, col_h3 = st.columns(3)
                with col_h1:
                    kota_d = st.selectbox("Filter Kota",
                                           options=["Semua"] + sorted(df_all["kota"].dropna().unique()),
                                           key="del_filter_kota_ihpr")
                with col_h2:
                    tahun_d = st.selectbox("Filter Tahun",
                                            options=["Semua"] + sorted(df_all["tahun"].dropna().unique(), reverse=True),
                                            key="del_filter_tahun_ihpr")
                with col_h3:
                    tipe_d = st.selectbox("Filter Tipe",
                                           options=["Semua"] + TIPE_PROPERTI,
                                           key="del_filter_tipe_ihpr")

                df_del = df_all.copy()
                if kota_d  != "Semua": df_del = df_del[df_del["kota"]  == kota_d]
                if tahun_d != "Semua": df_del = df_del[df_del["tahun"] == tahun_d]
                if tipe_d  != "Semua": df_del = df_del[df_del["tipe"]  == tipe_d]

                if df_del.empty:
                    st.warning("Tidak ada data yang cocok dengan filter.")
                else:
                    opts = {
                        f"ID {d['id']} — {d['kota']} | {d['tipe']} | "
                        f"{d['kuartal']} {d['tahun']} | nilai: {d['nilai']:.4f}": d
                        for d in df_del.sort_values(["kota", "tahun", "kuartal_num"]).to_dict("records")
                    }
                    pilihan  = st.selectbox("Pilih Record", options=list(opts.keys()),
                                             key="del_sel_ihpr")
                    selected = opts[pilihan]

                    st.warning(
                        f"Anda akan menghapus secara permanen: "
                        f"**ID {selected['id']}** — **{selected['kota']}** | "
                        f"Tipe **{selected['tipe']}** | "
                        f"**{selected['kuartal']} {selected['tahun']}** | "
                        f"nilai: **{selected['nilai']:.4f}** | base: **{selected['index_base']}**"
                    )
                    if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_ihpr"):
                        result = crud_delete(
                            "analitik/ihpr",
                            selected["row_id"]   # "2018_10"
                        )
                        if result:
                            notif_sukses(f"Data IHPR ID {selected['id']} berhasil dihapus.")
                            st.rerun()