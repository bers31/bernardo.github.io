# views/wilayah.py
import streamlit as st
import pandas as pd
import plotly.express as px
import math
from api_client import get_semua_properti

def render():
    st.title("🗺️ Analitik Persebaran Wilayah")
    st.divider()

    prop_list = get_semua_properti()
    if not prop_list:
        st.warning("Tidak ada data properti yang tersedia.")
        return

    df = pd.DataFrame(prop_list)
    df["harga"] = pd.to_numeric(df["harga"], errors="coerce")
    df["tahun"] = pd.to_numeric(df["tahun"], errors="coerce")

    # ── Filter per kolom ──────────────────────────────────────────────────────
    st.subheader("🔽 Filter per Kolom")
    col_f1, col_f2, col_f3, col_f4 = st.columns(4)

    with col_f1:
        semua_kota = sorted(df["kabupaten_kota"].dropna().unique().tolist())
        pilih_kota = st.multiselect(
            "Filter Kota",
            options=["Semua"] + semua_kota,
            default=["Semua"],
            key="filter_kota"
        )
        aktif_kota = semua_kota if "Semua" in pilih_kota or not pilih_kota else pilih_kota

    with col_f2:
        semua_tipe = sorted(df["tipe_properti"].dropna().unique().tolist())
        pilih_tipe = st.multiselect(
            "Filter Tipe Properti",
            options=["Semua"] + semua_tipe,
            default=["Semua"],
            key="filter_tipe"
        )
        aktif_tipe = semua_tipe if "Semua" in pilih_tipe or not pilih_tipe else pilih_tipe

    with col_f3:
        semua_segmen = sorted(df["segmen_harga"].dropna().unique().tolist())
        pilih_segmen = st.multiselect(
            "Filter Segmen Harga",
            options=["Semua"] + semua_segmen,
            default=["Semua"],
            key="filter_segmen"
        )
        aktif_segmen = semua_segmen if "Semua" in pilih_segmen or not pilih_segmen else pilih_segmen

    with col_f4:
        semua_tahun = sorted(
            df["tahun"].dropna().astype(int).unique().tolist()
        )

        pilih_tahun = st.multiselect(
            "Filter Tahun",
            options=["Semua"] + semua_tahun,
            default=["Semua"],
            key="filter_tahun_wilayah"
        )

        aktif_tahun = (
            semua_tahun
            if "Semua" in pilih_tahun or not pilih_tahun
            else [int(t) for t in pilih_tahun]
        )

    # ── Slider Harga (dibulatkan terhadap step) ───────────────────────────────
    st.markdown("**Filter Rentang Harga**")
    STEP_HARGA    = 50_000_000
    harga_min_val = int(df["harga"].min() // STEP_HARGA * STEP_HARGA)
    harga_max_val = int(math.ceil(df["harga"].max() / STEP_HARGA) * STEP_HARGA)
    harga_range   = st.slider(
        "Rentang Harga (Rp)",
        min_value=harga_min_val,
        max_value=harga_max_val,
        value=(harga_min_val, harga_max_val),
        step=STEP_HARGA,
        format="Rp %d",
        key="filter_harga_range"
    )

    # ── Terapkan semua filter ─────────────────────────────────────────────────
    df_filtered = df[
        df["kabupaten_kota"].isin(aktif_kota) &
        df["tipe_properti"].isin(aktif_tipe) &
        df["segmen_harga"].isin(aktif_segmen) &
        df["tahun"].isin(aktif_tahun) &
        df["harga"].between(harga_range[0], harga_range[1])
    ]

    # ── Metrik ────────────────────────────────────────────────────────────────
    st.divider()
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Properti",  f"{len(df_filtered):,}")
    with col2:
        st.metric("Total Kabupaten/Kota",      f"{df_filtered['kabupaten_kota'].nunique():,}")
    with col3:
        st.metric("Harga Tertinggi",
                  f"Rp {df_filtered['harga'].max():,.0f}" if not df_filtered.empty else "-")
    with col4:
        st.metric("Harga Rata-rata",
                  f"Rp {df_filtered['harga'].mean():,.0f}" if not df_filtered.empty else "-")

    if df_filtered.empty:
        st.warning("Tidak ada data yang sesuai dengan filter yang dipilih.")
        return

    # ── Grafik Jumlah Properti per Kota ───────────────────────────────────────
    st.divider()
    st.subheader("Jumlah Properti per Kota")
    kota_count = df_filtered["kabupaten_kota"].value_counts().reset_index()
    kota_count.columns = ["Kabupaten/Kota", "Jumlah Properti"]
    fig1 = px.bar(
        kota_count.head(20),
        x="Kabupaten/Kota", y="Jumlah Properti",
        color="Jumlah Properti",
        color_continuous_scale="Blues"
    )
    fig1.update_layout(coloraxis_showscale=False)
    st.plotly_chart(fig1, use_container_width=True)

    # ── Grafik Rata-rata Harga per Kota ───────────────────────────────────────
    st.subheader("Rata-rata Harga Properti per Kota")
    harga_kota = df_filtered.groupby("kabupaten_kota")["harga"].mean().reset_index()
    harga_kota.columns = ["Kabupaten/Kota", "Rata-rata Harga"]
    harga_kota = harga_kota.sort_values("Rata-rata Harga", ascending=False).head(15)
    fig2 = px.bar(
        harga_kota,
        x="Rata-rata Harga", y="Kabupaten/Kota",
        orientation="h",
        color="Rata-rata Harga",
        color_continuous_scale="Oranges"
    )
    fig2.update_layout(
        yaxis={"categoryorder": "total ascending"},
        coloraxis_showscale=False
    )
    st.plotly_chart(fig2, use_container_width=True)

    # ── Grafik Distribusi Tipe per Kota ───────────────────────────────────────
    if len(aktif_kota) <= 10:
        st.subheader("Distribusi Tipe Properti per Kota")
        tipe_kota = df_filtered.groupby(
            ["kabupaten_kota", "tipe_properti"]
        ).size().reset_index(name="Jumlah")
        fig3 = px.bar(
            tipe_kota,
            x="kabupaten_kota", y="Jumlah",
            color="tipe_properti",
            barmode="stack",
            labels={"kabupaten_kota": "Kabupaten/Kota", "tipe_properti": "Tipe Properti"}
        )
        st.plotly_chart(fig3, use_container_width=True)

    # ── Tabel dengan pagination manual ───────────────────────────────────────
    ROWS_PER_PAGE = 1000
    st.divider()

    total_rows  = len(df_filtered)
    total_pages = max(1, (total_rows + ROWS_PER_PAGE - 1) // ROWS_PER_PAGE)

    st.subheader(f"Data Lengkap ({total_rows:,} data)")
    st.caption(
        f"Menampilkan {ROWS_PER_PAGE:,} baris per halaman untuk menjaga performa. "
        f"Total {total_pages} halaman."
    )

    # Inisialisasi dan validasi state halaman tabel
    if "wilayah_tabel_halaman" not in st.session_state:
        st.session_state["wilayah_tabel_halaman"] = 1
    if st.session_state["wilayah_tabel_halaman"] > total_pages:
        st.session_state["wilayah_tabel_halaman"] = 1

    # Kontrol navigasi halaman
    col_nav1, col_nav2, col_nav3, col_nav4, col_nav5 = st.columns([1, 1, 2, 1, 1])
    with col_nav1:
        if st.button("⏮ Pertama", use_container_width=True,
                     disabled=st.session_state["wilayah_tabel_halaman"] == 1):
            st.session_state["wilayah_tabel_halaman"] = 1
    with col_nav2:
        if st.button("◀ Sebelum", use_container_width=True,
                     disabled=st.session_state["wilayah_tabel_halaman"] == 1):
            st.session_state["wilayah_tabel_halaman"] -= 1
    with col_nav3:
        st.markdown(
            f"<div style='text-align:center; padding-top:8px;'>"
            f"Halaman <b>{st.session_state['wilayah_tabel_halaman']}</b> "
            f"dari <b>{total_pages}</b></div>",
            unsafe_allow_html=True
        )
    with col_nav4:
        if st.button("Sesudah ▶", use_container_width=True,
                     disabled=st.session_state["wilayah_tabel_halaman"] == total_pages):
            st.session_state["wilayah_tabel_halaman"] += 1
    with col_nav5:
        if st.button("Terakhir ⏭", use_container_width=True,
                     disabled=st.session_state["wilayah_tabel_halaman"] == total_pages):
            st.session_state["wilayah_tabel_halaman"] = total_pages

    # Slice data sesuai halaman aktif
    halaman   = st.session_state["wilayah_tabel_halaman"]
    idx_awal  = (halaman - 1) * ROWS_PER_PAGE
    idx_akhir = min(idx_awal + ROWS_PER_PAGE, total_rows)

    kolom_tampil = [
        "kabupaten_kota", "tipe_properti", "segmen_harga",
        "harga", "tahun", "luas_tanah_m2", "kamar_tidur"
    ]

    df_tampil = df_filtered.iloc[idx_awal:idx_akhir][
        [k for k in kolom_tampil if k in df_filtered.columns]
    ].copy()
    df_tampil["harga"] = df_tampil["harga"].apply(
        lambda x: f"Rp {x:,.0f}" if pd.notna(x) else "-"
    )
    df_tampil.columns = [
        "Kabupaten/Kota", "Tipe", "Segmen Harga",
        "Harga", "Tahun", "Luas Tanah (m²)", "Kamar Tidur"
    ][:len(df_tampil.columns)]

    st.caption(f"Baris {idx_awal + 1:,} – {idx_akhir:,} dari {total_rows:,}")
    st.dataframe(df_tampil, use_container_width=True, hide_index=True)

    # ── Tombol Download Seluruh Data ──────────────────────────────────────────
    # Menggunakan HTTP file download — bukan WebSocket — sehingga aman untuk data besar
    df_download = df_filtered[
        [k for k in kolom_tampil if k in df_filtered.columns]
    ].copy()
    df_download.columns = [
        "Kabupaten/Kota", "Tipe", "Segmen Harga",
        "Harga", "Tahun", "Luas Tanah (m2)", "Kamar Tidur"
    ][:len(df_download.columns)]

    st.download_button(
        label=f"⬇️ Download Seluruh Data ({total_rows:,} baris) sebagai CSV",
        data=df_download.to_csv(index=False).encode("utf-8"),
        file_name="wilayah_wiraky.csv",
        mime="text/csv",
        use_container_width=True
    )