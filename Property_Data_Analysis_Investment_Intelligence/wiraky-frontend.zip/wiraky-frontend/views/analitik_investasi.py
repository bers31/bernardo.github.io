# views/analitik_investasi.py
# Dashboard utama analitik investasi properti — menggabungkan semua data

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from api_client import get_investasi_properti_cached, clear_investasi_cache
import time as _time

ROWS_PER_PAGE_INV = 1000

def render():
    st.title("💼 Analitik Investasi Properti")
    st.divider()
    st.caption(
        "Dashboard ini menggabungkan data properti operasional dengan data "
        "makroekonomi (IHPR, inflasi, BI Rate, populasi) untuk menghasilkan "
        "analisis mendalam bagi pengambilan keputusan investasi."
    )

    # ── Info cache ────────────────────────────────────────────────────────────
    if "investasi_cache_time" in st.session_state:
        usia  = int(_time.time() - st.session_state["investasi_cache_time"])
        menit = usia // 60
        st.caption(f"Data dimuat {menit} menit yang lalu. Cache berlaku 60 menit.")

    with st.spinner("Memuat data analitik investasi..."):
        data = get_investasi_properti_cached()

    if not data:
        st.warning("Data analitik investasi belum tersedia.")
        if st.button("🔄 Coba Muat Ulang"):
            clear_investasi_cache()
            st.rerun()
        return

    df = pd.DataFrame(data)

    # Konversi kolom numerik
    numerik_cols = [
        "harga", "luas_tanah_m2", "luas_bangunan_m2",
        "ihpr_terbaru", "ihpr_pct_perubahan",
        "inflasi_tahunan_terbaru", "bi_rate_terkini",
        "total_populasi", "harga_per_m2_tanah"
    ]
    for col in numerik_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # ── Filter ────────────────────────────────────────────────────────────────
    st.subheader("🔽 Filter")
    col_f1, col_f2, col_f3 = st.columns(3)

    with col_f1:
        semua_kota = sorted(df["kabupaten_kota"].dropna().unique().tolist())
        pilih_kota = st.multiselect(
            "Filter Kota", options=["Semua"] + semua_kota,
            default=["Semua"], key="filter_kota_inv"
        )
        aktif_kota = semua_kota if "Semua" in pilih_kota or not pilih_kota else pilih_kota

    with col_f2:
        semua_tipe = sorted(df["tipe_properti"].dropna().unique().tolist())
        pilih_tipe = st.multiselect(
            "Filter Tipe", options=["Semua"] + semua_tipe,
            default=["Semua"], key="filter_tipe_inv"
        )
        aktif_tipe = semua_tipe if "Semua" in pilih_tipe or not pilih_tipe else pilih_tipe

    with col_f3:
        semua_segmen = sorted(df["segmen_harga"].dropna().unique().tolist())
        pilih_segmen = st.multiselect(
            "Filter Segmen", options=["Semua"] + semua_segmen,
            default=["Semua"], key="filter_segmen_inv"
        )
        aktif_segmen = semua_segmen if "Semua" in pilih_segmen or not pilih_segmen else pilih_segmen

    df_filtered = df[
        df["kabupaten_kota"].isin(aktif_kota) &
        df["tipe_properti"].isin(aktif_tipe) &
        df["segmen_harga"].isin(aktif_segmen)
    ]

    if df_filtered.empty:
        st.warning("Tidak ada data yang sesuai dengan filter.")
        return

    # ── Metrik ringkasan makroekonomi ─────────────────────────────────────────
    st.divider()
    bi_rate = df_filtered["bi_rate_terkini"].dropna().iloc[0] if not df_filtered["bi_rate_terkini"].dropna().empty else None

    col1, col2, col3, col4, col5 = st.columns(5)
    col1.metric("Total Properti",       f"{len(df_filtered):,}")
    col2.metric("BI Rate Terkini",      f"{bi_rate:.2f}%" if bi_rate else "-",
                help="Suku bunga acuan Bank Indonesia")
    col3.metric("IHPR Rata-rata",
                f"{df_filtered['ihpr_terbaru'].mean():.2f}" if not df_filtered["ihpr_terbaru"].isna().all() else "-",
                help="Rata-rata Indeks Harga Properti Residensial")
    col4.metric("Inflasi Rata-rata",
                f"{df_filtered['inflasi_tahunan_terbaru'].mean():.4f}%" if not df_filtered["inflasi_tahunan_terbaru"].isna().all() else "-",
                help="Rata-rata inflasi tahunan provinsi")
    col5.metric("Harga Median",         f"Rp {df_filtered['harga'].median():,.0f}")

    # ── Analisis 1: Skor Investasi per Kota ───────────────────────────────────
    st.divider()
    st.subheader("📊 Skor Potensi Investasi per Kota")
    st.caption(
        "Skor dihitung dari kombinasi apresiasi IHPR, inflasi terkendali, "
        "dan populasi besar. Semakin tinggi skor, semakin menarik untuk investasi."
    )

    df_kota = df_filtered.groupby("kabupaten_kota").agg(
        jumlah_properti  = ("harga", "count"),
        harga_median     = ("harga", "median"),
        ihpr_rata        = ("ihpr_terbaru", "mean"),
        ihpr_pct_rata    = ("ihpr_pct_perubahan", "mean"),
        inflasi_rata     = ("inflasi_tahunan_terbaru", "mean"),
        populasi_rata    = ("total_populasi", "mean"),
        harga_m2_rata    = ("harga_per_m2_tanah", "mean")
    ).reset_index()

    # Normalisasi 0-100 untuk setiap metrik
    def norm(series):
        mn, mx = series.min(), series.max()
        if mx == mn:
            return pd.Series([50.0] * len(series), index=series.index)
        return (series - mn) / (mx - mn) * 100

    df_kota_valid = df_kota.dropna(subset=["ihpr_rata", "inflasi_rata", "populasi_rata"])

    if not df_kota_valid.empty:
        # Skor: IHPR tinggi (+), inflasi rendah (+), populasi besar (+)
        df_kota_valid = df_kota_valid.copy()
        df_kota_valid["skor_ihpr"]     = norm(df_kota_valid["ihpr_rata"])
        df_kota_valid["skor_inflasi"]  = 100 - norm(df_kota_valid["inflasi_rata"].abs())
        df_kota_valid["skor_populasi"] = norm(df_kota_valid["populasi_rata"])
        df_kota_valid["skor_total"]    = (
            df_kota_valid["skor_ihpr"]     * 0.40 +
            df_kota_valid["skor_inflasi"]  * 0.30 +
            df_kota_valid["skor_populasi"] * 0.30
        ).round(2)
        df_kota_valid = df_kota_valid.sort_values("skor_total", ascending=False)

        # Grafik skor investasi
        fig_skor = px.bar(
            df_kota_valid.head(15),
            x="skor_total", y="kabupaten_kota",
            orientation="h",
            color="skor_total",
            color_continuous_scale="RdYlGn",
            labels={"skor_total": "Skor Potensi (0-100)", "kabupaten_kota": "Kabupaten/Kota"},
            text="skor_total"
        )
        fig_skor.update_traces(texttemplate="%{text:.1f}", textposition="outside")
        fig_skor.update_layout(coloraxis_showscale=False,
                               yaxis={"categoryorder": "total ascending"})
        st.plotly_chart(fig_skor, use_container_width=True)

        # Tabel skor detail
        df_skor_tampil = df_kota_valid[[
            "kabupaten_kota", "skor_total", "skor_ihpr", "skor_inflasi",
            "skor_populasi", "jumlah_properti", "harga_median"
        ]].copy()
        df_skor_tampil["harga_median"] = df_skor_tampil["harga_median"].apply(
            lambda x: f"Rp {x:,.0f}"
        )
        df_skor_tampil.columns = [
            "Kabupaten/Kota", "Skor Total", "Skor IHPR",
            "Skor Inflasi", "Skor Populasi",
            "Jumlah Properti", "Harga Median"
        ]
        st.dataframe(df_skor_tampil, use_container_width=True, hide_index=True)

    # ── Analisis 2: Scatter IHPR vs Harga ────────────────────────────────────
    st.divider()
    st.subheader("🔵 Hubungan Harga Properti vs Indeks IHPR")
    st.caption(
        "Properti di kota dengan IHPR tinggi namun harga listing masih rendah "
        "mengindikasikan potensi apresiasi yang belum terefleksikan dalam harga pasar."
    )

    df_scatter = df_filtered.dropna(subset=["ihpr_terbaru", "harga"])
    if not df_scatter.empty:
        fig_scatter = px.scatter(
            df_scatter.sample(min(2000, len(df_scatter))),
            x="ihpr_terbaru", y="harga",
            color="kabupaten_kota",
            size="luas_tanah_m2",
            hover_data=["tipe_properti", "segmen_harga", "kamar_tidur"],
            labels={
                "ihpr_terbaru": "Indeks IHPR (base 2018=100)",
                "harga"        : "Harga Properti (Rp)",
                "luas_tanah_m2": "Luas Tanah (m²)"
            },
            opacity=0.6
        )
        st.plotly_chart(fig_scatter, use_container_width=True)

    # ── Analisis 3: Matriks Risiko-Peluang ────────────────────────────────────
    st.divider()
    st.subheader("🎯 Matriks Risiko-Peluang per Kota")
    st.caption(
        "**Kuadran kanan-atas** (IHPR tinggi + inflasi rendah) = zona investasi optimal. "
        "Ukuran gelembung = total populasi provinsi."
    )

    if not df_kota_valid.empty:
        fig_matrix = px.scatter(
            df_kota_valid,
            x="inflasi_rata",
            y="ihpr_rata",
            size="populasi_rata",
            color="skor_total",
            hover_name="kabupaten_kota",
            hover_data={
                "jumlah_properti" : True,
                "harga_median"    : ":,.0f",
                "skor_total"      : ":.2f"
            },
            color_continuous_scale="RdYlGn",
            size_max=60,
            labels={
                "inflasi_rata"  : "Rata-rata Inflasi (%)",
                "ihpr_rata"     : "Rata-rata IHPR",
                "populasi_rata" : "Total Populasi",
                "skor_total"    : "Skor Investasi"
            }
        )
        # Tambahkan garis referensi di median
        fig_matrix.add_hline(
            y=df_kota_valid["ihpr_rata"].median(),
            line_dash="dash", line_color="gray",
            annotation_text="Median IHPR"
        )
        fig_matrix.add_vline(
            x=df_kota_valid["inflasi_rata"].median(),
            line_dash="dash", line_color="gray",
            annotation_text="Median Inflasi"
        )
        # Label kota di grafik
        for _, row in df_kota_valid.iterrows():
            fig_matrix.add_annotation(
                x=row["inflasi_rata"],
                y=row["ihpr_rata"],
                text=row["kabupaten_kota"],
                showarrow=False,
                font=dict(size=9),
                yshift=12
            )
        st.plotly_chart(fig_matrix, use_container_width=True)

    # ── Analisis 4: Tren BI Rate vs Harga Properti ───────────────────────────
    st.divider()
    st.subheader("📉 Konteks BI Rate terhadap Pasar Properti")
    if bi_rate:
        estimasi_cicilan_pct = bi_rate + 3.5  # estimasi spread KPR
        harga_median         = df_filtered["harga"].median()
        estimasi_cicilan     = (harga_median * (estimasi_cicilan_pct / 100 / 12)) / \
                               (1 - (1 + estimasi_cicilan_pct / 100 / 12) ** -240)

        col1, col2, col3 = st.columns(3)
        col1.metric(
            "BI Rate",
            f"{bi_rate:.2f}%",
            help="Suku bunga acuan saat ini"
        )
        col2.metric(
            "Estimasi Suku Bunga KPR",
            f"{estimasi_cicilan_pct:.2f}%",
            help="BI Rate + spread rata-rata KPR 3.5%"
        )
        col3.metric(
            "Estimasi Cicilan KPR/Bulan",
            f"Rp {estimasi_cicilan:,.0f}",
            help=f"Untuk properti seharga Rp {harga_median:,.0f} dengan tenor 20 tahun"
        )
        st.caption(
            f"*Estimasi cicilan dihitung untuk properti dengan harga median "
            f"Rp {harga_median:,.0f}, tenor 20 tahun (240 bulan), "
            f"suku bunga KPR estimasi {estimasi_cicilan_pct:.2f}% per tahun.*"
        )

    # ── Tabel Data Lengkap dengan Paginasi ───────────────────────────────────
    st.divider()

    kolom_dl = [
        "properti_id", "kabupaten_kota", "nama_area", "tipe_properti", "segmen_harga",
        "harga", "luas_tanah_m2", "harga_per_m2_tanah",
        "nama_provinsi", "ihpr_terbaru", "ihpr_pct_perubahan",
        "inflasi_tahunan_terbaru", "bi_rate_terkini", "total_populasi"
    ]
    df_dl = df_filtered[[k for k in kolom_dl if k in df_filtered.columns]].copy()

    total_rows_inv  = len(df_dl)
    total_pages_inv = max(1, (total_rows_inv + ROWS_PER_PAGE_INV - 1) // ROWS_PER_PAGE_INV)

    st.subheader(f"📋 Data Lengkap Investasi ({total_rows_inv:,} data)")
    st.caption(
        f"Menampilkan {ROWS_PER_PAGE_INV:,} baris per halaman. "
        f"Total {total_pages_inv} halaman. "
        "Tombol download di bawah akan mengunduh **seluruh** data."
    )

    if "inv_tabel_halaman" not in st.session_state:
        st.session_state["inv_tabel_halaman"] = 1
    if st.session_state["inv_tabel_halaman"] > total_pages_inv:
        st.session_state["inv_tabel_halaman"] = 1

    col_n1, col_n2, col_n3, col_n4, col_n5 = st.columns([1, 1, 2, 1, 1])
    with col_n1:
        if st.button("⏮ Pertama", use_container_width=True, key="inv_hal_pertama",
                     disabled=st.session_state["inv_tabel_halaman"] == 1):
            st.session_state["inv_tabel_halaman"] = 1
            st.rerun()
    with col_n2:
        if st.button("◀ Sebelum", use_container_width=True, key="inv_hal_sebelum",
                     disabled=st.session_state["inv_tabel_halaman"] == 1):
            st.session_state["inv_tabel_halaman"] -= 1
            st.rerun()
    with col_n3:
        st.markdown(
            f"<div style='text-align:center;padding-top:8px;'>"
            f"Halaman <b>{st.session_state['inv_tabel_halaman']}</b> "
            f"dari <b>{total_pages_inv}</b></div>",
            unsafe_allow_html=True
        )
    with col_n4:
        if st.button("Sesudah ▶", use_container_width=True, key="inv_hal_sesudah",
                     disabled=st.session_state["inv_tabel_halaman"] == total_pages_inv):
            st.session_state["inv_tabel_halaman"] += 1
            st.rerun()
    with col_n5:
        if st.button("Terakhir ⏭", use_container_width=True, key="inv_hal_terakhir",
                     disabled=st.session_state["inv_tabel_halaman"] == total_pages_inv):
            st.session_state["inv_tabel_halaman"] = total_pages_inv
            st.rerun()

    halaman_inv   = st.session_state["inv_tabel_halaman"]
    idx_awal_inv  = (halaman_inv - 1) * ROWS_PER_PAGE_INV
    idx_akhir_inv = min(idx_awal_inv + ROWS_PER_PAGE_INV, total_rows_inv)

    df_tampil_inv = df_dl.iloc[idx_awal_inv:idx_akhir_inv].copy()
    df_tampil_inv["harga"] = df_tampil_inv["harga"].apply(
        lambda x: f"Rp {x:,.0f}" if pd.notna(x) else "-"
    )
    st.caption(f"Baris {idx_awal_inv + 1:,} – {idx_akhir_inv:,} dari {total_rows_inv:,}")
    st.dataframe(df_tampil_inv, use_container_width=True, hide_index=True)

    # ── Download & Refresh ────────────────────────────────────────────────────
    st.divider()
    col_dl1, col_dl2 = st.columns(2)
    with col_dl1:
        st.download_button(
            label=f"⬇️ Download Data Investasi ({len(df_dl):,} baris)",
            data=df_dl.to_csv(index=False).encode("utf-8"),
            file_name="analitik_investasi_properti.csv",
            mime="text/csv", use_container_width=True
        )
    with col_dl2:
        if st.button("🔄 Refresh Data Analitik",
                     help="Hapus cache dan ambil data terbaru",
                     use_container_width=True):
            clear_investasi_cache()
            st.rerun()