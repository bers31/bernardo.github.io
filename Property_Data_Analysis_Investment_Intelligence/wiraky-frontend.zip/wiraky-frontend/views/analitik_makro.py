# views/analitik_makro.py
# Dashboard BI Rate & PDB dengan CRUD penuh untuk admin
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import date
from api_client import (
    fetch, is_admin,
    crud_create, crud_update, crud_delete,
    notif_sukses, notif_gagal, tampilkan_notif
)

ROWS_PER_PAGE = 1000   # baris per halaman untuk tabel PDB

# ── Helper fungsi data ────────────────────────────────────────────────────────
def get_bi_rate(tanggal_mulai=None, tanggal_akhir=None):
    params = {}

    if tanggal_mulai:
        params["tanggal_mulai"] = str(tanggal_mulai)

    if tanggal_akhir:
        params["tanggal_akhir"] = str(tanggal_akhir)

    return fetch("analitik/bi-rate", params) or []

def get_bi_rate_terkini():
    return fetch("analitik/bi-rate/terkini") or {"nilai_pct": None, "tanggal": None}

def get_pdb(komponen=None, level=None, laju=None, tahun=None, kuartal=None):
    params = {}
    if komponen: params["komponen"]         = komponen
    if level:    params["level"]            = level
    if laju:     params["laju_pertumbuhan"] = laju
    if tahun:    params["tahun"]            = tahun
    if kuartal:  params["kuartal"]          = kuartal
    return fetch("analitik/pdb", params) or []

def get_pdb_komponen_tersedia():
    return fetch("analitik/pdb/komponen-tersedia") or []

def get_pdb_laju_tersedia():
    return fetch("analitik/pdb/laju-tersedia") or []

# ── Render utama ──────────────────────────────────────────────────────────────
def render():
    st.title("🏦 Analitik Makroekonomi — BI Rate & PDB")
    st.divider()
    tampilkan_notif()
    tab_bi, tab_pdb = st.tabs(["📊 BI Rate", "📈 PDB"])

    # ══════════════════════════════════════════════════════════════════════════
    # TAB BI RATE
    # ══════════════════════════════════════════════════════════════════════════
    with tab_bi:
        st.subheader("BI 7-Day Reverse Repo Rate")
        st.caption(
            "BI Rate adalah suku bunga acuan Bank Indonesia yang langsung "
            "mempengaruhi suku bunga KPR dan biaya modal investasi properti."
        )
        bi_terkini = get_bi_rate_terkini()
        if bi_terkini["nilai_pct"] is not None:
            col1, col2 = st.columns(2)
            col1.metric("BI Rate Terkini",   f"{bi_terkini['nilai_pct']}%")
            col2.metric("Tanggal Penetapan", str(bi_terkini["tanggal"]))
        st.divider()

        if is_admin():
            sub_lihat, sub_tambah, sub_edit, sub_hapus = st.tabs([
                "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
            ])
        else:
            sub_lihat  = st.tabs(["📊 Lihat Data"])[0]
            sub_tambah = sub_edit = sub_hapus = None

        # ── Sub-tab Lihat BI Rate ─────────────────────────────────────────────
        with sub_lihat:
            col_f1, col_f2 = st.columns(2)
            with col_f1:
                tanggal_mulai = st.date_input(
                    "Tanggal Mulai",
                    value=date(2016, 1, 1),
                    key="bi_tanggal_mulai"
                )

            with col_f2:
                tanggal_akhir = st.date_input(
                    "Tanggal Akhir",
                    value=date.today(),
                    key="bi_tanggal_akhir"
                )

            with st.spinner("Memuat data BI Rate..."):
                bi_data = get_bi_rate(
                    tanggal_mulai=tanggal_mulai,
                    tanggal_akhir=tanggal_akhir
                )
            if not bi_data:
                st.warning("Belum ada data BI Rate.")
            else:
                df_bi = pd.DataFrame(bi_data)
                df_bi["tanggal"]   = pd.to_datetime(df_bi["tanggal"])
                df_bi["nilai_pct"] = pd.to_numeric(df_bi["nilai_pct"], errors="coerce")
                df_bi = df_bi.sort_values("tanggal")

                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Total Data Poin",   f"{len(df_bi):,}")
                m2.metric("BI Rate Tertinggi", f"{df_bi['nilai_pct'].max():.2f}%")
                m3.metric("BI Rate Terendah",  f"{df_bi['nilai_pct'].min():.2f}%")
                m4.metric("BI Rate Rata-rata", f"{df_bi['nilai_pct'].mean():.2f}%")

                fig_bi = go.Figure()
                fig_bi.add_trace(go.Scatter(
                    x=df_bi["tanggal"], y=df_bi["nilai_pct"],
                    mode="lines+markers", name="BI Rate (%)",
                    line=dict(color="#1a56db", width=2), marker=dict(size=4),
                    fill="tozeroy", fillcolor="rgba(26,86,219,0.1)"
                ))
                fig_bi.update_layout(
                    title=f"Tren BI Rate {tanggal_mulai:%d %b %Y} – {tanggal_akhir:%d %b %Y}",
                    xaxis_title="Tanggal", yaxis_title="BI Rate (%)",
                    hovermode="x unified"
                )
                st.plotly_chart(fig_bi, use_container_width=True)

                st.subheader(f"Data Lengkap ({len(df_bi):,} baris)")
                df_tampil = df_bi[["id", "tanggal", "nilai_pct"]].copy()
                df_tampil["tanggal"] = df_tampil["tanggal"].dt.strftime("%d %B %Y")
                df_tampil.columns    = ["ID", "Tanggal", "BI Rate (%)"]
                st.dataframe(df_tampil, use_container_width=True,
                             hide_index=True, height=300)
                st.download_button(
                    label="⬇️ Download CSV",
                    data=df_tampil.to_csv(index=False).encode("utf-8"),
                    file_name="bi_rate.csv", mime="text/csv",
                    use_container_width=True
                )

        # ── Sub-tab Tambah BI Rate ────────────────────────────────────────────
        if sub_tambah:
            with sub_tambah:
                st.subheader("Tambah Data BI Rate Baru")
                with st.form("form_tambah_bi"):
                    tgl   = st.date_input("Tanggal Penetapan",
                                          value=date.today(), key="bi_tgl_baru")
                    nilai = st.number_input("Nilai BI Rate (%)", min_value=0.0,
                                            max_value=100.0, step=0.25,
                                            value=5.50, key="bi_val_baru")
                    saved = st.form_submit_button("💾 Simpan", use_container_width=True)
                if saved:
                    result = crud_create("analitik/bi-rate", {
                        "tanggal"  : str(tgl),
                        "nilai_pct": float(nilai)
                    })
                    if result:
                        notif_sukses(f"BI Rate {nilai}% tanggal {tgl} berhasil ditambahkan.")
                        st.rerun()

        # ── Sub-tab Edit BI Rate ──────────────────────────────────────────────
        if sub_edit:
            with sub_edit:
                st.subheader("Edit Data BI Rate")
                with st.spinner("Memuat data..."):
                    bi_all = get_bi_rate()
                if not bi_all:
                    st.warning("Tidak ada data BI Rate.")
                else:
                    options  = {
                        f"ID {r['id']} — {r['tanggal']} ({r['nilai_pct']}%)": r
                        for r in bi_all
                    }
                    pilihan  = st.selectbox("Pilih Data BI Rate",
                                            options=list(options.keys()),
                                            key="bi_edit_sel")
                    selected = options[pilihan]
                    with st.form("form_edit_bi"):
                        st.caption(
                            f"Tanggal: **{selected['tanggal']}** (tidak dapat diubah)"
                        )
                        nilai_baru = st.number_input(
                            "Nilai BI Rate (%)", min_value=0.0, max_value=100.0,
                            step=0.25, value=float(selected["nilai_pct"]),
                            key="bi_val_edit"
                        )
                        updated = st.form_submit_button("✏️ Update",
                                                        use_container_width=True)
                    if updated:
                        result = crud_update("analitik/bi-rate",
                                             str(selected["id"]),
                                             {"nilai_pct": float(nilai_baru)})
                        if result:
                            notif_sukses(f"BI Rate ID {selected['id']} berhasil diperbarui.")
                            st.rerun()

        # ── Sub-tab Hapus BI Rate ─────────────────────────────────────────────
        if sub_hapus:
            with sub_hapus:
                st.subheader("Hapus Data BI Rate")
                with st.spinner("Memuat data..."):
                    bi_all = get_bi_rate()
                if not bi_all:
                    st.warning("Tidak ada data BI Rate.")
                else:
                    options  = {
                        f"ID {r['id']} — {r['tanggal']} ({r['nilai_pct']}%)": r
                        for r in bi_all
                    }
                    pilihan  = st.selectbox("Pilih Data BI Rate",
                                            options=list(options.keys()),
                                            key="bi_hapus_sel")
                    selected = options[pilihan]
                    st.warning(
                        f"Anda akan menghapus data BI Rate "
                        f"**{selected['nilai_pct']}%** tanggal **{selected['tanggal']}**."
                    )
                    if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_bi"):
                        result = crud_delete("analitik/bi-rate", str(selected["id"]))
                        if result:
                            notif_sukses(f"Data BI Rate ID {selected['id']} berhasil dihapus.")
                            st.rerun()

    # ══════════════════════════════════════════════════════════════════════════
    # TAB PDB
    # ══════════════════════════════════════════════════════════════════════════
    with tab_pdb:
        st.subheader("Laju Pertumbuhan PDB (Seri 2010)")
        st.caption(
            "Pertumbuhan PDB mencerminkan kondisi ekonomi secara keseluruhan. "
            "Pilih laju **y-on-y** untuk perbandingan yang konsisten dengan IHPR dan inflasi."
        )

        if is_admin():
            sub_lihat_p, sub_tambah_p, sub_edit_p, sub_hapus_p = st.tabs([
                "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
            ])
        else:
            sub_lihat_p  = st.tabs(["📊 Lihat Data"])[0]
            sub_tambah_p = sub_edit_p = sub_hapus_p = None

        # ── Sub-tab Lihat PDB ─────────────────────────────────────────────────
        with sub_lihat_p:
            col_f1, col_f2, col_f3 = st.columns(3)
            with col_f1:
                laju_list  = get_pdb_laju_tersedia()
                pilih_laju = st.multiselect("Jenis Laju Pertumbuhan",
                                            options=["Semua"] + laju_list,
                                            default=["Semua"], key="pdb_laju_lihat")
                aktif_laju = laju_list if "Semua" in pilih_laju or not pilih_laju else pilih_laju
            with col_f2:
                pilih_level = st.multiselect("Level",
                                            options=["Semua", "detail", "sektor", "subsektor"],
                                            default=["Semua"], key="pdb_level_lihat")
                aktif_level = ["detail", "sektor", "subsektor"] if "Semua" in pilih_level or not pilih_level else pilih_level
            with col_f3:
                pilih_kuartal = st.multiselect("Kuartal",
                                                options=["Semua", "QI", "QII", "QIII", "QIV"],
                                                default=["Semua"], key="pdb_kuartal_lihat")
                aktif_kuartal = ["QI", "QII", "QIII", "QIV"] if "Semua" in pilih_kuartal or not pilih_kuartal else pilih_kuartal

            with st.spinner("Memuat data PDB..."):
                pdb_data = get_pdb()

            if not pdb_data:
                st.warning("Belum ada data PDB.")
            else:
                df_pdb = pd.DataFrame(pdb_data)
                semua_tahun_pdb = sorted(df_pdb["tahun"].dropna().unique().tolist(), reverse=True)
                pilih_tahun_pdb = st.multiselect("Filter Tahun",
                                                options=["Semua"] + semua_tahun_pdb,
                                                default=["Semua"], key="pdb_tahun_lihat")
                aktif_tahun_pdb = semua_tahun_pdb if "Semua" in pilih_tahun_pdb or not pilih_tahun_pdb \
                                else [int(t) for t in pilih_tahun_pdb]

                df_pdb = df_pdb[
                    df_pdb["laju_pertumbuhan"].isin(aktif_laju) &
                    df_pdb["level"].isin(aktif_level) &
                    df_pdb["kuartal"].isin(aktif_kuartal) &
                    df_pdb["tahun"].isin(aktif_tahun_pdb)   # ← tambah ini
                ]

                # ── Metrik (kolom terpisah dari BI Rate) ─────────────────────
                pm1, pm2, pm3, pm4 = st.columns(4)
                pm1.metric("Total Data",    f"{len(df_pdb):,}")
                pm2.metric("Nilai Maksimum", f"{df_pdb['nilai'].max():.2f}%")
                pm3.metric("Nilai Minimum",  f"{df_pdb['nilai'].min():.2f}%")
                pm4.metric("Rata-rata",      f"{df_pdb['nilai'].mean():.2f}%")

                # ── Persiapan urutan kuartal ──────────────────────────────────
                kuartal_order = {"QI": 1, "QII": 2, "QIII": 3, "QIV": 4,
                                 1: 1, 2: 2, 3: 3, 4: 4}
                df_pdb["kuartal_sort"] = df_pdb["kuartal"].map(kuartal_order).fillna(0)
                df_pdb["periode"]      = (df_pdb["tahun"].astype(str)
                                          + " " + df_pdb["kuartal"].astype(str))

                # ── Filter komponen untuk grafik ──────────────────────────────
                semua_komponen  = sorted(df_pdb["komponen"].dropna().unique().tolist())
                filter_komponen = st.multiselect("Filter Komponen (Grafik)",
                                                options=["Semua"] + semua_komponen,
                                                default=["Semua"], key="pdb_filter_komponen")
                aktif_komponen  = semua_komponen if "Semua" in filter_komponen or not filter_komponen \
                                else filter_komponen
                df_plot = df_pdb[df_pdb["komponen"].isin(aktif_komponen)].copy()

                # ── Grafik Tren PDB ───────────────────────────────────────────
                fig_pdb = px.line(
                    df_plot.sort_values(["tahun", "kuartal_sort"]),
                    x="periode", y="nilai", color="komponen",
                    markers=True,
                    labels={"nilai": "Laju Pertumbuhan (%)", "periode": "Periode"}
                )
                fig_pdb.add_hline(y=0, line_dash="dash", line_color="gray")
                st.plotly_chart(fig_pdb, use_container_width=True)

                # ── Tabel dengan Pagination ───────────────────────────────────
                total_rows  = len(df_pdb)
                total_pages = max(1, (total_rows + ROWS_PER_PAGE - 1) // ROWS_PER_PAGE)

                st.subheader(f"Data Lengkap ({total_rows:,} baris)")
                st.caption(
                    f"Menampilkan {ROWS_PER_PAGE:,} baris per halaman. "
                    f"Total {total_pages} halaman."
                )

                # Reset halaman jika filter berubah dan halaman melebihi total
                if "pdb_tabel_halaman" not in st.session_state:
                    st.session_state["pdb_tabel_halaman"] = 1
                if st.session_state["pdb_tabel_halaman"] > total_pages:
                    st.session_state["pdb_tabel_halaman"] = 1

                # Navigasi halaman
                col_n1, col_n2, col_n3, col_n4, col_n5 = st.columns([1, 1, 2, 1, 1])
                with col_n1:
                    if st.button("⏮ Pertama", use_container_width=True,
                                 disabled=st.session_state["pdb_tabel_halaman"] == 1,
                                 key="pdb_page_first"):
                        st.session_state["pdb_tabel_halaman"] = 1
                with col_n2:
                    if st.button("◀ Sebelum", use_container_width=True,
                                 disabled=st.session_state["pdb_tabel_halaman"] == 1,
                                 key="pdb_page_prev"):
                        st.session_state["pdb_tabel_halaman"] -= 1
                with col_n3:
                    st.markdown(
                        f"<div style='text-align:center;padding-top:8px;'>"
                        f"Halaman <b>{st.session_state['pdb_tabel_halaman']}</b> "
                        f"dari <b>{total_pages}</b></div>",
                        unsafe_allow_html=True
                    )
                with col_n4:
                    if st.button("Sesudah ▶", use_container_width=True,
                                 disabled=st.session_state["pdb_tabel_halaman"] == total_pages,
                                 key="pdb_page_next"):
                        st.session_state["pdb_tabel_halaman"] += 1
                with col_n5:
                    if st.button("Terakhir ⏭", use_container_width=True,
                                 disabled=st.session_state["pdb_tabel_halaman"] == total_pages,
                                 key="pdb_page_last"):
                        st.session_state["pdb_tabel_halaman"] = total_pages

                halaman   = st.session_state["pdb_tabel_halaman"]
                idx_awal  = (halaman - 1) * ROWS_PER_PAGE
                idx_akhir = min(idx_awal + ROWS_PER_PAGE, total_rows)

                # Tabel halaman saat ini
                kolom_tabel = ["id", "komponen", "level", "laju_pertumbuhan",
                               "tahun", "kuartal", "nilai"]
                df_page   = df_pdb.iloc[idx_awal:idx_akhir][
                    [k for k in kolom_tabel if k in df_pdb.columns]
                ].copy()
                df_tampil = df_page.copy()
                df_tampil["nilai"] = (
                    pd.to_numeric(df_tampil["nilai"], errors="coerce")
                    .round(4).astype(str) + "%"
                )
                df_tampil.columns = ["ID", "Komponen", "Level", "Jenis Laju",
                                     "Tahun", "Kuartal", "Nilai"]

                st.caption(f"Baris {idx_awal + 1:,} – {idx_akhir:,} dari {total_rows:,}")
                st.dataframe(df_tampil, use_container_width=True,
                             hide_index=True, height=400)

                # Download SEMUA data (bukan hanya halaman ini)
                df_dl = df_pdb[
                    [k for k in kolom_tabel if k in df_pdb.columns]
                ].copy()
                df_dl["nilai"] = pd.to_numeric(df_dl["nilai"], errors="coerce").round(4)
                df_dl.columns  = ["ID", "Komponen", "Level", "Jenis Laju",
                                   "Tahun", "Kuartal", "Nilai (%)"]
                st.download_button(
                    label=f"⬇️ Download Seluruh Data ({total_rows:,} baris) sebagai CSV",
                    data=df_dl.to_csv(index=False).encode("utf-8"),
                    file_name="pdb_pertumbuhan.csv", mime="text/csv",
                    use_container_width=True
                )

        # ── Sub-tab Tambah PDB ────────────────────────────────────────────────
        if sub_tambah_p:
            with sub_tambah_p:
                st.subheader("Tambah Data PDB Baru")
                komp_list = get_pdb_komponen_tersedia()
                komp_opts = [k["komponen"] for k in komp_list] if komp_list else []
                with st.form("form_tambah_pdb"):
                    komponen = st.selectbox(
                        "Komponen",
                        options=komp_opts if komp_opts else ["Isi manual di bawah"],
                        key="pdb_komp_baru"
                    )
                    komponen_manual = st.text_input(
                        "Atau ketik komponen baru",
                        placeholder="kosongkan jika pilih dari dropdown",
                        key="pdb_komp_manual"
                    )
                    col1, col2 = st.columns(2)
                    with col1:
                        level   = st.selectbox("Level",
                                               options=["sektor", "subsektor", "detail"],
                                               key="pdb_level_baru")
                        laju    = st.selectbox("Laju Pertumbuhan",
                                               options=["y-on-y", "kumulatif", "berantai"],
                                               key="pdb_laju_baru")
                        tahun   = st.number_input("Tahun", min_value=2000, max_value=2030,
                                                   value=2024, step=1, key="pdb_tahun_baru")
                    with col2:
                        kuartal = st.selectbox("Kuartal",
                                               options=["QI", "QII", "QIII", "QIV"],
                                               key="pdb_kwartal_baru")
                        nilai   = st.number_input("Nilai (%)", min_value=-100.0,
                                                   max_value=500.0, step=0.01,
                                                   value=0.0, key="pdb_nilai_baru")
                    saved = st.form_submit_button("💾 Simpan", use_container_width=True)
                if saved:
                    final_k = komponen_manual.strip() if komponen_manual.strip() else komponen
                    result  = crud_create("analitik/pdb", {
                        "komponen"        : final_k,
                        "level"           : level,
                        "laju_pertumbuhan": laju,
                        "tahun"           : int(tahun),
                        "kuartal"         : kuartal,
                        "nilai"           : float(nilai)
                    })
                    if result:
                        notif_sukses(
                            f"Data PDB '{final_k}' {kuartal} {tahun} berhasil ditambahkan."
                        )
                        st.rerun()

        # ── Sub-tab Edit PDB ──────────────────────────────────────────────────
        if sub_edit_p:
            with sub_edit_p:
                st.subheader("Edit Data PDB")
                st.info("Masukkan ID data PDB yang akan diedit. "
                        "ID dapat dilihat di kolom ID pada tab Lihat Data.")
                pdb_id_edit = st.text_input("ID Data PDB", placeholder="contoh: 1",
                                             key="pdb_id_edit")
                if st.button("🔍 Cari", key="btn_cari_pdb_edit") and pdb_id_edit:
                    data = fetch(f"analitik/pdb/{pdb_id_edit.strip()}")
                    if data:
                        st.session_state["pdb_edit_data"] = data
                        notif_sukses(f"Data PDB ID {pdb_id_edit} ditemukan.")
                    else:
                        st.session_state.pop("pdb_edit_data", None)
                        notif_gagal(f"Data PDB ID {pdb_id_edit} tidak ditemukan.")
                if "pdb_edit_data" in st.session_state:
                    p = st.session_state["pdb_edit_data"]
                    st.success(
                        f"**{p['komponen']}** — {p['laju_pertumbuhan']} "
                        f"{p['kuartal']} {p['tahun']}"
                    )
                    with st.form("form_edit_pdb"):
                        nilai_baru = st.number_input(
                            "Nilai (%)", min_value=-100.0, max_value=500.0, step=0.01,
                            value=float(p["nilai"]) if p["nilai"] is not None else 0.0,
                            key="pdb_nilai_edit"
                        )
                        updated = st.form_submit_button("✏️ Update", use_container_width=True)
                    if updated:
                        result = crud_update("analitik/pdb", str(p["id"]),
                                             {"nilai": float(nilai_baru)})
                        if result:
                            st.session_state.pop("pdb_edit_data", None)
                            notif_sukses(f"Data PDB ID {p['id']} berhasil diperbarui.")
                            st.rerun()

        # ── Sub-tab Hapus PDB ─────────────────────────────────────────────────
        if sub_hapus_p:
            with sub_hapus_p:
                st.subheader("Hapus Data PDB")
                st.info("Masukkan ID data PDB yang akan dihapus.")
                pdb_id_hapus = st.text_input("ID Data PDB", placeholder="contoh: 1",
                                              key="pdb_id_hapus")
                if st.button("🔍 Cari", key="btn_cari_pdb_hapus") and pdb_id_hapus:
                    data = fetch(f"analitik/pdb/{pdb_id_hapus.strip()}")
                    if data:
                        st.session_state["pdb_hapus_data"] = data
                    else:
                        st.session_state.pop("pdb_hapus_data", None)
                        notif_gagal(f"Data PDB ID {pdb_id_hapus} tidak ditemukan.")
                if "pdb_hapus_data" in st.session_state:
                    p = st.session_state["pdb_hapus_data"]
                    st.warning(
                        f"Anda akan menghapus data PDB **ID {p['id']}** — "
                        f"**{p['komponen']}** {p['laju_pertumbuhan']} "
                        f"{p['kuartal']} {p['tahun']} (nilai: {p['nilai']})."
                    )
                    if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_pdb"):
                        result = crud_delete("analitik/pdb", str(p["id"]))
                        if result:
                            st.session_state.pop("pdb_hapus_data", None)
                            notif_sukses(f"Data PDB ID {p['id']} berhasil dihapus.")
                            st.rerun()