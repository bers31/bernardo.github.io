# views/tipe_properti.py

import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_tipe_properti, get_semua_properti_cached, is_admin,
    crud_create, crud_update, crud_delete,
    invalidate_properti_cache,
    notif_sukses, notif_gagal, tampilkan_notif
)


def render():
    st.title("🏗️ Data Tipe Properti")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat  = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # ── TAB LIHAT ─────────────────────────────────────────────────────────────
    with tab_lihat:
        tipe_list = get_tipe_properti()
        if not tipe_list:
            st.error("Gagal memuat data tipe properti.")
            return

        df_tipe = pd.DataFrame(tipe_list)

        st.subheader("🔽 Filter per Kolom")
        semua_nama = sorted(df_tipe["nama"].dropna().unique().tolist())
        pilih_nama = st.multiselect("Filter Nama Tipe",
                                    options=["Semua"] + semua_nama,
                                    default=["Semua"], key="filter_nama_tipe")
        aktif_nama  = semua_nama if "Semua" in pilih_nama or not pilih_nama else pilih_nama
        df_filtered = df_tipe[df_tipe["nama"].isin(aktif_nama)]

        st.divider()
        col1, col2 = st.columns(2)
        col1.metric("Total Ditampilkan", len(df_filtered))
        col2.metric("Total Keseluruhan", len(df_tipe))

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai.")
            return

        st.subheader(f"Daftar Tipe Properti ({len(df_filtered):,} data)")
        df_tampil = df_filtered[["id", "nama"]].copy()
        df_tampil.columns = ["ID", "Nama Tipe"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)

        st.divider()
        prop_list = get_semua_properti_cached()
        if prop_list:
            df_prop          = pd.DataFrame(prop_list)
            df_prop_filtered = df_prop[df_prop["tipe_properti"].isin(aktif_nama)]

            if not df_prop_filtered.empty:
                col_a, col_b = st.columns(2)
                with col_a:
                    st.subheader("Distribusi Properti per Tipe")
                    tipe_count = df_prop_filtered["tipe_properti"].value_counts().reset_index()
                    tipe_count.columns = ["Tipe", "Jumlah"]
                    fig1 = px.pie(tipe_count, names="Tipe", values="Jumlah", hole=0.4,
                                  color_discrete_sequence=px.colors.qualitative.Set2)
                    st.plotly_chart(fig1, use_container_width=True)
                with col_b:
                    st.subheader("Rata-rata Harga per Tipe")
                    avg_harga = df_prop_filtered.groupby("tipe_properti")["harga"].mean().reset_index()
                    avg_harga.columns = ["Tipe", "Rata-rata Harga"]
                    fig2 = px.bar(avg_harga.sort_values("Rata-rata Harga", ascending=False),
                                  x="Tipe", y="Rata-rata Harga", color="Tipe",
                                  color_discrete_sequence=px.colors.qualitative.Pastel)
                    fig2.update_layout(showlegend=False)
                    st.plotly_chart(fig2, use_container_width=True)

                st.subheader("Ringkasan Statistik per Tipe")
                ringkasan = df_prop_filtered.groupby("tipe_properti")["harga"].agg(
                    ["mean", "min", "max", "count"]
                ).reset_index()
                ringkasan.columns = ["Tipe", "Rata-rata", "Minimum", "Maksimum", "Jumlah Properti"]
                for col in ["Rata-rata", "Minimum", "Maksimum"]:
                    ringkasan[col] = ringkasan[col].apply(lambda x: f"Rp {x:,.0f}")
                st.dataframe(ringkasan, use_container_width=True, hide_index=True)

    # ── TAB TAMBAH ────────────────────────────────────────────────────────────
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Tipe Properti Baru")
            with st.form("form_tambah_tipe"):
                nama  = st.text_input("Nama Tipe Properti", placeholder="contoh: Rumah Tapak")
                saved = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not nama:
                    notif_gagal("Nama tipe properti wajib diisi.")
                else:
                    result = crud_create("tipe-properti", {"nama": nama.strip()})
                    if result:
                        invalidate_properti_cache()
                        notif_sukses(
                            f"Tipe properti '{nama}' berhasil ditambahkan "
                            f"dengan ID: {result.get('id')}."
                        )
                        st.rerun()

    # ── TAB EDIT ──────────────────────────────────────────────────────────────
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Tipe Properti")
            tipe_list = get_tipe_properti()
            if not tipe_list:
                st.warning("Tidak ada data untuk diedit.")
            else:
                tipe_options = {f"{t['id']} — {t['nama']}": t for t in tipe_list}
                pilihan      = st.selectbox("Pilih Tipe Properti",
                                            options=list(tipe_options.keys()),
                                            key="edit_sel_tipe")
                selected     = tipe_options[pilihan]

                with st.form("form_edit_tipe"):
                    st.caption(f"ID: **{selected['id']}** (tidak dapat diubah)")
                    nama_baru = st.text_input("Nama Tipe Properti", value=selected["nama"])
                    updated   = st.form_submit_button("✏️ Update", use_container_width=True)

                if updated:
                    if not nama_baru:
                        notif_gagal("Nama tipe properti wajib diisi.")
                    else:
                        result = crud_update("tipe-properti", selected["id"],
                                             {"nama": nama_baru.strip()})
                        if result:
                            invalidate_properti_cache()
                            notif_sukses(
                                f"Tipe properti berhasil diperbarui menjadi '{nama_baru}'."
                            )
                            st.rerun()

    # ── TAB HAPUS ─────────────────────────────────────────────────────────────
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Tipe Properti")
            tipe_list = get_tipe_properti()
            if not tipe_list:
                st.warning("Tidak ada data.")
            else:
                tipe_options = {f"{t['id']} — {t['nama']}": t for t in tipe_list}
                pilihan      = st.selectbox("Pilih Tipe Properti",
                                            options=list(tipe_options.keys()),
                                            key="del_sel_tipe")
                selected     = tipe_options[pilihan]

                st.warning(
                    f"Anda akan menghapus tipe properti **{selected['nama']}** "
                    f"(ID: {selected['id']}). "
                    f"Pastikan tidak ada properti yang masih menggunakan tipe ini."
                )
                if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_tipe"):
                    result = crud_delete("tipe-properti", selected["id"])
                    if result:
                        invalidate_properti_cache()
                        notif_sukses(f"Tipe properti '{selected['nama']}' berhasil dihapus.")
                        st.rerun()