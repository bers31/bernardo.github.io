# views/area.py

import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_area, is_admin,
    crud_create, crud_update, crud_delete,
    invalidate_properti_cache,
    notif_sukses, notif_gagal, tampilkan_notif
)


def render():
    st.title("📍 Data Area")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat  = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # ── TAB LIHAT ─────────────────────────────────────────────────────────────
    with tab_lihat:
        area_list = get_area()
        if not area_list:
            st.warning("Tidak ada data area yang ditemukan.")
            return

        df = pd.DataFrame(area_list)

        st.subheader("🔽 Filter per Kolom")
        col_f1, col_f2 = st.columns(2)
        with col_f1:
            semua_area = sorted(df["nama_area"].dropna().unique().tolist())
            pilih_area = st.multiselect("Filter Nama Area",
                                        options=["Semua"] + semua_area,
                                        default=["Semua"], key="filter_area_view")
            aktif_area = semua_area if "Semua" in pilih_area or not pilih_area else pilih_area
        with col_f2:
            semua_kota = sorted(df["kabupaten_kota"].dropna().unique().tolist())
            pilih_kota = st.multiselect("Filter Kabupaten Kota",
                                        options=["Semua"] + semua_kota,
                                        default=["Semua"], key="filter_kota_area")
            aktif_kota = semua_kota if "Semua" in pilih_kota or not pilih_kota else pilih_kota

        df_filtered = df[
            df["nama_area"].isin(aktif_area) &
            df["kabupaten_kota"].isin(aktif_kota)
        ]

        st.divider()
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Area Ditampilkan", len(df_filtered))
        col2.metric("Total Kota Ditampilkan", df_filtered["kabupaten_kota"].nunique())
        col3.metric("Total Area Keseluruhan", len(df))

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai dengan filter.")
            return

        st.subheader("Jumlah Area per Kota")
        kota_count = df_filtered["kabupaten_kota"].value_counts().reset_index()
        kota_count.columns = ["Kabupaten/Kota", "Jumlah Area"]
        fig = px.bar(kota_count.head(20), x="Kabupaten/Kota", y="Jumlah Area",
                     color="Jumlah Area", color_continuous_scale="Teal")
        fig.update_layout(coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)

        st.subheader(f"Daftar Area ({len(df_filtered):,} data)")
        df_tampil = df_filtered[["area_id", "nama_area", "kabupaten_kota"]].copy()
        df_tampil.columns = ["ID", "Nama Area", "Kabupaten/Kota"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)

    # ── TAB TAMBAH ────────────────────────────────────────────────────────────
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Area Baru")
            with st.form("form_tambah_area"):
                nama_area = st.text_input("Nama Area",
                                          placeholder="contoh: Kota Baru Parahyangan")
                kabupaten_kota      = st.text_input("Kabupaten_Kota", placeholder="contoh: Bandung")
                saved     = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not nama_area or not kabupaten_kota:
                    notif_gagal("Nama area dan kota wajib diisi.")
                else:
                    result = crud_create("area", {
                        "nama_area": nama_area.strip(),
                        "kabupaten_kota"     : kabupaten_kota.strip()
                    })
                    if result:
                        invalidate_properti_cache()
                        notif_sukses(
                            f"Area '{nama_area}' berhasil ditambahkan "
                            f"dengan ID: {result.get('area_id')}."
                        )
                        st.rerun()

    # ── TAB EDIT ──────────────────────────────────────────────────────────────
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Area")
            area_list = get_area()
            if not area_list:
                st.warning("Tidak ada data area untuk diedit.")
            else:
                area_options = {
                    f"{a['area_id']} — {a['nama_area']} ({a['kabupaten_kota']})": a
                    for a in area_list
                }
                pilihan  = st.selectbox("Pilih Area",
                                        options=list(area_options.keys()),
                                        key="edit_sel_area")
                selected = area_options[pilihan]

                with st.form("form_edit_area"):
                    st.caption(f"ID: **{selected['area_id']}** (tidak dapat diubah)")
                    nama_baru = st.text_input("Nama Area", value=selected["nama_area"])
                    kota_baru = st.text_input("Kabupaten/Kota", value=selected["kabupaten_kota"])
                    updated   = st.form_submit_button("✏️ Update", use_container_width=True)

                if updated:
                    if not nama_baru or not kota_baru:
                        notif_gagal("Nama area dan kota wajib diisi.")
                    else:
                        result = crud_update("area", selected["area_id"], {
                            "nama_area": nama_baru.strip(),
                            "kabupaten_kota"     : kota_baru.strip()
                        })
                        if result:
                            invalidate_properti_cache()
                            notif_sukses(f"Area '{nama_baru}' berhasil diperbarui.")
                            st.rerun()

    # ── TAB HAPUS ─────────────────────────────────────────────────────────────
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Area")
            area_list = get_area()
            if not area_list:
                st.warning("Tidak ada data area.")
            else:
                area_options = {
                    f"{a['area_id']} — {a['nama_area']} ({a['kabupaten_kota']})": a
                    for a in area_list
                }
                pilihan  = st.selectbox("Pilih Area",
                                        options=list(area_options.keys()),
                                        key="del_sel_area")
                selected = area_options[pilihan]

                st.warning(
                    f"Anda akan menghapus area **{selected['nama_area']}** "
                    f"(ID: {selected['area_id']}). "
                    f"Pastikan tidak ada properti yang masih menggunakan area ini."
                )
                if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_area"):
                    result = crud_delete("area", selected["area_id"])
                    if result:
                        invalidate_properti_cache()
                        notif_sukses(f"Area '{selected['nama_area']}' berhasil dihapus.")
                        st.rerun()