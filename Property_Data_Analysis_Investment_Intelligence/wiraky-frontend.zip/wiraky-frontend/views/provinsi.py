# views/provinsi.py

import streamlit as st
import pandas as pd
from api_client import (
    get_provinsi, is_admin,
    crud_create, crud_update, crud_delete,
    notif_sukses, notif_gagal, tampilkan_notif
)


def render():
    st.title("🗾 Data Provinsi")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat  = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # ── TAB LIHAT ─────────────────────────────────────────────────────────────
    with tab_lihat:
        provinsi_list = get_provinsi()
        if not provinsi_list:
            st.error("Gagal memuat data provinsi.")
            return

        df = pd.DataFrame(provinsi_list)

        st.subheader("🔽 Filter per Kolom")
        semua_nama = sorted(df["nama_provinsi"].dropna().unique().tolist())
        pilih_nama = st.multiselect(
            "Filter Nama Provinsi",
            options=["Semua"] + semua_nama,
            default=["Semua"], key="filter_nama_provinsi"
        )
        aktif_nama  = semua_nama if "Semua" in pilih_nama or not pilih_nama else pilih_nama
        df_filtered = df[df["nama_provinsi"].isin(aktif_nama)]

        st.divider()
        col1, col2 = st.columns(2)
        col1.metric("Total Ditampilkan", len(df_filtered))
        col2.metric("Total Keseluruhan", len(df))

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai dengan filter.")
            return

        st.subheader(f"Daftar Provinsi ({len(df_filtered):,} data)")
        df_tampil         = df_filtered[["kode_provinsi", "nama_provinsi"]].copy()
        df_tampil.columns = ["Kode Provinsi", "Nama Provinsi"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)

    # ── TAB TAMBAH ────────────────────────────────────────────────────────────
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Provinsi Baru")
            with st.form("form_tambah_provinsi"):
                kode  = st.text_input("Kode Provinsi", placeholder="contoh: 32")
                nama  = st.text_input("Nama Provinsi", placeholder="contoh: JAWA BARAT")
                saved = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not kode or not nama:
                    notif_gagal("Kode dan nama provinsi wajib diisi.")
                else:
                    result = crud_create("provinsi", {
                        "kode_provinsi": kode.strip(),
                        "nama_provinsi": nama.strip().upper()
                    })
                    if result:
                        notif_sukses(f"Provinsi '{nama.upper()}' berhasil ditambahkan.")
                        st.rerun()

    # ── TAB EDIT ──────────────────────────────────────────────────────────────
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Provinsi")
            provinsi_list = get_provinsi()
            if not provinsi_list:
                st.warning("Tidak ada data provinsi untuk diedit.")
            else:
                options  = {f"{p['kode_provinsi']} — {p['nama_provinsi']}": p for p in provinsi_list}
                pilihan  = st.selectbox("Pilih Provinsi", options=list(options.keys()), key="edit_sel_prov")
                selected = options[pilihan]

                with st.form("form_edit_provinsi"):
                    st.caption(f"Kode Provinsi: **{selected['kode_provinsi']}** (tidak dapat diubah)")
                    nama_baru = st.text_input("Nama Provinsi", value=selected["nama_provinsi"])
                    updated   = st.form_submit_button("✏️ Update", use_container_width=True)

                if updated:
                    if not nama_baru:
                        notif_gagal("Nama provinsi wajib diisi.")
                    else:
                        result = crud_update("provinsi", selected["kode_provinsi"], {
                            "nama_provinsi": nama_baru.strip().upper()
                        })
                        if result:
                            notif_sukses(f"Provinsi berhasil diperbarui menjadi '{nama_baru.upper()}'.")
                            st.rerun()

    # ── TAB HAPUS ─────────────────────────────────────────────────────────────
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Provinsi")
            provinsi_list = get_provinsi()
            if not provinsi_list:
                st.warning("Tidak ada data provinsi.")
            else:
                options  = {f"{p['kode_provinsi']} — {p['nama_provinsi']}": p for p in provinsi_list}
                pilihan  = st.selectbox("Pilih Provinsi", options=list(options.keys()), key="del_sel_prov")
                selected = options[pilihan]

                st.warning(
                    f"Anda akan menghapus provinsi **{selected['nama_provinsi']}** "
                    f"(kode: {selected['kode_provinsi']}). "
                    f"Pastikan tidak ada kabupaten/kota yang masih terhubung."
                )
                if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_prov"):
                    result = crud_delete("provinsi", selected["kode_provinsi"])
                    if result:
                        notif_sukses(f"Provinsi '{selected['nama_provinsi']}' berhasil dihapus.")
                        st.session_state.pop("del_sel_prov", None)
                        st.rerun()