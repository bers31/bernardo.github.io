# views/kabupaten_kota.py

import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_kabupaten_kota, get_provinsi, is_admin,
    crud_create, crud_update, crud_delete,
    notif_sukses, notif_gagal, tampilkan_notif
)


def render():
    st.title("🏙️ Data Kabupaten & Kota")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat  = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # ── TAB LIHAT ─────────────────────────────────────────────────────────────
    with tab_lihat:
        kab_list = get_kabupaten_kota()
        if not kab_list:
            st.warning("Tidak ada data kabupaten/kota.")
            return

        df = pd.DataFrame(kab_list)

        st.subheader("🔽 Filter per Kolom")
        col_f1, col_f2 = st.columns(2)
        with col_f1:
            semua_nama = sorted(df["nama_kabupaten_kota"].dropna().unique().tolist())
            pilih_nama = st.multiselect("Filter Nama Kabupaten/Kota",
                                        options=["Semua"] + semua_nama,
                                        default=["Semua"], key="filter_nama_kab")
            aktif_nama = semua_nama if "Semua" in pilih_nama or not pilih_nama else pilih_nama
        with col_f2:
            semua_prov = sorted(df["kode_provinsi"].dropna().unique().tolist())
            pilih_prov = st.multiselect("Filter Kode Provinsi",
                                        options=["Semua"] + semua_prov,
                                        default=["Semua"], key="filter_prov_kab")
            aktif_prov = semua_prov if "Semua" in pilih_prov or not pilih_prov else pilih_prov

        df_filtered = df[
            df["nama_kabupaten_kota"].isin(aktif_nama) &
            df["kode_provinsi"].isin(aktif_prov)
        ]

        st.divider()
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Ditampilkan",   len(df_filtered))
        col2.metric("Total Provinsi Unik", df_filtered["kode_provinsi"].nunique())
        col3.metric("Total Keseluruhan",   len(df))

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai.")
            return

        st.subheader("Jumlah Kabupaten/Kota per Provinsi")
        prov_count = df_filtered["kode_provinsi"].value_counts().reset_index()
        prov_count.columns = ["Kode Provinsi", "Jumlah"]
        fig = px.bar(prov_count, x="Kode Provinsi", y="Jumlah",
                     color="Jumlah", color_continuous_scale="Blues")
        fig.update_layout(coloraxis_showscale=False)
        st.plotly_chart(fig, use_container_width=True)

        st.subheader(f"Daftar Kabupaten/Kota ({len(df_filtered):,} data)")
        df_tampil = df_filtered[["kode_kabupaten_kota", "nama_kabupaten_kota", "kode_provinsi"]].copy()
        df_tampil.columns = ["Kode", "Nama Kabupaten/Kota", "Kode Provinsi"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)

    # ── TAB TAMBAH ────────────────────────────────────────────────────────────
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Kabupaten/Kota Baru")
            provinsi_list = get_provinsi()
            prov_options  = {f"{p['kode_provinsi']} — {p['nama_provinsi']}": p["kode_provinsi"]
                             for p in provinsi_list}

            with st.form("form_tambah_kab"):
                kode_kab = st.text_input("Kode Kabupaten/Kota", placeholder="contoh: 3201")
                nama_kab = st.text_input("Nama Kabupaten/Kota", placeholder="contoh: KABUPATEN BOGOR")
                prov_sel = st.selectbox("Provinsi Induk", options=list(prov_options.keys()))
                saved    = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not kode_kab or not nama_kab:
                    notif_gagal("Kode dan nama kabupaten/kota wajib diisi.")
                else:
                    result = crud_create("kabupaten-kota", {
                        "kode_kabupaten_kota": kode_kab.strip(),
                        "nama_kabupaten_kota": nama_kab.strip().upper(),
                        "kode_provinsi"      : prov_options[prov_sel]
                    })
                    if result:
                        notif_sukses(f"Kabupaten/kota '{nama_kab.upper()}' berhasil ditambahkan.")
                        st.rerun()

    # ── TAB EDIT ──────────────────────────────────────────────────────────────
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Kabupaten/Kota")
            kab_list      = get_kabupaten_kota()
            provinsi_list = get_provinsi()
            prov_options  = {f"{p['kode_provinsi']} — {p['nama_provinsi']}": p["kode_provinsi"]
                             for p in provinsi_list}
            prov_keys     = list(prov_options.keys())

            if not kab_list:
                st.warning("Tidak ada data untuk diedit.")
            else:
                kab_options = {f"{k['kode_kabupaten_kota']} — {k['nama_kabupaten_kota']}": k
                               for k in kab_list}
                pilihan  = st.selectbox("Pilih Kabupaten/Kota",
                                        options=list(kab_options.keys()), key="edit_sel_kab")
                selected = kab_options[pilihan]
                prov_idx = next((i for i, k in enumerate(prov_keys)
                                 if prov_options[k] == selected["kode_provinsi"]), 0)

                with st.form("form_edit_kab"):
                    st.caption(f"Kode: **{selected['kode_kabupaten_kota']}** (tidak dapat diubah)")
                    nama_baru = st.text_input("Nama Kabupaten/Kota",
                                              value=selected["nama_kabupaten_kota"])
                    prov_baru = st.selectbox("Provinsi Induk", options=prov_keys, index=prov_idx)
                    updated   = st.form_submit_button("✏️ Update", use_container_width=True)

                if updated:
                    result = crud_update("kabupaten-kota", selected["kode_kabupaten_kota"], {
                        "nama_kabupaten_kota": nama_baru.strip().upper(),
                        "kode_provinsi"      : prov_options[prov_baru]
                    })
                    if result:
                        notif_sukses("Kabupaten/kota berhasil diperbarui.")
                        st.rerun()

    # ── TAB HAPUS ─────────────────────────────────────────────────────────────
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Kabupaten/Kota")
            kab_list = get_kabupaten_kota()
            if not kab_list:
                st.warning("Tidak ada data.")
            else:
                kab_options = {f"{k['kode_kabupaten_kota']} — {k['nama_kabupaten_kota']}": k
                               for k in kab_list}
                pilihan  = st.selectbox("Pilih Kabupaten/Kota",
                                        options=list(kab_options.keys()), key="del_sel_kab")
                selected = kab_options[pilihan]

                st.warning(
                    f"Anda akan menghapus **{selected['nama_kabupaten_kota']}** "
                    f"(kode: {selected['kode_kabupaten_kota']}). "
                    f"Pastikan tidak ada data UMR yang masih terhubung."
                )
                if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_kab"):
                    result = crud_delete("kabupaten-kota", selected["kode_kabupaten_kota"])
                    if result:
                        notif_sukses(f"'{selected['nama_kabupaten_kota']}' berhasil dihapus.")
                        st.rerun()