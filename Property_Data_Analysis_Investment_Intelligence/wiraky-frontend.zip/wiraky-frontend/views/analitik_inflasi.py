# views/analitik_inflasi.py
import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_inflasi, get_bi_rate_terkini,
    is_admin, crud_create, crud_update, crud_delete,
    notif_sukses, notif_gagal, tampilkan_notif,
)

NAMA_BULAN = {
    1: "Januari", 2: "Februari", 3: "Maret", 4: "April",
    5: "Mei", 6: "Juni", 7: "Juli", 8: "Agustus",
    9: "September", 10: "Oktober", 11: "November", 12: "Desember",
}


def _load_data() -> pd.DataFrame:
    data = get_inflasi()
    if not data:
        return pd.DataFrame()
    df = pd.DataFrame(data)
    df["nilai"]      = pd.to_numeric(df["nilai"],      errors="coerce")
    df["index_base"] = pd.to_numeric(df["index_base"], errors="coerce")
    df["tahun"]      = pd.to_numeric(df["tahun"],      errors="coerce").astype("Int64")
    df["bulan"]      = pd.to_numeric(df["bulan"],      errors="coerce").astype("Int64")
    return df


def render():
    st.title("📈 Analitik Inflasi")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # =========================================================================
    # TAB LIHAT — data langsung dari analitik.inflasi_bulanan
    # =========================================================================
    with tab_lihat:
        bi = get_bi_rate_terkini()
        if bi.get("nilai_pct"):
            st.info(f"🏦 **BI Rate Terkini:** {bi['nilai_pct']}% (per {bi['tanggal']})")

        with st.spinner("Memuat data inflasi..."):
            df = _load_data()

        if df.empty:
            st.warning("Belum ada data inflasi.")
            return

        # Filter
        st.subheader("🔽 Filter")
        col_f1, col_f2, col_f3 = st.columns(3)
        with col_f1:
            semua_prov  = sorted(df["provinsi"].dropna().unique().tolist())
            pilih_prov  = st.multiselect("Filter Provinsi", options=["Semua"] + semua_prov,
                                          default=["Semua"], key="filter_prov_inflasi")
            aktif_prov  = semua_prov if "Semua" in pilih_prov or not pilih_prov else pilih_prov
        with col_f2:
            semua_tahun = sorted(df["tahun"].dropna().unique().tolist(), reverse=True)
            pilih_tahun = st.multiselect("Filter Tahun", options=["Semua"] + semua_tahun,
                                          default=["Semua"], key="filter_tahun_inflasi")
            aktif_tahun = semua_tahun if "Semua" in pilih_tahun or not pilih_tahun else pilih_tahun
        with col_f3:
            semua_bulan = sorted(df["bulan"].dropna().unique().tolist())
            pilih_bulan = st.multiselect("Filter Bulan", options=["Semua"] + semua_bulan,
                                          default=["Semua"],
                                          format_func=lambda x: "Semua" if x == "Semua"
                                                                 else f"{x} — {NAMA_BULAN.get(x, x)}",
                                          key="filter_bulan_inflasi")
            aktif_bulan = semua_bulan if "Semua" in pilih_bulan or not pilih_bulan else pilih_bulan

        df_filtered = df[
            df["provinsi"].isin(aktif_prov) &
            df["tahun"].isin(aktif_tahun) &
            df["bulan"].isin(aktif_bulan)
        ]

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai dengan filter.")
            return

        # Metrik
        st.divider()
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total Data",        f"{len(df_filtered):,}")
        c2.metric("Inflasi Tertinggi", f"{df_filtered['nilai'].max():.4f}%")
        c3.metric("Inflasi Terendah",  f"{df_filtered['nilai'].min():.4f}%")
        c4.metric("Inflasi Rata-rata", f"{df_filtered['nilai'].mean():.4f}%")

        # Heatmap
        st.divider()
        if len(aktif_tahun) == 1:
            st.subheader(f"Peta Panas Inflasi — Provinsi vs Bulan ({aktif_tahun[0]})")
            if len(aktif_prov) <= 20:
                pivot = df_filtered.pivot_table(index="provinsi", columns="bulan",
                                                 values="nilai", aggfunc="mean")
                pivot.columns = [NAMA_BULAN.get(c, c) for c in pivot.columns]
                fig_hm = px.imshow(pivot, color_continuous_scale="RdYlGn_r",
                                    labels={"color": "Inflasi (%)"}, aspect="auto")
                fig_hm.update_layout(xaxis_title="Bulan", yaxis_title="Provinsi")
                st.plotly_chart(fig_hm, use_container_width=True)
            else:
                st.caption("Pilih maksimal 20 provinsi untuk menampilkan heatmap.")
        elif len(aktif_tahun) > 1:
            st.subheader("Peta Panas Inflasi — Provinsi vs Tahun (rata-rata bulanan)")
            if len(aktif_prov) <= 20:
                pivot = df_filtered.pivot_table(index="provinsi", columns="tahun",
                                                 values="nilai", aggfunc="mean")
                fig_hm = px.imshow(pivot, color_continuous_scale="RdYlGn_r",
                                    labels={"color": "Inflasi (%)"}, aspect="auto")
                fig_hm.update_layout(xaxis_title="Tahun", yaxis_title="Provinsi")
                st.plotly_chart(fig_hm, use_container_width=True)
            else:
                st.caption("Pilih maksimal 20 provinsi untuk menampilkan heatmap.")

        # Tren bulanan
        st.subheader("Tren Inflasi Bulanan per Provinsi")
        df_tren = df_filtered.copy()
        df_tren["periode"] = (df_tren["tahun"].astype(str) + "-"
                               + df_tren["bulan"].astype(str).str.zfill(2))
        fig_line = px.line(df_tren.sort_values(["tahun", "bulan"]),
                            x="periode", y="nilai", color="provinsi", markers=True,
                            labels={"nilai": "Inflasi (%)", "periode": "Periode"})
        fig_line.update_xaxes(tickangle=45)
        st.plotly_chart(fig_line, use_container_width=True)

        # Bar rata-rata per provinsi
        st.subheader("Rata-rata Inflasi per Provinsi")
        df_bar = (df_filtered.groupby("provinsi")["nilai"].mean()
                   .reset_index().sort_values("nilai", ascending=True))
        fig_bar = px.bar(df_bar, x="nilai", y="provinsi", orientation="h",
                          color="nilai", color_continuous_scale="RdYlGn_r",
                          labels={"nilai": "Rata-rata Inflasi (%)", "provinsi": "Provinsi"})
        fig_bar.update_layout(coloraxis_showscale=False)
        st.plotly_chart(fig_bar, use_container_width=True)

        # Tabel
        st.subheader(f"Data Lengkap ({len(df_filtered):,} baris)")
        df_tampil = df_filtered[["id", "provinsi", "tahun", "bulan", "nilai", "index_base"]].copy()
        df_tampil["bulan"] = df_tampil["bulan"].map(lambda x: f"{x} — {NAMA_BULAN.get(x, x)}")
        df_tampil["nilai"] = df_tampil["nilai"].apply(lambda x: f"{x:.4f}%")
        df_tampil.columns  = ["ID", "Provinsi", "Tahun", "Bulan", "Nilai Inflasi", "Index Base"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)
        st.download_button("⬇️ Download CSV",
                            data=df_tampil.to_csv(index=False).encode("utf-8"),
                            file_name="inflasi_bulanan.csv", mime="text/csv",
                            use_container_width=True)

    # =========================================================================
    # TAB TAMBAH
    # =========================================================================
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Data Inflasi Bulanan")
            st.caption("Data disimpan ke tabel `analitik.inflasi_bulanan`.")

            with st.spinner("Memuat daftar provinsi..."):
                df_ref = _load_data()
            # Provinsi diambil dinamis dari data yang sudah ada
            provinsi_list = sorted(df_ref["provinsi"].dropna().unique().tolist()) if not df_ref.empty else []

            with st.form("form_tambah_inflasi"):
                col_a, col_b = st.columns(2)
                with col_a:
                    provinsi_sel = st.selectbox("Provinsi",
                                                 options=provinsi_list + ["— Ketik manual —"])
                    if provinsi_sel == "— Ketik manual —":
                        provinsi = st.text_input("Nama Provinsi Baru")
                    else:
                        provinsi = provinsi_sel
                    tahun = st.number_input("Tahun", min_value=2000, max_value=2100,
                                             value=2025, step=1)
                with col_b:
                    bulan = st.selectbox("Bulan", options=list(range(1, 13)),
                                          format_func=lambda x: f"{x} — {NAMA_BULAN[x]}")
                    index_base = st.number_input("Index Base (tahun dasar)",
                                                  min_value=2000, max_value=2100,
                                                  value=2022, step=1)
                nilai = st.number_input("Nilai Inflasi (%)",
                                         min_value=-100.0, max_value=100.0,
                                         value=0.0, step=0.01, format="%.4f")
                saved = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not provinsi or not provinsi.strip():
                    notif_gagal("Nama provinsi tidak boleh kosong.")
                else:
                    result = crud_create("analitik/inflasi", {
                        "provinsi"  : provinsi.strip(),
                        "tahun"     : int(tahun),
                        "bulan"     : int(bulan),
                        "nilai"     : float(nilai),
                        "index_base": int(index_base),
                    })
                    if result:
                        notif_sukses(
                            f"Berhasil ditambahkan — {provinsi} "
                            f"{NAMA_BULAN[int(bulan)]} {int(tahun)} (ID: {result.get('id')})."
                        )
                        st.rerun()

    # =========================================================================
    # TAB EDIT
    # =========================================================================
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Data Inflasi Bulanan")
            with st.spinner("Memuat data inflasi..."):
                df_all = _load_data()

            if df_all.empty:
                st.warning("Tidak ada data inflasi yang tersedia.")
            else:
                col_e1, col_e2, col_e3 = st.columns(3)
                with col_e1:
                    prov_f = st.selectbox("Filter Provinsi",
                                           options=["Semua"] + sorted(df_all["provinsi"].dropna().unique()),
                                           key="edit_filter_prov")
                with col_e2:
                    tahun_f = st.selectbox("Filter Tahun",
                                            options=["Semua"] + sorted(df_all["tahun"].dropna().unique(), reverse=True),
                                            key="edit_filter_tahun")
                with col_e3:
                    bulan_f = st.selectbox("Filter Bulan",
                                            options=["Semua"] + list(range(1, 13)),
                                            format_func=lambda x: "Semua" if x == "Semua"
                                                                   else f"{x} — {NAMA_BULAN[x]}",
                                            key="edit_filter_bulan")

                df_edit = df_all.copy()
                if prov_f  != "Semua": df_edit = df_edit[df_edit["provinsi"] == prov_f]
                if tahun_f != "Semua": df_edit = df_edit[df_edit["tahun"]    == tahun_f]
                if bulan_f != "Semua": df_edit = df_edit[df_edit["bulan"]    == bulan_f]

                if df_edit.empty:
                    st.warning("Tidak ada data yang cocok dengan filter.")
                else:
                    opts = {
                        f"ID {d['id']} — {d['provinsi']} "
                        f"{NAMA_BULAN.get(int(d['bulan']), d['bulan'])} {d['tahun']} "
                        f"| nilai: {d['nilai']}% | base: {d['index_base']}": d
                        for d in df_edit.to_dict("records")
                    }
                    pilihan  = st.selectbox("Pilih Record", options=list(opts.keys()),
                                             key="edit_sel_inflasi")
                    selected = opts[pilihan]

                    with st.form("form_edit_inflasi"):
                        st.caption(
                            f"**ID {selected['id']}** | Provinsi: **{selected['provinsi']}** | "
                            f"Periode: **{NAMA_BULAN.get(int(selected['bulan']), selected['bulan'])} "
                            f"{selected['tahun']}** — provinsi, tahun, bulan tidak dapat diubah"
                        )
                        col_f, col_g = st.columns(2)
                        with col_f:
                            nilai_baru = st.number_input(
                                "Nilai Inflasi (%)", min_value=-100.0, max_value=100.0,
                                value=float(selected["nilai"]) if pd.notna(selected["nilai"]) else 0.0,
                                step=0.01, format="%.4f"
                            )
                        with col_g:
                            base_baru = st.number_input(
                                "Index Base", min_value=2000, max_value=2100,
                                value=int(selected["index_base"]) if pd.notna(selected["index_base"]) else 2022,
                                step=1
                            )
                        updated = st.form_submit_button("✏️ Update", use_container_width=True)

                    if updated:
                        result = crud_update("analitik/inflasi", selected["id"], {
                            "nilai"     : float(nilai_baru),
                            "index_base": int(base_baru),
                        })
                        if result:
                            notif_sukses(f"Data inflasi ID {selected['id']} berhasil diperbarui.")
                            st.rerun()

    # =========================================================================
    # TAB HAPUS
    # =========================================================================
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Data Inflasi Bulanan")
            with st.spinner("Memuat data inflasi..."):
                df_all = _load_data()

            if df_all.empty:
                st.warning("Tidak ada data inflasi yang tersedia.")
            else:
                col_h1, col_h2, col_h3 = st.columns(3)
                with col_h1:
                    prov_d = st.selectbox("Filter Provinsi",
                                           options=["Semua"] + sorted(df_all["provinsi"].dropna().unique()),
                                           key="del_filter_prov")
                with col_h2:
                    tahun_d = st.selectbox("Filter Tahun",
                                            options=["Semua"] + sorted(df_all["tahun"].dropna().unique(), reverse=True),
                                            key="del_filter_tahun")
                with col_h3:
                    bulan_d = st.selectbox("Filter Bulan",
                                            options=["Semua"] + list(range(1, 13)),
                                            format_func=lambda x: "Semua" if x == "Semua"
                                                                   else f"{x} — {NAMA_BULAN[x]}",
                                            key="del_filter_bulan")

                df_del = df_all.copy()
                if prov_d  != "Semua": df_del = df_del[df_del["provinsi"] == prov_d]
                if tahun_d != "Semua": df_del = df_del[df_del["tahun"]    == tahun_d]
                if bulan_d != "Semua": df_del = df_del[df_del["bulan"]    == bulan_d]

                if df_del.empty:
                    st.warning("Tidak ada data yang cocok dengan filter.")
                else:
                    opts = {
                        f"ID {d['id']} — {d['provinsi']} "
                        f"{NAMA_BULAN.get(int(d['bulan']), d['bulan'])} {d['tahun']} "
                        f"| nilai: {d['nilai']}%": d
                        for d in df_del.to_dict("records")
                    }
                    pilihan  = st.selectbox("Pilih Record", options=list(opts.keys()),
                                             key="del_sel_inflasi")
                    selected = opts[pilihan]

                    st.warning(
                        f"Anda akan menghapus secara permanen: "
                        f"**ID {selected['id']}** — **{selected['provinsi']}** "
                        f"bulan **{NAMA_BULAN.get(int(selected['bulan']), selected['bulan'])}** "
                        f"tahun **{selected['tahun']}** dengan nilai **{selected['nilai']}%**"
                    )
                    if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_inflasi"):
                        result = crud_delete("analitik/inflasi", selected["id"])
                        if result:
                            notif_sukses(f"Data inflasi ID {selected['id']} berhasil dihapus.")
                            st.rerun()