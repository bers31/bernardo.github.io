# views/segmen_harga.py

import streamlit as st
import pandas as pd
import plotly.express as px
from api_client import (
    get_segmen_harga, get_semua_properti_cached, is_admin,
    crud_create, crud_update, crud_delete,
    invalidate_properti_cache,
    notif_sukses, notif_gagal, tampilkan_notif
)


def render():
    st.title("💰 Data Segmen Harga")
    st.divider()
    tampilkan_notif()

    if is_admin():
        tab_lihat, tab_tambah, tab_edit, tab_hapus = st.tabs([
            "📊 Lihat Data", "➕ Tambah", "✏️ Edit", "🗑️ Hapus"
        ])
    else:
        tab_lihat  = st.tabs(["📊 Lihat Data"])[0]
        tab_tambah = tab_edit = tab_hapus = None

    # ── TAB LIHAT ─────────────────────────────────────────────────────────────
    with tab_lihat:
        segmen_list = get_segmen_harga()
        if not segmen_list:
            st.error("Gagal memuat data segmen harga.")
            return

        df_segmen = pd.DataFrame(segmen_list)

        st.subheader("🔽 Filter per Kolom")
        semua_nama = sorted(df_segmen["nama"].dropna().unique().tolist())
        pilih_nama = st.multiselect("Filter Nama Segmen",
                                    options=["Semua"] + semua_nama,
                                    default=["Semua"], key="filter_nama_segmen")
        aktif_nama  = semua_nama if "Semua" in pilih_nama or not pilih_nama else pilih_nama
        df_filtered = df_segmen[df_segmen["nama"].isin(aktif_nama)]

        st.divider()
        col1, col2 = st.columns(2)
        col1.metric("Total Ditampilkan", len(df_filtered))
        col2.metric("Total Keseluruhan", len(df_segmen))

        if df_filtered.empty:
            st.warning("Tidak ada data yang sesuai.")
            return

        st.subheader(f"Daftar Segmen Harga ({len(df_filtered):,} data)")
        df_tampil = df_filtered[["id", "nama"]].copy()
        df_tampil.columns = ["ID", "Nama Segmen"]
        st.dataframe(df_tampil, use_container_width=True, hide_index=True)

        st.divider()
        prop_list = get_semua_properti_cached()
        if prop_list:
            df_prop          = pd.DataFrame(prop_list)
            df_prop["harga"] = pd.to_numeric(df_prop["harga"], errors="coerce")
            df_prop_filtered = df_prop[df_prop["segmen_harga"].isin(aktif_nama)]

            if not df_prop_filtered.empty:
                col_a, col_b = st.columns(2)
                with col_a:
                    st.subheader("Distribusi Properti per Segmen")
                    segmen_count = df_prop_filtered["segmen_harga"].value_counts().reset_index()
                    segmen_count.columns = ["Segmen", "Jumlah"]
                    fig1 = px.bar(segmen_count, x="Segmen", y="Jumlah", color="Segmen",
                                  color_discrete_sequence=px.colors.qualitative.Set2)
                    fig1.update_layout(showlegend=False)
                    st.plotly_chart(fig1, use_container_width=True)
                with col_b:
                    st.subheader("Rata-rata Harga per Segmen")
                    avg_harga = df_prop_filtered.groupby("segmen_harga")["harga"].mean().reset_index()
                    avg_harga.columns = ["Segmen", "Rata-rata Harga"]
                    fig2 = px.bar(avg_harga.sort_values("Rata-rata Harga", ascending=False),
                                  x="Segmen", y="Rata-rata Harga", color="Segmen",
                                  color_discrete_sequence=px.colors.qualitative.Pastel)
                    fig2.update_layout(showlegend=False)
                    st.plotly_chart(fig2, use_container_width=True)

                st.subheader("Ringkasan Harga per Segmen")
                ringkasan = df_prop_filtered.groupby("segmen_harga")["harga"].agg(
                    ["mean", "min", "max", "count"]
                ).reset_index()
                ringkasan.columns = ["Segmen", "Rata-rata", "Minimum", "Maksimum", "Jumlah Properti"]
                for col in ["Rata-rata", "Minimum", "Maksimum"]:
                    ringkasan[col] = ringkasan[col].apply(lambda x: f"Rp {x:,.0f}")
                st.dataframe(ringkasan, use_container_width=True, hide_index=True)

    # ── TAB TAMBAH ────────────────────────────────────────────────────────────
    if tab_tambah:
        with tab_tambah:
            st.subheader("Tambah Segmen Harga Baru")
            with st.form("form_tambah_segmen"):
                nama  = st.text_input("Nama Segmen Harga", placeholder="contoh: Murah")
                saved = st.form_submit_button("💾 Simpan", use_container_width=True)

            if saved:
                if not nama:
                    notif_gagal("Nama segmen harga wajib diisi.")
                else:
                    result = crud_create("segmen-harga", {"nama": nama.strip()})
                    if result:
                        invalidate_properti_cache()
                        notif_sukses(
                            f"Segmen harga '{nama}' berhasil ditambahkan "
                            f"dengan ID: {result.get('id')}."
                        )
                        st.rerun()

    # ── TAB EDIT ──────────────────────────────────────────────────────────────
    if tab_edit:
        with tab_edit:
            st.subheader("Edit Segmen Harga")
            segmen_list = get_segmen_harga()
            if not segmen_list:
                st.warning("Tidak ada data untuk diedit.")
            else:
                segmen_options = {f"{s['id']} — {s['nama']}": s for s in segmen_list}
                pilihan        = st.selectbox("Pilih Segmen Harga",
                                              options=list(segmen_options.keys()),
                                              key="edit_sel_segmen")
                selected       = segmen_options[pilihan]

                with st.form("form_edit_segmen"):
                    st.caption(f"ID: **{selected['id']}** (tidak dapat diubah)")
                    nama_baru = st.text_input("Nama Segmen Harga", value=selected["nama"])
                    updated   = st.form_submit_button("✏️ Update", use_container_width=True)

                if updated:
                    if not nama_baru:
                        notif_gagal("Nama segmen harga wajib diisi.")
                    else:
                        result = crud_update("segmen-harga", selected["id"],
                                             {"nama": nama_baru.strip()})
                        if result:
                            invalidate_properti_cache()
                            notif_sukses(
                                f"Segmen harga berhasil diperbarui menjadi '{nama_baru}'."
                            )
                            st.rerun()

    # ── TAB HAPUS ─────────────────────────────────────────────────────────────
    if tab_hapus:
        with tab_hapus:
            st.subheader("Hapus Segmen Harga")
            segmen_list = get_segmen_harga()
            if not segmen_list:
                st.warning("Tidak ada data.")
            else:
                segmen_options = {f"{s['id']} — {s['nama']}": s for s in segmen_list}
                pilihan        = st.selectbox("Pilih Segmen Harga",
                                              options=list(segmen_options.keys()),
                                              key="del_sel_segmen")
                selected       = segmen_options[pilihan]

                st.warning(
                    f"Anda akan menghapus segmen harga **{selected['nama']}** "
                    f"(ID: {selected['id']}). "
                    f"Pastikan tidak ada properti yang masih menggunakan segmen ini."
                )
                if st.button("🗑️ Hapus Permanen", type="primary", key="btn_hapus_segmen"):
                    result = crud_delete("segmen-harga", selected["id"])
                    if result:
                        invalidate_properti_cache()
                        notif_sukses(f"Segmen harga '{selected['nama']}' berhasil dihapus.")
                        st.rerun()