# api_client.py — versi lengkap dengan role dan notifikasi toast

import requests
import streamlit as st
from dotenv import load_dotenv
import os
import time as _time

load_dotenv()
API_URL = os.getenv("API_URL", "http://127.0.0.1:8000").rstrip("/")


# ── Autentikasi & Session ─────────────────────────────────────────────────────

def get_token() -> str | None:
    token = st.session_state.get("token")

    if token:
        return token

    token = st.query_params.get("t")

    if token:
        st.session_state["token"] = token

        try:
            import base64
            import json

            payload_b64 = token.split(".")[1]

            padding = "=" * (-len(payload_b64) % 4)

            payload = json.loads(
                base64.urlsafe_b64decode(
                    payload_b64 + padding
                )
            )

            st.session_state["username"] = (
                payload.get("sub")
                or payload.get("username")
                or "Admin"
            )

            st.session_state["role"] = str(
                payload.get("role", "user")
            ).lower()

            if "p" not in st.session_state:
                st.session_state["p"] = "home"

        except Exception:
            st.session_state["role"] = "user"
            st.session_state["username"] = "User"

    return token


def get_current_page():
    if "p" not in st.session_state:
        st.session_state["p"] = "home"

    return st.session_state["p"]


def navigate_to(page: str):
    st.session_state["p"] = page


def login(username: str, password: str) -> bool:
    try:
        response = requests.post(
            f"{API_URL}/auth/login",  # Tanpa trailing slash — kritis untuk POST
            json={"username": username, "password": password},
            timeout=10
        )
        if response.status_code == 200:
            data  = response.json()
            token = data["access_token"]
            # Decode role dari token JWT tanpa verifikasi (hanya membaca payload)
            import base64, json as _json
            try:
                payload_b64 = token.split(".")[1]
                payload_b64 += "=" * (4 - len(payload_b64) % 4)
                payload = _json.loads(
                    base64.urlsafe_b64decode(
                        payload_b64
                    )
                )

                st.write("JWT Payload:", payload)

                role = (
                    payload.get("role")
                    or payload.get("roles", ["user"])[0]
                    or "user"
                )

                role = str(role).lower()
            except Exception:
                role = "user"
            
            st.session_state["token"] = token
            st.session_state["username"] = username
            st.session_state["role"] = role
            st.session_state["p"] = "home"
            st.query_params.clear()
            st.query_params["t"] = token
            return True
        elif response.status_code == 401:
            return False
        else:
            st.error(f"Error server {response.status_code}: {response.text}")
            return False
    except requests.exceptions.ConnectionError:
        st.error(f"Tidak dapat terhubung ke backend. Periksa API_URL: {API_URL}")
        return False
    except Exception as e:
        st.error(f"Terjadi kesalahan: {e}")
        return False


def logout():
    st.session_state.clear()
    st.query_params.clear()
    st.rerun()

def is_authenticated() -> bool:
    return bool(get_token())


def is_admin() -> bool:
    return st.session_state.get("role") == "admin"


def get_headers() -> dict:
    token = get_token()
    return {"Authorization": f"Bearer {token}"} if token else {}


# ── Notifikasi ────────────────────────────────────────────────────────────────

def notif_sukses(pesan: str):
    """
    Menyimpan notifikasi sukses ke session_state agar persisten
    melalui st.rerun(), lalu juga mencoba menampilkan toast.
    """
    st.session_state["_notif_msg"]  = pesan
    st.session_state["_notif_type"] = "success"
    try:
        st.toast(f"✅ {pesan}", icon="✅")
    except Exception:
        pass


def notif_gagal(pesan: str):
    """
    Menyimpan notifikasi gagal ke session_state agar persisten
    melalui st.rerun(), lalu juga mencoba menampilkan toast.
    """
    st.session_state["_notif_msg"]  = pesan
    st.session_state["_notif_type"] = "error"
    try:
        st.toast(f"❌ {pesan}", icon="❌")
    except Exception:
        pass


def tampilkan_notif():
    """
    Menampilkan notifikasi yang tertunda dari operasi sebelumnya.
    Panggil fungsi ini di AWAL setiap fungsi render() sebelum tabs dibuat,
    agar banner notifikasi selalu terlihat terlepas dari tab mana yang aktif.
    """
    if "_notif_msg" not in st.session_state:
        return

    notif_type = st.session_state.pop("_notif_type", "success")
    notif_msg  = st.session_state.pop("_notif_msg",  "")

    if not notif_msg:
        return

    # Tampilkan toast terlebih dahulu (tidak memicu rerun)
    try:
        icon = "✅" if notif_type == "success" else "❌"
        st.toast(f"{icon} {notif_msg}", icon=icon)
    except Exception:
        pass

    # Tampilkan banner sebagai fallback yang pasti terlihat
    if notif_type == "success":
        st.success(f"✅ {notif_msg}")
    else:
        st.error(f"❌ {notif_msg}")

# ── HTTP Helpers ──────────────────────────────────────────────────────────────

def fetch(endpoint: str, params: dict = None):
    """GET request — hanya menambahkan trailing slash untuk endpoint root."""
    token = get_token()
    if not token:
        st.warning("Tidak terautentikasi. Silakan login kembali.")
        st.stop()

    # Hanya endpoint root (tanpa sub-path) yang mendapat trailing slash
    if "/" not in endpoint and not endpoint.endswith("/"):
        endpoint = endpoint + "/"

    try:
        response = requests.get(
            f"{API_URL}/{endpoint}",
            headers={"Authorization": f"Bearer {token}"},
            params=params or {},
            timeout=30
        )
        if response.status_code == 200:
            return response.json()
        elif response.status_code in (401, 403):
            logout()
            st.error("Sesi telah berakhir. Silakan login kembali.")
            st.rerun()
        else:
            st.error(f"Error {response.status_code}: {response.text}")
        return None
    except requests.exceptions.ConnectionError:
        st.error("Tidak dapat terhubung ke server backend.")
        return None
    except Exception as e:
        st.error(f"Terjadi kesalahan: {e}")
        return None


def crud_create(endpoint: str, data: dict) -> dict | None:
    """POST request — tanpa trailing slash."""
    endpoint = endpoint.rstrip("/")+ "/"
    try:
        response = requests.post(
            f"{API_URL}/{endpoint}",
            headers=get_headers(),
            json=data,
            timeout=30
        )
        if response.status_code in (200, 201):
            return response.json()
        else:
            detail = response.json().get("detail", response.text)
            notif_gagal(f"Gagal menyimpan data: {detail}")
            return None
    except Exception as e:
        notif_gagal(f"Terjadi kesalahan: {e}")
        return None


def crud_update(endpoint: str, id_value: str, data: dict) -> dict | None:
    """PUT request — tanpa trailing slash."""
    endpoint = endpoint.rstrip("/")
    try:
        response = requests.put(
            f"{API_URL}/{endpoint}/{id_value}",
            headers=get_headers(),
            json=data,
            timeout=30
        )
        if response.status_code == 200:
            return response.json()
        else:
            detail = response.json().get("detail", response.text)
            notif_gagal(f"Gagal memperbarui data: {detail}")
            return None
    except Exception as e:
        notif_gagal(f"Terjadi kesalahan: {e}")
        return None


def crud_delete(endpoint: str, id_value: str) -> bool:
    """DELETE request — tanpa trailing slash."""
    endpoint = endpoint.rstrip("/")
    try:
        response = requests.delete(
            f"{API_URL}/{endpoint}/{id_value}",
            headers=get_headers(),
            timeout=30
        )
        if response.status_code == 200:
            return True
        else:
            detail = response.json().get("detail", response.text)
            notif_gagal(f"Gagal menghapus data: {detail}")
            return False
    except Exception as e:
        notif_gagal(f"Terjadi kesalahan: {e}")
        return False


def invalidate_properti_cache():
    for key in ["properti_data_cache", "properti_cache_time"]:
        st.session_state.pop(key, None)


# ── Fungsi Read ───────────────────────────────────────────────────────────────

def get_provinsi() -> list:
    return fetch("provinsi") or []

def get_kabupaten_kota(kode_provinsi=None) -> list:
    params = {"kode_provinsi": kode_provinsi} if kode_provinsi else {}
    return fetch("kabupaten-kota", params) or []

def get_umr(tahun=None, kode_provinsi=None, per_page=99999) -> dict:
    params = {"page": 1, "per_page": per_page}
    if tahun:         params["tahun"] = tahun
    if kode_provinsi: params["kode_provinsi"] = kode_provinsi
    return fetch("umr", params) or {"data": [], "total": 0}

def get_tahun_umr() -> list:
    return fetch("umr/tahun/tersedia") or []

def get_area(kabupaten_kota=None) -> list:
    params = {"kabupaten_kota": kabupaten_kota} if kabupaten_kota else {}
    return fetch("area", params) or []

def get_tipe_properti() -> list:
    return fetch("tipe-properti") or []

def get_segmen_harga() -> list:
    return fetch("segmen-harga") or []

def get_properti(kota=None, tipe=None, segmen=None,
                 harga_min=None, harga_max=None, per_page=99999) -> dict:
    params = {"page": 1, "per_page": per_page}
    if kota:      params["kota"] = kota
    if tipe:      params["tipe"] = tipe
    if segmen:    params["segmen"] = segmen
    if harga_min: params["harga_min"] = harga_min
    if harga_max: params["harga_max"] = harga_max
    return fetch("properti", params) or {"data": [], "total": 0}

def get_semua_properti(kota=None, tipe=None, segmen=None) -> list:
    params = {}
    if kota:   params["kota"] = kota
    if tipe:   params["tipe"] = tipe
    if segmen: params["segmen"] = segmen
    return fetch("properti/semua", params) or []


# ── Cache Properti ────────────────────────────────────────────────────────────

def get_semua_properti_cached() -> list:
    CACHE_KEY      = "properti_data_cache"
    CACHE_TIME_KEY = "properti_cache_time"
    CACHE_TTL      = 3600

    waktu_sekarang = _time.time()
    waktu_cache    = st.session_state.get(CACHE_TIME_KEY, 0)

    if CACHE_KEY in st.session_state and (waktu_sekarang - waktu_cache) < CACHE_TTL:
        return st.session_state[CACHE_KEY]

    data = fetch("properti/semua")
    if data is not None:
        st.session_state[CACHE_KEY]      = data
        st.session_state[CACHE_TIME_KEY] = waktu_sekarang
        return data

    return st.session_state.get(CACHE_KEY, [])

def clear_properti_cache():
    invalidate_properti_cache()

# ─────────────────────────────────────────────────────────────────────────────
# FUNGSI READ — Data Analitik Makroekonomi
# ─────────────────────────────────────────────────────────────────────────────

import time as _time


def get_inflasi(provinsi=None, tahun=None, bulan=None) -> list:
    params = {}
    if provinsi is not None:
        params["provinsi"] = provinsi
    if tahun is not None:
        params["tahun"] = tahun
    if bulan is not None:
        params["bulan"] = bulan
    return fetch("analitik/inflasi", params) or []


def get_inflasi_tahunan(provinsi=None, tahun=None) -> list:
    params = {}
    if provinsi is not None:
        params["provinsi"] = provinsi
    if tahun is not None:
        params["tahun"] = tahun
    return fetch("analitik/inflasi/tahunan", params) or []


def get_ihpr(kota=None, tipe=None, tahun=None, index_base=None) -> list:
    params = {}
    if kota is not None:
        params["kota"] = kota
    if tipe is not None:
        params["tipe"] = tipe
    if tahun is not None:
        params["tahun"] = tahun
    if index_base is not None:
        params["index_base"] = index_base
    return fetch("analitik/ihpr", params) or []


def get_ihpr_tren(kota=None, tipe=None, index_base=2018) -> list:
    params = {"index_base": index_base}
    if kota is not None:
        params["kota"] = kota
    if tipe is not None:
        params["tipe"] = tipe
    return fetch("analitik/ihpr/tren", params) or []


def get_ihpr_kota_tersedia() -> list:
    return fetch("analitik/ihpr/kota-tersedia") or []


def get_pdb(komponen=None, level=None, laju=None, tahun=None, kuartal=None) -> list:
    params = {}
    if komponen is not None:
        params["komponen"] = komponen
    if level is not None:
        params["level"] = level
    if laju is not None:
        params["laju_pertumbuhan"] = laju
    if tahun is not None:
        params["tahun"] = tahun
    if kuartal is not None:
        params["kuartal"] = kuartal
    return fetch("analitik/pdb", params) or []


def get_bi_rate(tahun_mulai=None, tahun_akhir=None) -> list:
    params = {}
    if tahun_mulai is not None:
        params["tahun_mulai"] = tahun_mulai
    if tahun_akhir is not None:
        params["tahun_akhir"] = tahun_akhir
    return fetch("analitik/bi-rate", params) or []


def get_bi_rate_terkini() -> dict:
    return fetch("analitik/bi-rate/terkini") or {"nilai_pct": None, "tanggal": None}


def get_sensus(provinsi=None, tahun=None) -> list:
    params = {}
    if provinsi is not None:
        params["provinsi"] = provinsi
    if tahun is not None:
        params["tahun"] = tahun
    return fetch("analitik/sensus", params) or []


def get_investasi_properti(
    kota=None, tipe=None, segmen=None,
    harga_min=None, harga_max=None
) -> list:
    params = {}
    if kota is not None:
        params["kota"] = kota
    if tipe is not None:
        params["tipe"] = tipe
    if segmen is not None:
        params["segmen"] = segmen
    if harga_min is not None:
        params["harga_min"] = harga_min
    if harga_max is not None:
        params["harga_max"] = harga_max
    return fetch("analitik/investasi-properti", params) or []


# ── Cache untuk data analitik (jarang berubah) ────────────────────────────────

def get_investasi_properti_cached() -> list:
    """
    Cache data investasi properti selama 1 jam.
    Data ini jarang berubah sehingga aman di-cache.
    """
    import streamlit as st
    CACHE_KEY = "investasi_data_cache"
    CACHE_TIME_KEY = "investasi_cache_time"
    CACHE_TTL = 3600

    waktu_sekarang = _time.time()
    waktu_cache = st.session_state.get(CACHE_TIME_KEY, 0)

    if CACHE_KEY in st.session_state and (waktu_sekarang - waktu_cache) < CACHE_TTL:
        return st.session_state[CACHE_KEY]

    data = fetch("analitik/investasi-properti")
    if data is not None:
        st.session_state[CACHE_KEY] = data
        st.session_state[CACHE_TIME_KEY] = waktu_sekarang
        return data

    return st.session_state.get(CACHE_KEY, [])


def clear_investasi_cache():
    import streamlit as st
    for key in ["investasi_data_cache", "investasi_cache_time"]:
        st.session_state.pop(key, None)