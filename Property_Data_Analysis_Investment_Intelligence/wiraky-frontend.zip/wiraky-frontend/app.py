# app.py — versi lengkap dengan navigasi analitik

import streamlit as st
from api_client import login, logout, is_authenticated, get_current_page, navigate_to

st.set_page_config(
    page_title="Wiraky Nusa Telekomunikasi",
    page_icon="📡",
    layout="wide"
)


def show_login():
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("## 📡 Wiraky Nusa Telekomunikasi")
        st.markdown("### Dashboard Analitik Internal")
        st.divider()
        with st.form("login_form"):
            username  = st.text_input("Username")
            password  = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Login", use_container_width=True)
            if submitted:
                if login(username, password):
                    st.rerun()
                else:
                    st.error("Username atau password salah.")


def show_sidebar():
    with st.sidebar:
        st.markdown("## 📡 Wiraky Dashboard")
        st.markdown(f"Login sebagai: **{st.session_state.get('username', 'Admin')}**")
        st.divider()

        current = get_current_page()

        # ── Menu Operasional ─────────────────────────────────────────────────
        st.markdown("**🗂️ Data Operasional**")
        menu_operasional = {
            "🏠 Beranda"          : "home",
            "🏠 Properti"         : "properti",
            "🗺️ Wilayah"          : "wilayah",
            "🗾 Provinsi"         : "provinsi",
            "🏙️ Kabupaten & Kota" : "kabupaten_kota",
            "📍 Area"             : "area",
            "🏗️ Tipe Properti"    : "tipe_properti",
            "💰 Segmen Harga"     : "segmen_harga",
        }
        for label, page_key in menu_operasional.items():
            if st.button(
                label, use_container_width=True,
                type="primary" if current == page_key else "secondary",
                key=f"nav_{page_key}"
            ):
                navigate_to(page_key)
                st.rerun()

        # ── Menu Analitik ─────────────────────────────────────────────────────
        st.divider()
        st.markdown("**📈 Analitik Investasi**")
        menu_analitik = {
            "💼 Dashboard Investasi"  : "analitik_investasi",
            "📊 UMR"                  : "umr",
            "📈 Inflasi"              : "analitik_inflasi",
            "🏘️ IHPR Properti"        : "analitik_ihpr",
            "🏦 BI Rate & PDB"        : "analitik_makro",
            "👥 Sensus Penduduk"      : "analitik_sensus",
        }
        for label, page_key in menu_analitik.items():
            if st.button(
                label, use_container_width=True,
                type="primary" if current == page_key else "secondary",
                key=f"nav_{page_key}"
            ):
                navigate_to(page_key)
                st.rerun()

        st.divider()
        if st.button("🚪 Logout", use_container_width=True):
            logout()
            st.rerun()


# ── Routing utama ─────────────────────────────────────────────────────────────

if not is_authenticated():
    show_login()
else:
    show_sidebar()
    page = get_current_page()
    st.sidebar.write("Current page:", page)
    st.sidebar.write(
        "Role:",
        st.session_state.get("role")
    )
    st.sidebar.write("Session page:", st.session_state.get("p"))
    st.sidebar.write("Session token:", "Ada" if st.session_state.get("token") else "Tidak ada")

    # ── Halaman beranda ───────────────────────────────────────────────────────
    if page == "home":
        st.title("Selamat Datang di Dashboard Wiraky Nusa Telekomunikasi")
        st.markdown(
            "Gunakan menu navigasi di sebelah kiri untuk mengakses "
            "halaman operasional maupun analitik."
        )
        st.divider()
        st.subheader("🗂️ Data Operasional")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.info("📊 **UMR** — Upah minimum regional.")
        with col2:
            st.info("🏠 **Properti** — Data listing properti.")
        with col3:
            st.info("🗺️ **Wilayah** — Persebaran per wilayah.")

        st.divider()
        st.subheader("📈 Analitik Investasi")
        col4, col5, col6, col7, col8 = st.columns(5)
        with col4:
            st.success("💼 **Dashboard Investasi** — Skor potensi & matriks risiko.")
        with col5:
            st.success("📈 **Inflasi** — Tren inflasi bulanan & tahunan per provinsi.")
        with col6:
            st.success("🏘️ **IHPR** — Indeks harga properti residensial.")
        with col7:
            st.success("🏦 **BI Rate & PDB** — Indikator makroekonomi.")
        with col8:
            st.success("👥 **Sensus** — Populasi dan distribusi gender.")

    # ── Halaman operasional ───────────────────────────────────────────────────
    elif page == "properti":
        try:
            from views.properti import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "wilayah":
        try:
            from views.wilayah import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "provinsi":
        try:
            from views.provinsi import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "kabupaten_kota":
        try:
            from views.kabupaten_kota import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "area":
        try:
            from views.area import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "tipe_properti":
        try:
            from views.tipe_properti import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "segmen_harga":
        try:
            from views.segmen_harga import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()

    # ── Halaman analitik ──────────────────────────────────────────────────────
    elif page == "umr":
        try:
            from views.analitik_umr import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "analitik_investasi":
        try:
            from views.analitik_investasi import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "analitik_inflasi":
        try:
            from views.analitik_inflasi import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "analitik_ihpr":
        try:
            from views.analitik_ihpr import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "analitik_makro":
        try:
            from views.analitik_makro import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()
    elif page == "analitik_sensus":
        try:
            from views.analitik_sensus import render; render()
        except Exception as e:
            st.error(
                f"Halaman mengalami error: {e}. "
                f"Coba refresh halaman atau pilih menu lain."
            )
            if st.button("🔄 Muat Ulang Halaman"):
                st.rerun()