import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sqlalchemy import create_engine
import os
from dotenv import load_dotenv

load_dotenv()

# ── Konfigurasi Halaman ───────────────────────────────────────────────────────
st.set_page_config(
    page_title="Dashboard ABSA — Maribaya Resort",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── Custom CSS (tema sama dengan dashboard reviews, untuk konsistensi) ────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500&display=swap');

    html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
    .main { background-color: #faf8f4; }

    .dashboard-header {
        background: linear-gradient(160deg, #2d4a2d 0%, #3d5c3a 50%, #4a6b45 100%);
        padding: 28px 32px;
        border-radius: 12px;
        margin-bottom: 28px;
        color: white;
    }
    .dashboard-header h1 { font-size: 26px; font-weight: 300; margin: 0 0 4px 0; letter-spacing: 0.3px; }
    .dashboard-header p  { font-size: 13px; opacity: 0.7; margin: 0; }

    [data-testid="metric-container"] {
        background: white;
        border: 1px solid #ddd8cf;
        border-radius: 10px;
        padding: 16px !important;
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }

    .section-title {
        font-size: 15px;
        font-weight: 500;
        color: #5a7a5a;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin: 28px 0 12px 0;
        padding-bottom: 8px;
        border-bottom: 1px solid #ddd8cf;
    }

    [data-testid="stSidebar"] { background-color: #f0ede6; }

    .review-banner {
        background: #fdf0ee;
        border: 1px solid rgba(192,57,43,0.3);
        border-left: 4px solid #c0392b;
        border-radius: 8px;
        padding: 14px 18px;
        margin-bottom: 16px;
        font-size: 13px;
        color: #7a2c1f;
    }
</style>
""", unsafe_allow_html=True)

# ── Koneksi Database ──────────────────────────────────────────────────────────
@st.cache_resource
def get_engine():
    return create_engine(os.getenv("DATABASE_URL"))

@st.cache_data(ttl=300)
def load_data():
    engine = get_engine()
    # LEFT JOIN ke reviews untuk konteks (nama, kota, waktu, status anomali) —
    # LEFT (bukan INNER) supaya baris tidak diam-diam hilang kalau ada
    # review_id yang kebetulan tidak match (defensif, bukan diasumsikan
    # selalu bersih).
    query = """
        SELECT
            ras.id, ras.review_id,
            ras.aspect_term, ras.confidence_aspect_term,
            ras.opinion_term, ras.confidence_opinion_term,
            ras.aspect_category, ras.confidence_aspect_category,
            ras.opinion_sentiment, ras.confidence_opinion_sentiment,
            r.nama, r.kota_asal, r.submitted_at, r.is_anomaly, r.ulasan_teks
        FROM review_aspect_sentiment ras
        LEFT JOIN reviews r ON ras.review_id = r.id
    """
    df = pd.read_sql(query, engine)
    df["submitted_at"] = pd.to_datetime(df["submitted_at"])
    df["submitted_at"] = df["submitted_at"] + pd.Timedelta(hours=7)
    df["submitted_date"] = df["submitted_at"].dt.date
    return df

# ── Warna Konsisten ───────────────────────────────────────────────────────────
PALETTE = ["#5a7a5a", "#c9a96e", "#8b6f5a", "#7a9c7a", "#c4b8a8", "#3d5c3a", "#e8f0e8"]

CONF_COLS = {
    "confidence_aspect_term":      "Aspect Term",
    "confidence_aspect_category":  "Aspect Category",
    "confidence_opinion_term":     "Opinion Term",
    "confidence_opinion_sentiment": "Opinion Sentiment",
}

def warna_sentiment(label):
    """Pemetaan warna berdasarkan substring, bukan hardcode nilai persis —
    supaya tetap tepat warnanya apapun bahasa/kapitalisasi label sentimen
    yang sebenarnya dipakai di data (positif/positive/POSITIVE, dst)."""
    l = str(label).lower()
    if "posit" in l:
        return "#5a7a5a"   # sage — konsisten dengan tema positif di dashboard lain
    if "negat" in l:
        return "#c0392b"   # merah — sama dengan warna error di seluruh sistem
    if "netral" in l or "neutral" in l:
        return "#c4b8a8"   # stone
    return "#8b6f5a"       # earth — fallback untuk label tak terduga

def make_pie(df, col, title, warna_map=None):
    counts = df[col].value_counts().reset_index()
    counts.columns = [col, "Jumlah"]
    if warna_map:
        colors = [warna_map(v) for v in counts[col]]
    else:
        colors = PALETTE
    fig = px.pie(counts, names=col, values="Jumlah", hole=0.4,
                 color_discrete_sequence=colors if warna_map else PALETTE)
    if warna_map:
        fig.update_traces(marker=dict(colors=colors))
    fig.update_traces(textposition="outside", textinfo="percent+label")
    fig.update_layout(
        title=dict(text=title, font=dict(size=14, color="#2d2d2d")),
        showlegend=True, legend=dict(orientation="h", yanchor="bottom", y=-0.3),
        margin=dict(t=48, b=48, l=12, r=12),
        paper_bgcolor="white", plot_bgcolor="white", font=dict(family="DM Sans"),
    )
    return fig

def make_bar_h(df, col, title, top_n=15):
    counts = df[col].value_counts().head(top_n).reset_index()
    counts.columns = [col, "Jumlah"]
    counts = counts.sort_values("Jumlah")
    fig = px.bar(counts, x="Jumlah", y=col, orientation="h",
                 color_discrete_sequence=[PALETTE[0]], text="Jumlah")
    fig.update_traces(textposition="outside")
    fig.update_layout(
        title=dict(text=title, font=dict(size=14, color="#2d2d2d")),
        xaxis_title="Jumlah", yaxis_title="",
        margin=dict(t=48, b=24, l=12, r=48),
        paper_bgcolor="white", plot_bgcolor="white", font=dict(family="DM Sans"),
        yaxis=dict(gridcolor="#f0ece5"), xaxis=dict(gridcolor="#f0ece5"),
    )
    return fig

def beautify_layout(fig):
    fig.update_layout(
        paper_bgcolor="white",
        plot_bgcolor="white",
        font=dict(family="DM Sans"),

        title=dict(
            x=0,
            xanchor="left",
            y=0.97
        ),

        legend=dict(
            orientation="h",
            x=0,
            xanchor="left",
            y=1.08,
            yanchor="bottom"
        ),

        margin=dict(
            t=110,
            b=40,
            l=20,
            r=20
        ),

        height=500
    )

    return fig

# ── Load Data ─────────────────────────────────────────────────────────────────
try:
    df_raw = load_data()
except Exception as e:
    st.error(f"Gagal terhubung ke database: {e}")
    st.info("Pastikan tabel `review_aspect_sentiment` sudah dibuat dan diisi via absa_extraction.py.")
    st.stop()

if df_raw.empty:
    st.warning("Tabel review_aspect_sentiment masih kosong. Jalankan absa_extraction.py terlebih dahulu.")
    st.stop()

# ── Sidebar Filters ───────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🔍 Filter Data")
    st.markdown("---")

    aspect_category_sel = st.multiselect(
        "Aspect Category",
        options=sorted(df_raw["aspect_category"].dropna().unique().tolist()),
        default=[], placeholder="Semua"
    )

    opinion_sentiment_sel = st.multiselect(
        "Opinion Sentiment",
        options=sorted(df_raw["opinion_sentiment"].dropna().unique().tolist()),
        default=[], placeholder="Semua"
    )

    st.markdown("---")
    st.markdown("**Rentang Tanggal**")
    submitted_clean = df_raw["submitted_at"].dropna()
    if len(submitted_clean) > 0:
        min_date = pd.Timestamp(submitted_clean.min()).date()
        max_date = pd.Timestamp(submitted_clean.max()).date()
        if min_date == max_date:
            st.caption(f"Tanggal: {min_date} (data belum bervariasi)")
            tanggal_range = (min_date, max_date)
        else:
            tanggal_range = st.date_input(
                "Pilih Rentang Tanggal", value=(min_date, max_date),
                min_value=min_date, max_value=max_date,
            )
    else:
        tanggal_range = None

    exclude_anomali = st.checkbox(
        "Kecualikan review anomali (is_anomaly)",
        value=True,
        help="Review yang ditandai anomaly_detection.py bisa mendistorsi insight ABSA — direkomendasikan tetap dicentang."
    )

    st.markdown("---")
    st.markdown("### 🎯 Peninjauan Ulang (Confidence Rendah)")
    st.caption("Geser slider untuk menandai baris dengan confidence DI BAWAH nilai ini pada kolom terkait. Default 0 = tidak memfilter.")

    conf_thresholds = {}
    for col, label in CONF_COLS.items():
        conf_thresholds[col] = st.slider(
            f"Confidence {label} <", 0.0, 1.0, 0.0, 0.05,
            key=f"conf_{col}"
        )

    st.markdown("---")
    st.markdown("*Data diperbarui setiap 5 menit*")

# ── Terapkan Filter ───────────────────────────────────────────────────────────
df = df_raw.copy()

if aspect_category_sel:
    df = df[df["aspect_category"].isin(aspect_category_sel)]
if opinion_sentiment_sel:
    df = df[df["opinion_sentiment"].isin(opinion_sentiment_sel)]

if exclude_anomali and "is_anomaly" in df.columns:
    df = df[df["is_anomaly"] != True]

if tanggal_range and isinstance(tanggal_range, tuple) and len(tanggal_range) == 2:
    df = df[
        (df["submitted_at"].dt.date >= tanggal_range[0]) &
        (df["submitted_at"].dt.date <= tanggal_range[1])
    ]

# ── Hitung Flag Peninjauan Ulang (OR di antara 4 dimensi confidence) ──────────
# Sengaja OR, bukan AND: seorang reviewer manusia ingin tahu ulasan yang
# LEMAH DI MANA SAJA (aspect_term ATAU category ATAU opinion_term ATAU
# sentiment) — bukan cuma yang lemah di keempat-empatnya sekaligus, karena
# itu justru kasus paling jarang dan paling tidak berguna untuk QA.
df["flagged"] = False
df["alasan_flag"] = ""

for col, label in CONF_COLS.items():
    threshold = conf_thresholds[col]
    if threshold > 0:
        # Null confidence dianggap LEBIH layak ditinjau daripada confidence
        # rendah biasa — ini terjadi kalau ekstraksi tidak menghasilkan
        # aspek/opini sama sekali untuk review tsb (lihat absa_extraction.py:
        # baris "tidak ada aspek terdeteksi" punya semua kolom confidence
        # null). Tanpa OR isna() ini, baris tsb TIDAK PERNAH ter-flag
        # walau threshold dinaikkan setinggi apapun — terverifikasi lewat
        # pengujian manual sebelum dirilis.
        mask = (df[col] < threshold) | (df[col].isna())
        df.loc[mask, "flagged"] = True
        df.loc[mask, "alasan_flag"] += df.loc[mask].apply(
            lambda row, c=col, lb=label: f"{lb}: {'kosong' if pd.isna(row[c]) else f'{row[c]:.2f}'} | ", axis=1
        )

df["alasan_flag"] = df["alasan_flag"].str.rstrip(" |")

any_threshold_active = any(v > 0 for v in conf_thresholds.values())

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="dashboard-header">
    <h1>🔍 Dashboard Aspect-Based Sentiment Analysis</h1>
    <p>Analisis aspek & sentimen ulasan Maribaya Resort — hasil ekstraksi otomatis</p>
</div>
""", unsafe_allow_html=True)

# ── Metric Summary ────────────────────────────────────────────────────────────
c1, c2, c3, c4, c5 = st.columns(5)

total_pasangan   = len(df)
total_review     = df["review_id"].nunique()
avg_conf         = df[list(CONF_COLS.keys())].mean().mean() if total_pasangan > 0 else 0
total_flagged    = df["flagged"].sum()
pct_negatif = 0
if total_pasangan > 0 and df["opinion_sentiment"].notna().any():
    mask_neg = df["opinion_sentiment"].str.lower().str.contains("negat", na=False)
    pct_negatif = (mask_neg.sum() / df["opinion_sentiment"].notna().sum()) * 100

c1.metric("Total Pasangan Aspek-Opini", f"{total_pasangan:,}")
c2.metric("Ulasan Unik Terwakili",      f"{total_review:,}")
c3.metric("Rata-rata Confidence",       f"{avg_conf:.2f}" if total_pasangan > 0 else "-")
c4.metric("Perlu Ditinjau Ulang",       f"{total_flagged:,}")
c5.metric("% Sentimen Negatif",         f"{pct_negatif:.1f}%" if total_pasangan > 0 else "-")

if total_pasangan == 0:
    st.warning("Tidak ada data yang sesuai dengan filter yang dipilih.")
    st.stop()

# ── Seksi 0: Peninjauan Ulang (kalau ada threshold aktif) ────────────────────
if any_threshold_active:
    df_review = df[df["flagged"]].sort_values(
        [c for c in CONF_COLS.keys()], ascending=True
    )
    st.markdown('<div class="section-title">🎯 Perlu Ditinjau Ulang</div>', unsafe_allow_html=True)
    st.markdown(f"""
    <div class="review-banner">
        <b>{len(df_review):,} baris</b> memiliki minimal satu confidence score di bawah threshold yang kamu set di sidebar.
        Diurutkan dari confidence paling rendah.
    </div>
    """, unsafe_allow_html=True)

    kolom_review = ["review_id", "aspect_term", "confidence_aspect_term",
                     "aspect_category", "confidence_aspect_category",
                     "opinion_term", "confidence_opinion_term",
                     "opinion_sentiment", "confidence_opinion_sentiment",
                     "alasan_flag", "ulasan_teks"]
    st.dataframe(
        df_review[kolom_review].rename(columns={
            "review_id": "Review ID", "aspect_term": "Aspect Term",
            "confidence_aspect_term": "Conf. Aspect",
            "aspect_category": "Category", "confidence_aspect_category": "Conf. Category",
            "opinion_term": "Opinion Term", "confidence_opinion_term": "Conf. Opinion",
            "opinion_sentiment": "Sentiment", "confidence_opinion_sentiment": "Conf. Sentiment",
            "alasan_flag": "Alasan Ditandai", "ulasan_teks": "Ulasan Asli"
        }),
        use_container_width=True, height=320, hide_index=True
    )

    csv_review = df_review[kolom_review].to_csv(index=False, encoding="utf-8-sig")
    st.download_button(
        "⬇️ Download Daftar Perlu Ditinjau (CSV)", data=csv_review,
        file_name="perlu_ditinjau_ulang.csv", mime="text/csv"
    )

# ── Seksi 1: Distribusi Aspect Category & Opinion Sentiment ──────────────────
st.markdown('<div class="section-title">📊 Distribusi Kategori & Sentimen</div>', unsafe_allow_html=True)

col1, col2 = st.columns(2)
with col1:
    st.plotly_chart(
        make_pie(df.dropna(subset=["aspect_category"]), "aspect_category", "Distribusi Aspect Category"),
        use_container_width=True
    )
with col2:
    st.plotly_chart(
        make_pie(df.dropna(subset=["opinion_sentiment"]), "opinion_sentiment",
                 "Distribusi Opinion Sentiment", warna_map=warna_sentiment),
        use_container_width=True
    )

# ── Seksi 2: Sentimen per Kategori — INSIGHT UTAMA ───────────────────────────
st.markdown('<div class="section-title">🎯 Sentimen per Aspect Category (Insight Utama)</div>', unsafe_allow_html=True)
st.caption("Kategori mana yang paling banyak dikeluhkan (sentimen negatif) vs dipuji (positif) — jawaban langsung untuk pertanyaan bisnis inti proyek ini.")

df_cross = df.dropna(subset=["aspect_category", "opinion_sentiment"])
if not df_cross.empty:
    cross_count = df_cross.groupby(["aspect_category", "opinion_sentiment"]).size().reset_index(name="Jumlah")
    cross_pct = cross_count.copy()
    total_per_cat = cross_count.groupby("aspect_category")["Jumlah"].transform("sum")
    cross_pct["Persentase"] = (cross_count["Jumlah"] / total_per_cat) * 100

    sentimen_unik = sorted(df_cross["opinion_sentiment"].unique())
    warna_map_sentimen = {s: warna_sentiment(s) for s in sentimen_unik}

    tab1, tab2 = st.tabs(["Persentase (100% Stacked)", "Jumlah Absolut"])

    with tab1:
        fig_pct = px.bar(
            cross_pct, x="aspect_category", y="Persentase", color="opinion_sentiment",
            color_discrete_map=warna_map_sentimen, text=cross_pct["Persentase"].round(1),
            title="Proporsi Sentimen per Aspect Category (%)"
        )
        fig_pct.update_traces(textposition="inside")
        fig_pct.update_layout(
            barmode="stack",
            xaxis_title="",
            yaxis_title="Persentase (%)",

            xaxis=dict(
                tickangle=-20,
                gridcolor="#f0ece5"
            ),

            yaxis=dict(
                gridcolor="#f0ece5"
            )
        )

        fig_pct = beautify_layout(fig_pct)
        st.plotly_chart(fig_pct, use_container_width=True)

    with tab2:
        fig_abs = px.bar(
            cross_count, x="aspect_category", y="Jumlah", color="opinion_sentiment",
            color_discrete_map=warna_map_sentimen, barmode="group",
            title="Jumlah Pasangan Aspek-Opini per Kategori & Sentimen"
        )
        fig_abs.update_layout(
            xaxis_title="",
            yaxis_title="Jumlah",

            xaxis=dict(
                tickangle=-20,
                gridcolor="#f0ece5"
            ),

            yaxis=dict(
                gridcolor="#f0ece5"
            )
        )

        fig_abs = beautify_layout(fig_abs)
        st.plotly_chart(fig_abs, use_container_width=True)
else:
    st.info("Tidak cukup data untuk cross-tab sentimen per kategori pada filter saat ini.")

# ── Seksi 3: Term Paling Sering Muncul ────────────────────────────────────────
st.markdown('<div class="section-title">🔤 Aspect Term & Opinion Term Paling Sering</div>', unsafe_allow_html=True)

col1, col2 = st.columns(2)
with col1:
    st.plotly_chart(
        make_bar_h(df.dropna(subset=["aspect_term"]), "aspect_term", "Top 15 Aspect Term", top_n=15),
        use_container_width=True
    )
with col2:
    st.plotly_chart(
        make_bar_h(df.dropna(subset=["opinion_term"]), "opinion_term", "Top 15 Opinion Term", top_n=15),
        use_container_width=True
    )

# Opinion term Top 15, dipecah per sentimen — biar tahu "enak" itu selalu
# positif atau kadang dipakai sarkastis/negatif
df_opinion_sent = df.dropna(subset=["opinion_term", "opinion_sentiment"])
if not df_opinion_sent.empty:
    top_terms = df_opinion_sent["opinion_term"].value_counts().head(12).index.tolist()
    df_top = df_opinion_sent[df_opinion_sent["opinion_term"].isin(top_terms)]
    count_top = df_top.groupby(["opinion_term", "opinion_sentiment"]).size().reset_index(name="Jumlah")

    sentimen_unik2 = sorted(df_top["opinion_sentiment"].unique())
    warna_map2 = {s: warna_sentiment(s) for s in sentimen_unik2}

    fig_opinion = px.bar(
        count_top, x="Jumlah", y="opinion_term", color="opinion_sentiment",
        orientation="h", color_discrete_map=warna_map2, barmode="stack",
        title="Top 12 Opinion Term — Dipecah per Sentimen",
        category_orders={"opinion_term": top_terms[::-1]}
    )
    fig_opinion.update_layout(
        yaxis_title="",
        xaxis_title="Jumlah",

        xaxis=dict(
            gridcolor="#f0ece5"
        )
    )

    fig_opinion = beautify_layout(fig_opinion)
    st.plotly_chart(fig_opinion, use_container_width=True)

# ── Seksi 4: Tren Sentimen dari Waktu ke Waktu ───────────────────────────────
st.markdown('<div class="section-title">📈 Tren Sentimen dari Waktu ke Waktu</div>', unsafe_allow_html=True)
st.caption("Berguna untuk mendeteksi isu yang baru muncul (mis. lonjakan sentimen negatif di kategori tertentu pada periode tertentu).")

df_tren = df.dropna(subset=["submitted_date", "opinion_sentiment"])
if not df_tren.empty and df_tren["submitted_date"].nunique() > 1:
    tren_data = df_tren.groupby(["submitted_date", "opinion_sentiment"]).size().reset_index(name="Jumlah")
    warna_map3 = {s: warna_sentiment(s) for s in sorted(tren_data["opinion_sentiment"].unique())}

    fig_tren = px.line(
        tren_data, x="submitted_date", y="Jumlah", color="opinion_sentiment",
        markers=True, color_discrete_map=warna_map3,
        title="Jumlah Opini per Sentimen dari Waktu ke Waktu",
        labels={"submitted_date": "Tanggal", "Jumlah": "Jumlah Opini"},
    )
    fig_tren.update_layout(
        yaxis=dict(
            gridcolor="#f0ece5"
        ),

        xaxis=dict(
            gridcolor="#f0ece5"
        )
    )

    fig_tren = beautify_layout(fig_tren)
    st.plotly_chart(fig_tren, use_container_width=True)
else:
    st.info("Data tanggal belum cukup bervariasi untuk menampilkan tren.")

# ── Seksi 5: Distribusi Confidence Score (4 dimensi) ─────────────────────────
st.markdown('<div class="section-title">📐 Distribusi Confidence Score</div>', unsafe_allow_html=True)
st.caption("Semakin banyak nilai menumpuk di sisi kiri (rendah), semakin banyak hasil ekstraksi yang layak diverifikasi manual.")

cols_hist = st.columns(4)
for idx, (col, label) in enumerate(CONF_COLS.items()):
    with cols_hist[idx]:
        fig_hist = px.histogram(
            df.dropna(subset=[col]), x=col, nbins=20,
            color_discrete_sequence=[PALETTE[0]], title=label,
        )
        fig_hist.update_layout(
            paper_bgcolor="white", plot_bgcolor="white", font=dict(family="DM Sans", size=11),
            yaxis=dict(gridcolor="#f0ece5", title=""), xaxis=dict(title="", range=[0, 1]),
            margin=dict(t=36, b=24, l=12, r=12), height=260,
            title=dict(font=dict(size=12)),
        )
        st.plotly_chart(fig_hist, use_container_width=True)

# ── Seksi 6: Tabel Data Lengkap & Download ───────────────────────────────────
st.markdown('<div class="section-title">📋 Data Lengkap</div>', unsafe_allow_html=True)

ROWS_PER_PAGE = 1000
df_tabel   = df.drop(columns=["flagged", "alasan_flag"], errors="ignore")
total_rows = len(df_tabel)
total_pages = max(1, (total_rows + ROWS_PER_PAGE - 1) // ROWS_PER_PAGE)

st.caption(f"Menampilkan {ROWS_PER_PAGE:,} baris per halaman untuk menjaga performa. Total {total_pages} halaman.")

if "tabel_halaman_absa" not in st.session_state:
    st.session_state["tabel_halaman_absa"] = 1
if st.session_state["tabel_halaman_absa"] > total_pages:
    st.session_state["tabel_halaman_absa"] = 1

col_nav1, col_nav2, col_nav3, col_nav4, col_nav5 = st.columns([1, 1, 2, 1, 1])
with col_nav1:
    if st.button("⏮ Pertama", use_container_width=True, key="absa_first",
                 disabled=st.session_state["tabel_halaman_absa"] == 1):
        st.session_state["tabel_halaman_absa"] = 1
with col_nav2:
    if st.button("◀ Sebelum", use_container_width=True, key="absa_prev",
                 disabled=st.session_state["tabel_halaman_absa"] == 1):
        st.session_state["tabel_halaman_absa"] -= 1
with col_nav3:
    st.markdown(
        f"<div style='text-align:center; padding-top:8px;'>"
        f"Halaman <b>{st.session_state['tabel_halaman_absa']}</b> dari <b>{total_pages}</b></div>",
        unsafe_allow_html=True
    )
with col_nav4:
    if st.button("Sesudah ▶", use_container_width=True, key="absa_next",
                 disabled=st.session_state["tabel_halaman_absa"] == total_pages):
        st.session_state["tabel_halaman_absa"] += 1
with col_nav5:
    if st.button("Terakhir ⏭", use_container_width=True, key="absa_last",
                 disabled=st.session_state["tabel_halaman_absa"] == total_pages):
        st.session_state["tabel_halaman_absa"] = total_pages

halaman   = st.session_state["tabel_halaman_absa"]
idx_awal  = (halaman - 1) * ROWS_PER_PAGE
idx_akhir = min(idx_awal + ROWS_PER_PAGE, total_rows)

st.caption(f"Baris {idx_awal + 1:,} – {idx_akhir:,} dari {total_rows:,}")
st.dataframe(df_tabel.iloc[idx_awal:idx_akhir], use_container_width=True, hide_index=True, height=420)

st.download_button(
    label=f"⬇️ Download Seluruh Data Terfilter ({total_rows:,} baris) sebagai CSV",
    data=df_tabel.to_csv(index=False, encoding="utf-8-sig"),
    file_name="review_aspect_sentiment_filtered.csv",
    mime="text/csv",
    use_container_width=True,
)